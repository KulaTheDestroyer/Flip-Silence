package com.flipsilence.app

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings as AndroidSettings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

private val Bg = Color(0xFF101827)
private val Panel = Color(0xFF1D2A3D)
private val Accent = Color(0xFF9BAEFF)
private val Muted = Color(0xFFB8C4D6)
private val Subtle = Color(0xFF9EADC2)
private val DividerColor = Color(0xFF34445B)

private enum class SoundTarget {
    ENABLE,
    DISABLE
}

private enum class SettingsPage {
    HOME,
    SETTINGS,
    NOTIFICATIONS,
    SOUND,
    SOUNDS,
    SOUND_ENABLE,
    SOUND_DISABLE,
    LANGUAGE,
    ABOUT
}

class MainActivity : ComponentActivity() {

    private val notificationPermission =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (
            Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(
                Manifest.permission.POST_NOTIFICATIONS
            )
        }

        setContent {
            FlipSilenceScreen()
        }
    }
}

@Composable
private fun FlipSilenceScreen() {
    val context = LocalContext.current

    var language by remember {
        mutableStateOf(Settings.language(context))
    }

    val navigation = remember {
        mutableStateListOf(SettingsPage.HOME)
    }

    val currentPage = navigation.last()

    fun navigate(page: SettingsPage) {
        if (navigation.lastOrNull() != page) {
            navigation.add(page)
        }
    }

    fun goBack() {
        if (navigation.size > 1) {
            navigation.removeAt(navigation.lastIndex)
        }
    }

    BackHandler(enabled = navigation.size > 1) {
        goBack()
    }

    var enabled by remember {
        mutableStateOf(Settings.enabled(context))
    }

    var schedule by remember {
        mutableStateOf(Settings.scheduleEnabled(context))
    }

    var start by remember {
        mutableIntStateOf(Settings.startMinute(context))
    }

    var end by remember {
        mutableIntStateOf(Settings.endMinute(context))
    }

    var days by remember {
        mutableIntStateOf(Settings.daysMask(context))
    }

    var delayValue by remember {
        mutableFloatStateOf(Settings.delayMs(context).toFloat())
    }

    var sensitivity by remember {
        mutableFloatStateOf(Settings.sensitivity(context).toFloat())
    }

    var torch by remember {
        mutableStateOf(Settings.blockTorch(context))
    }

    var media by remember {
        mutableStateOf(Settings.blockMedia(context))
    }

    var headphones by remember {
        mutableStateOf(Settings.blockHeadphones(context))
    }

    var unlockedScreen by remember {
        mutableStateOf(Settings.blockUnlockedScreen(context))
    }

    var camera by remember {
        mutableStateOf(Settings.blockCamera(context))
    }

    var battery by remember {
        mutableIntStateOf(Settings.minBattery(context))
    }

    var permission by remember {
        mutableStateOf(hasDndAccess(context))
    }

    var dndAlarms by remember {
        mutableStateOf(Settings.allowDndAlarms(context))
    }

    var dndCalls by remember {
        mutableStateOf(Settings.allowDndCalls(context))
    }

    var dndRepeatCallers by remember {
        mutableStateOf(Settings.allowDndRepeatCallers(context))
    }

    var dndMessages by remember {
        mutableStateOf(Settings.allowDndMessages(context))
    }

    var dndReminders by remember {
        mutableStateOf(Settings.allowDndReminders(context))
    }

    var dndEvents by remember {
        mutableStateOf(Settings.allowDndEvents(context))
    }

    var dndMedia by remember {
        mutableStateOf(Settings.allowDndMedia(context))
    }

    var dndSystem by remember {
        mutableStateOf(Settings.allowDndSystem(context))
    }

    var soundEnable by remember {
        mutableStateOf(Settings.soundOnEnable(context))
    }

    var soundDisable by remember {
        mutableStateOf(Settings.soundOnDisable(context))
    }

    // Niezależna głośność dźwięku włączania i wyłączania DND.
    var soundOnVolume by remember {
        mutableIntStateOf(Settings.soundOnVolume(context))
    }

    var soundOffVolume by remember {
        mutableIntStateOf(Settings.soundOffVolume(context))
    }

    var soundTone by remember {
        mutableIntStateOf(Settings.soundTone(context))
    }

    var soundStream by remember {
        mutableStateOf(Settings.soundStream(context))
    }

    var vibrationEnable by remember {
        mutableStateOf(Settings.vibrationOnEnable(context))
    }

    var vibrationDisable by remember {
        mutableStateOf(Settings.vibrationOnDisable(context))
    }

    var showStatusNotification by remember {
        mutableStateOf(Settings.showStatusNotification(context))
    }

    var showNotificationWarning by remember {
        mutableStateOf(false)
    }

    var refreshSounds by remember {
        mutableIntStateOf(0)
    }

    var pendingSoundTarget by remember {
        mutableStateOf(SoundTarget.ENABLE)
    }

    var showSupportDialog by remember {
        mutableStateOf(false)
    }

    LaunchedEffect(Unit) {
        delay(5000L)
        showSupportDialog = true
    }

    val ringtonePicker =
        rememberLauncherForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->

            if (result.resultCode != Activity.RESULT_OK) {
                return@rememberLauncherForActivityResult
            }

            val uri = if (Build.VERSION.SDK_INT >= 33) {
                result.data?.getParcelableExtra(
                    RingtoneManager.EXTRA_RINGTONE_PICKED_URI,
                    Uri::class.java
                )
            } else {
                @Suppress("DEPRECATION")
                result.data?.getParcelableExtra<Uri>(
                    RingtoneManager.EXTRA_RINGTONE_PICKED_URI
                )
            }

            if (uri != null) {
                when (pendingSoundTarget) {
                    SoundTarget.ENABLE -> {
                        Settings.setSoundOnType(
                            context,
                            Settings.SOUND_SYSTEM
                        )
                        Settings.setSoundOnUri(
                            context,
                            uri.toString()
                        )
                    }

                    SoundTarget.DISABLE -> {
                        Settings.setSoundOffType(
                            context,
                            Settings.SOUND_SYSTEM
                        )
                        Settings.setSoundOffUri(
                            context,
                            uri.toString()
                        )
                    }
                }

                refreshSounds++
            }
        }

    val customPicker =
        rememberLauncherForActivityResult(
            ActivityResultContracts.OpenDocument()
        ) { uri ->

            if (uri == null) {
                return@rememberLauncherForActivityResult
            }

            try {
                val directory = File(context.filesDir, "sounds")

                if (!directory.exists() && !directory.mkdirs()) {
                    throw IllegalStateException(
                        "Nie można utworzyć katalogu dźwięków."
                    )
                }

                val fileName = if (
                    pendingSoundTarget == SoundTarget.ENABLE
                ) {
                    "sound_on"
                } else {
                    "sound_off"
                }

                val extension = when (
                    context.contentResolver.getType(uri)
                ) {
                    "audio/mpeg" -> ".mp3"
                    "audio/wav", "audio/x-wav" -> ".wav"
                    "audio/ogg", "application/ogg" -> ".ogg"
                    "audio/mp4", "audio/m4a" -> ".m4a"
                    "audio/flac" -> ".flac"
                    else -> ".audio"
                }

                val destination = File(
                    directory,
                    fileName + extension
                )

                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(destination).use { output ->
                        input.copyTo(output)
                    }
                } ?: throw IllegalStateException(
                    "Nie można otworzyć wybranego pliku."
                )

                when (pendingSoundTarget) {
                    SoundTarget.ENABLE -> {
                        Settings.setSoundOnType(
                            context,
                            Settings.SOUND_CUSTOM
                        )
                        Settings.setSoundOnCustomFile(
                            context,
                            destination.name
                        )
                    }

                    SoundTarget.DISABLE -> {
                        Settings.setSoundOffType(
                            context,
                            Settings.SOUND_CUSTOM
                        )
                        Settings.setSoundOffCustomFile(
                            context,
                            destination.name
                        )
                    }
                }

                refreshSounds++

            } catch (_: Exception) {
                Toast.makeText(
                    context,
                    tr(
                        language,
                        "Nie udało się skopiować pliku audio.",
                        "Could not copy the audio file."
                    ),
                    Toast.LENGTH_LONG
                ).show()
            }
        }

    fun openSystemSoundPicker(target: SoundTarget) {
        pendingSoundTarget = target

        val existing = if (target == SoundTarget.ENABLE) {
            Settings.soundOnUri(context)
        } else {
            Settings.soundOffUri(context)
        }

        val intent = Intent(
            RingtoneManager.ACTION_RINGTONE_PICKER
        ).apply {
            putExtra(
                RingtoneManager.EXTRA_RINGTONE_TYPE,
                RingtoneManager.TYPE_ALL
            )

            putExtra(
                RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT,
                true
            )

            putExtra(
                RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT,
                false
            )

            putExtra(
                RingtoneManager.EXTRA_RINGTONE_TITLE,
                tr(
                    language,
                    "Wybierz dźwięk",
                    "Choose a sound"
                )
            )

            if (!existing.isNullOrBlank()) {
                putExtra(
                    RingtoneManager.EXTRA_RINGTONE_EXISTING_URI,
                    Uri.parse(existing)
                )
            }
        }

        try {
            ringtonePicker.launch(intent)
        } catch (_: Exception) {
            Toast.makeText(
                context,
                tr(
                    language,
                    "Nie można otworzyć wyboru dźwięku systemowego.",
                    "Could not open the system sound picker."
                ),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    fun openCustomSoundPicker(target: SoundTarget) {
        pendingSoundTarget = target

        try {
            customPicker.launch(arrayOf("audio/*"))
        } catch (_: Exception) {
            Toast.makeText(
                context,
                tr(
                    language,
                    "Nie można otworzyć wyboru pliku.",
                    "Could not open the file picker."
                ),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    fun previewSound(target: SoundTarget) {
        val type = if (target == SoundTarget.ENABLE) {
            Settings.soundOnType(context)
        } else {
            Settings.soundOffType(context)
        }

        val uri = if (target == SoundTarget.ENABLE) {
            Settings.soundOnUri(context)
        } else {
            Settings.soundOffUri(context)
        }

        val customFile = if (target == SoundTarget.ENABLE) {
            Settings.soundOnCustomFile(context)
        } else {
            Settings.soundOffCustomFile(context)
        }

        // Odsłuch wykorzystuje głośność właściwą dla danego dźwięku.
        val volume = if (target == SoundTarget.ENABLE) {
            soundOnVolume
        } else {
            soundOffVolume
        }

        playSelectedSound(
            context = context,
            type = type,
            uri = uri,
            customFile = customFile,
            toneIndex = soundTone,
            volume = volume,
            stream = soundStream,
            language = language
        )
    }

    fun updateDndSetting(
        value: Boolean,
        setter: (Boolean) -> Unit
    ) {
        setter(value)

        if (enabled) {
            updateService(context, true)
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Bg,
            surface = Panel
        )
    ) {
        when (currentPage) {

            SettingsPage.HOME -> {
                MainHomeScreen(
                    language = language,
                    enabled = enabled,
                    onEnabledChange = { value ->
                        if (value && !hasDndAccess(context)) {
                            context.startActivity(
                                Intent(
                                    AndroidSettings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS
                                )
                            )
                        } else {
                            enabled = value
                            Settings.setEnabled(context, value)
                            updateService(context, value)
                        }
                    },
                    permission = permission,
                    onOpenPermission = {
                        context.startActivity(
                            Intent(
                                AndroidSettings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS
                            )
                        )
                    },
                    schedule = schedule,
                    onScheduleChange = {
                        schedule = it
                        Settings.setScheduleEnabled(context, it)

                        if (enabled) {
                            updateService(context, true)
                        }
                    },
                    start = start,
                    end = end,
                    onStartChange = {
                        start = it
                        Settings.setStartMinute(context, it)

                        if (enabled) {
                            updateService(context, true)
                        }
                    },
                    onEndChange = {
                        end = it
                        Settings.setEndMinute(context, it)

                        if (enabled) {
                            updateService(context, true)
                        }
                    },
                    days = days,
                    onDaysChange = {
                        days = it
                        Settings.setDaysMask(context, it)

                        if (enabled) {
                            updateService(context, true)
                        }
                    },
                    torch = torch,
                    onTorchChange = {
                        torch = it
                        Settings.setBlockTorch(context, it)
                    },
                    media = media,
                    onMediaChange = {
                        media = it
                        Settings.setBlockMedia(context, it)
                    },
                    headphones = headphones,
                    onHeadphonesChange = {
                        headphones = it
                        Settings.setBlockHeadphones(context, it)
                    },
                    unlockedScreen = unlockedScreen,
                    onUnlockedScreenChange = {
                        unlockedScreen = it
                        Settings.setBlockUnlockedScreen(context, it)
                    },
                    camera = camera,
                    onCameraChange = {
                        camera = it
                        Settings.setBlockCamera(context, it)
                    },
                    battery = battery,
                    onBatteryChange = {
                        battery = it
                    },
                    onBatteryCommit = {
                        Settings.setMinBattery(context, battery)
                        if (enabled) {
                            updateService(context, true)
                        }
                    },
                    onOpenSettings = {
                        navigate(SettingsPage.SETTINGS)
                    },
                    version = getAppVersion(context)
                )
            }

            SettingsPage.SETTINGS -> {
                SettingsScaffold(
                    language = language,
                    title = tr(
                        language,
                        "Ustawienia",
                        "Settings"
                    ),
                    onBack = ::goBack
                ) {
                    Section(
                        tr(language, "Ogólne", "General")
                    ) {
                        NavigationItem(
                            title = tr(
                                language,
                                "Powiadomienia",
                                "Notifications"
                            ),
                            subtitle = tr(
                                language,
                                "Dozwolone kategorie i powiadomienie aplikacji",
                                "Allowed categories and app notification"
                            ),
                            onClick = {
                                navigate(SettingsPage.NOTIFICATIONS)
                            }
                        )

                        NavigationItem(
                            title = tr(
                                language,
                                "Dźwięk",
                                "Sound"
                            ),
                            subtitle = tr(
                                language,
                                "Wybór strumienia audio",
                                "Audio stream selection"
                            ),
                            onClick = {
                                navigate(SettingsPage.SOUND)
                            }
                        )

                        NavigationItem(
                            title = tr(
                                language,
                                "Dźwięki i sygnały",
                                "Sounds and signals"
                            ),
                            subtitle = tr(
                                language,
                                "Dźwięki włączania i wyłączania oraz ich parametry",
                                "Enable and disable sounds and their settings"
                            ),
                            onClick = {
                                navigate(SettingsPage.SOUNDS)
                            }
                        )

                        NavigationItem(
                            title = tr(
                                language,
                                "Język",
                                "Language"
                            ),
                            subtitle = if (
                                language == Settings.LANGUAGE_ENGLISH
                            ) {
                                "English"
                            } else {
                                "Polish"
                            },
                            onClick = {
                                navigate(SettingsPage.LANGUAGE)
                            }
                        )
                    }

                    Section(
                        tr(language, "Działanie", "Operation")
                    ) {
                        Text(
                            tr(
                                language,
                                "Czułość: ${sensitivity.toInt()}%",
                                "Sensitivity: ${sensitivity.toInt()}%"
                            ),
                            color = Color.White,
                            fontWeight = FontWeight.Medium
                        )

                        Slider(
                            value = sensitivity,
                            onValueChange = {
                                sensitivity = it
                            },
                            onValueChangeFinished = {
                                Settings.setSensitivity(
                                    context,
                                    sensitivity.toInt()
                                )
                            },
                            valueRange = 0f..100f,
                            steps = 9
                        )

                        Text(
                            tr(
                                language,
                                "Niższa czułość wymaga bardziej płaskiego położenia telefonu. Wyższa czułość pozwala reagować przy większym kącie.",
                                "Lower sensitivity requires the phone to be more horizontal. Higher sensitivity allows activation at a greater angle."
                            ),
                            color = Subtle,
                            style = MaterialTheme.typography.bodySmall
                        )

                        HorizontalDivider(color = DividerColor)

                        Text(
                            tr(
                                language,
                                "Opóźnienie: ${delayValue.toInt()} ms",
                                "Delay: ${delayValue.toInt()} ms"
                            ),
                            color = Color.White,
                            fontWeight = FontWeight.Medium
                        )

                        Slider(
                            value = delayValue,
                            onValueChange = {
                                delayValue = it
                            },
                            onValueChangeFinished = {
                                Settings.setDelayMs(
                                    context,
                                    delayValue.toInt()
                                )
                            },
                            valueRange = 0f..2000f,
                            steps = 7
                        )

                        Text(
                            tr(
                                language,
                                "Czas oczekiwania przed reakcją aplikacji na zmianę położenia telefonu.",
                                "The waiting time before the app reacts to a change in phone orientation."
                            ),
                            color = Subtle,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    Section(
                        tr(
                            language,
                            "Wibracje",
                            "Vibration"
                        )
                    ) {
                        SettingSwitch(
                            tr(
                                language,
                                "Wibracja przy włączaniu DND",
                                "Vibrate when enabling DND"
                            ),
                            vibrationEnable
                        ) {
                            vibrationEnable = it
                            Settings.setVibrationOnEnable(context, it)
                        }

                        SettingSwitch(
                            tr(
                                language,
                                "Wibracja przy wyłączaniu DND",
                                "Vibrate when disabling DND"
                            ),
                            vibrationDisable
                        ) {
                            vibrationDisable = it
                            Settings.setVibrationOnDisable(context, it)
                        }
                    }

                    NavigationItem(
                        title = tr(
                            language,
                            "Informacje (About)",
                            "About"
                        ),
                        subtitle = tr(
                            language,
                            "Informacje o aplikacji",
                            "Application information"
                        ),
                        onClick = {
                            navigate(SettingsPage.ABOUT)
                        }
                    )
                }
            }

            SettingsPage.NOTIFICATIONS -> {
                SettingsScaffold(
                    language = language,
                    title = tr(
                        language,
                        "Powiadomienia",
                        "Notifications"
                    ),
                    onBack = ::goBack
                ) {
                    Section(
                        tr(
                            language,
                            "Dozwolone kategorie DND",
                            "Allowed DND categories"
                        )
                    ) {
                        Text(
                            tr(
                                language,
                                "Wybierz, które kategorie powiadomień mogą być słyszalne podczas działania trybu Nie przeszkadzać.",
                                "Choose which notification categories may be audible while Do Not Disturb is active."
                            ),
                            color = Muted,
                            style = MaterialTheme.typography.bodySmall
                        )

                        SettingSwitch(
                            tr(language, "Alarmy i budziki", "Alarms and alarm clocks"),
                            dndAlarms
                        ) {
                            dndAlarms = it
                            updateDndSetting(it) {
                                Settings.setAllowDndAlarms(context, it)
                            }
                        }

                        SettingSwitch(
                            tr(language, "Połączenia", "Calls"),
                            dndCalls
                        ) {
                            dndCalls = it
                            updateDndSetting(it) {
                                Settings.setAllowDndCalls(context, it)
                            }
                        }

                        SettingSwitch(
                            tr(
                                language,
                                "Powtarzające się połączenia",
                                "Repeat callers"
                            ),
                            dndRepeatCallers
                        ) {
                            dndRepeatCallers = it
                            updateDndSetting(it) {
                                Settings.setAllowDndRepeatCallers(context, it)
                            }
                        }

                        SettingSwitch(
                            tr(language, "Wiadomości", "Messages"),
                            dndMessages
                        ) {
                            dndMessages = it
                            updateDndSetting(it) {
                                Settings.setAllowDndMessages(context, it)
                            }
                        }

                        SettingSwitch(
                            tr(language, "Przypomnienia", "Reminders"),
                            dndReminders
                        ) {
                            dndReminders = it
                            updateDndSetting(it) {
                                Settings.setAllowDndReminders(context, it)
                            }
                        }

                        SettingSwitch(
                            tr(language, "Wydarzenia", "Events"),
                            dndEvents
                        ) {
                            dndEvents = it
                            updateDndSetting(it) {
                                Settings.setAllowDndEvents(context, it)
                            }
                        }

                        SettingSwitch(
                            tr(language, "Multimedia", "Media"),
                            dndMedia
                        ) {
                            dndMedia = it
                            updateDndSetting(it) {
                                Settings.setAllowDndMedia(context, it)
                            }
                        }

                        SettingSwitch(
                            tr(language, "Dźwięki systemowe", "System sounds"),
                            dndSystem
                        ) {
                            dndSystem = it
                            updateDndSetting(it) {
                                Settings.setAllowDndSystem(context, it)
                            }
                        }

                        Text(
                            tr(
                                language,
                                "Domyślnie dozwolone są wyłącznie alarmy i budziki. Zmiany zostaną zastosowane przy następnym włączeniu DND.",
                                "Only alarms are allowed by default. Changes will be applied the next time DND is enabled."
                            ),
                            color = Subtle,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    Section(
                        tr(
                            language,
                            "Powiadomienie o działaniu aplikacji",
                            "App activity notification"
                        )
                    ) {
                        SettingSwitch(
                            tr(
                                language,
                                "Pokazuj powiadomienie",
                                "Show notification"
                            ),
                            showStatusNotification
                        ) { value ->
                            if (value) {
                                showStatusNotification = true
                                Settings.setShowStatusNotification(
                                    context,
                                    true
                                )
                            } else {
                                showNotificationWarning = true
                            }
                        }

                        Text(
                            tr(
                                language,
                                "Powiadomienie informuje o działaniu usługi w tle. Android może nadal wymagać widocznego powiadomienia dla usługi pierwszego planu.",
                                "The notification informs you that the background service is running. Android may still require a visible foreground-service notification."
                            ),
                            color = Subtle,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }

            SettingsPage.SOUND -> {
                SettingsScaffold(
                    language = language,
                    title = tr(language, "Dźwięk", "Sound"),
                    onBack = ::goBack
                ) {
                    Section(
                        tr(language, "Strumień dźwięku", "Audio stream")
                    ) {
                        Text(
                            tr(
                                language,
                                "Wybierz kanał audio, przez który aplikacja będzie odtwarzać sygnały.",
                                "Choose the audio channel used by the app to play sounds."
                            ),
                            color = Muted,
                            style = MaterialTheme.typography.bodySmall
                        )

                        StreamChoice(
                            tr(language, "Multimedia", "Media"),
                            soundStream == Settings.STREAM_MEDIA
                        ) {
                            soundStream = Settings.STREAM_MEDIA
                            Settings.setSoundStream(context, soundStream)
                        }

                        StreamChoice(
                            tr(language, "Powiadomienia", "Notifications"),
                            soundStream == Settings.STREAM_NOTIFICATION
                        ) {
                            soundStream = Settings.STREAM_NOTIFICATION
                            Settings.setSoundStream(context, soundStream)
                        }

                        StreamChoice(
                            tr(language, "Alarmy", "Alarms"),
                            soundStream == Settings.STREAM_ALARM
                        ) {
                            soundStream = Settings.STREAM_ALARM
                            Settings.setSoundStream(context, soundStream)
                        }
                    }
                }
            }

            SettingsPage.SOUNDS -> {
                SettingsScaffold(
                    language = language,
                    title = tr(
                        language,
                        "Dźwięki i sygnały",
                        "Sounds and signals"
                    ),
                    onBack = ::goBack
                ) {
                    Section(
                        tr(language, "Dźwięki DND", "DND sounds")
                    ) {
                        SettingSwitch(
                            tr(
                                language,
                                "Odtwórz dźwięk przy włączaniu DND",
                                "Play a sound when enabling DND"
                            ),
                            soundEnable
                        ) {
                            soundEnable = it
                            Settings.setSoundOnEnable(context, it)
                        }

                        NavigationItem(
                            title = tr(
                                language,
                                "Dźwięk włączania",
                                "Enable sound"
                            ),
                            subtitle = getSelectedSoundName(
                                context,
                                Settings.soundOnType(context),
                                Settings.soundOnUri(context),
                                Settings.soundOnCustomFile(context),
                                soundTone,
                                language
                            ),
                            onClick = {
                                navigate(SettingsPage.SOUND_ENABLE)
                            }
                        )

                        HorizontalDivider(color = DividerColor)

                        SettingSwitch(
                            tr(
                                language,
                                "Odtwórz dźwięk przy wyłączaniu DND",
                                "Play a sound when disabling DND"
                            ),
                            soundDisable
                        ) {
                            soundDisable = it
                            Settings.setSoundOnDisable(context, it)
                        }

                        NavigationItem(
                            title = tr(
                                language,
                                "Dźwięk wyłączania",
                                "Disable sound"
                            ),
                            subtitle = getSelectedSoundName(
                                context,
                                Settings.soundOffType(context),
                                Settings.soundOffUri(context),
                                Settings.soundOffCustomFile(context),
                                soundTone,
                                language
                            ),
                            onClick = {
                                navigate(SettingsPage.SOUND_DISABLE)
                            }
                        )
                    }

                    // Pozostaje wspólny wybór rodzaju domyślnego sygnału.
                    // Głośność jest teraz konfigurowana osobno na podstronach.
                    Section(
                        tr(
                            language,
                            "Ustawienia sygnału",
                            "Signal settings"
                        )
                    ) {
                        Text(
                            tr(
                                language,
                                "Rodzaj domyślnego sygnału",
                                "Default sound tone"
                            ),
                            color = Color.White,
                            fontWeight = FontWeight.Medium
                        )

                        val tones = if (
                            language == Settings.LANGUAGE_ENGLISH
                        ) {
                            listOf("Short", "Confirm", "Double")
                        } else {
                            listOf("Krótki", "Potwierdzenie", "Podwójny")
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            tones.forEachIndexed { index, label ->
                                FilterChip(
                                    selected = soundTone == index,
                                    onClick = {
                                        soundTone = index
                                        Settings.setSoundTone(context, index)
                                    },
                                    label = { Text(label) }
                                )
                            }
                        }
                    }
                }
            }

            SettingsPage.SOUND_ENABLE,
            SettingsPage.SOUND_DISABLE -> {
                val target = if (
                    currentPage == SettingsPage.SOUND_ENABLE
                ) {
                    SoundTarget.ENABLE
                } else {
                    SoundTarget.DISABLE
                }

                val selectedType = if (
                    target == SoundTarget.ENABLE
                ) {
                    Settings.soundOnType(context)
                } else {
                    Settings.soundOffType(context)
                }

                val selectedUri = if (
                    target == SoundTarget.ENABLE
                ) {
                    Settings.soundOnUri(context)
                } else {
                    Settings.soundOffUri(context)
                }

                val selectedFile = if (
                    target == SoundTarget.ENABLE
                ) {
                    Settings.soundOnCustomFile(context)
                } else {
                    Settings.soundOffCustomFile(context)
                }

                val selectedVolume = if (
                    target == SoundTarget.ENABLE
                ) {
                    soundOnVolume
                } else {
                    soundOffVolume
                }

                SettingsScaffold(
                    language = language,
                    title = if (target == SoundTarget.ENABLE) {
                        tr(
                            language,
                            "Dźwięk włączania",
                            "Enable sound"
                        )
                    } else {
                        tr(
                            language,
                            "Dźwięk wyłączania",
                            "Disable sound"
                        )
                    },
                    onBack = ::goBack
                ) {
                    SoundConfiguration(
                        language = language,
                        selectedType = selectedType,
                        selectedName = getSelectedSoundName(
                            context,
                            selectedType,
                            selectedUri,
                            selectedFile,
                            soundTone,
                            language
                        ),
                        volume = selectedVolume,
                        onVolumeChange = { value ->
                            if (target == SoundTarget.ENABLE) {
                                soundOnVolume = value
                            } else {
                                soundOffVolume = value
                            }
                        },
                        onVolumeCommit = {
                            if (target == SoundTarget.ENABLE) {
                                Settings.setSoundOnVolume(
                                    context,
                                    soundOnVolume
                                )
                            } else {
                                Settings.setSoundOffVolume(
                                    context,
                                    soundOffVolume
                                )
                            }
                        },
                        onDefault = {
                            if (target == SoundTarget.ENABLE) {
                                Settings.setSoundOnType(
                                    context,
                                    Settings.SOUND_DEFAULT
                                )
                            } else {
                                Settings.setSoundOffType(
                                    context,
                                    Settings.SOUND_DEFAULT
                                )
                            }

                            refreshSounds++
                        },
                        onSystem = {
                            openSystemSoundPicker(target)
                        },
                        onCustom = {
                            openCustomSoundPicker(target)
                        },
                        onPreview = {
                            previewSound(target)
                        },
                        refreshKey = refreshSounds
                    )
                }
            }

            SettingsPage.LANGUAGE -> {
                SettingsScaffold(
                    language = language,
                    title = tr(
                        language,
                        "Język",
                        "Language"
                    ),
                    onBack = ::goBack
                ) {
                    Section(
                        tr(
                            language,
                            "Język aplikacji",
                            "Application language"
                        )
                    ) {
                        LanguageChoice(
                            label = "Polish",
                            selected = language == Settings.LANGUAGE_POLISH
                        ) {
                            language = Settings.LANGUAGE_POLISH
                            Settings.setLanguage(
                                context,
                                Settings.LANGUAGE_POLISH
                            )
                        }

                        LanguageChoice(
                            label = "English",
                            selected = language == Settings.LANGUAGE_ENGLISH
                        ) {
                            language = Settings.LANGUAGE_ENGLISH
                            Settings.setLanguage(
                                context,
                                Settings.LANGUAGE_ENGLISH
                            )
                        }
                    }

                    Text(
                        tr(
                            language,
                            "Wybrany język zostanie zapamiętany i będzie używany również po ponownym uruchomieniu aplikacji.",
                            "Your selected language will be saved and used after restarting the application."
                        ),
                        color = Muted,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            SettingsPage.ABOUT -> {
                SettingsScaffold(
                    language = language,
                    title = tr(
                        language,
                        "Informacje",
                        "About"
                    ),
                    onBack = ::goBack
                ) {
                    // Pusta podstrona przygotowana do przyszłej rozbudowy.
                }
            }
        }

        if (showNotificationWarning) {
            AlertDialog(
                onDismissRequest = {
                    showNotificationWarning = false
                },
                title = {
                    Text(
                        tr(
                            language,
                            "Wyłączyć powiadomienie?",
                            "Disable notification?"
                        )
                    )
                },
                text = {
                    Text(
                        tr(
                            language,
                            "Wyłączenie powiadomienia może wpłynąć na działanie aplikacji w tle. Android może nadal wymagać widocznego powiadomienia usługi pierwszego planu.",
                            "Disabling this notification may affect background operation. Android may still require a visible foreground-service notification."
                        )
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showStatusNotification = false
                            Settings.setShowStatusNotification(
                                context,
                                false
                            )
                            showNotificationWarning = false
                        }
                    ) {
                        Text(
                            tr(language, "Wyłącz", "Disable")
                        )
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            showNotificationWarning = false
                        }
                    ) {
                        Text(
                            tr(language, "Anuluj", "Cancel")
                        )
                    }
                },
                containerColor = Panel,
                titleContentColor = Color.White,
                textContentColor = Muted
            )
        }

        if (showSupportDialog) {
            AlertDialog(
                onDismissRequest = {
                    showSupportDialog = false
                },
                title = {
                    Text(
                        tr(
                            language,
                            "Rozważ wsparcie projektu",
                            "Consider supporting the project"
                        )
                    )
                },
                text = {
                    Text(
                        tr(
                            language,
                            "Jeśli Flip Silence jest dla Ciebie przydatny, rozważ wsparcie dalszego rozwoju projektu.",
                            "If Flip Silence is useful to you, consider supporting the continued development of the project."
                        )
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = { },
                        enabled = false
                    ) {
                        Text(
                            tr(language, "Wesprzyj", "Support")
                        )
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            showSupportDialog = false
                        }
                    ) {
                        Text(
                            tr(language, "Anuluj", "Cancel")
                        )
                    }
                },
                containerColor = Panel,
                titleContentColor = Color.White,
                textContentColor = Muted
            )
        }
    }

    LaunchedEffect(Unit) {
        permission = hasDndAccess(context)
    }

    LaunchedEffect(currentPage) {
        if (currentPage == SettingsPage.HOME) {
            permission = hasDndAccess(context)
        }
    }
}

@Composable
private fun MainHomeScreen(
    language: String,
    enabled: Boolean,
    onEnabledChange: (Boolean) -> Unit,
    permission: Boolean,
    onOpenPermission: () -> Unit,
    schedule: Boolean,
    onScheduleChange: (Boolean) -> Unit,
    start: Int,
    end: Int,
    onStartChange: (Int) -> Unit,
    onEndChange: (Int) -> Unit,
    days: Int,
    onDaysChange: (Int) -> Unit,
    torch: Boolean,
    onTorchChange: (Boolean) -> Unit,
    media: Boolean,
    onMediaChange: (Boolean) -> Unit,
    headphones: Boolean,
    onHeadphonesChange: (Boolean) -> Unit,
    unlockedScreen: Boolean,
    onUnlockedScreenChange: (Boolean) -> Unit,
    camera: Boolean,
    onCameraChange: (Boolean) -> Unit,
    battery: Int,
    onBatteryChange: (Int) -> Unit,
    onBatteryCommit: () -> Unit,
    onOpenSettings: () -> Unit,
    version: String
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "FLIP SILENCE",
                color = Accent,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )

            TextButton(onClick = onOpenSettings) {
                Text(
                    "⚙",
                    color = Accent,
                    style = MaterialTheme.typography.headlineMedium
                )
            }
        }

        Text(
            tr(
                language,
                "Cisza jednym\nodwróceniem.",
                "Silence with a\nsingle flip."
            ),
            color = Color.White,
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Bold
        )

        Text(
            tr(
                language,
                "Odwróć telefon ekranem do dołu, aby włączyć Nie przeszkadzać. Odwróć go ekranem do góry, aby przywrócić poprzedni stan.",
                "Turn your phone face down to enable Do Not Disturb. Turn it face up to restore the previous state."
            ),
            color = Muted
        )

        Section(
            tr(language, "Automatyzacja", "Automation")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        tr(language, "Automatyzacja", "Automation"),
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold
                    )

                    Text(
                        if (enabled) {
                            tr(
                                language,
                                "Monitorowanie położenia aktywne",
                                "Orientation monitoring is active"
                            )
                        } else {
                            tr(
                                language,
                                "Automatyzacja wyłączona",
                                "Automation is disabled"
                            )
                        },
                        color = Muted,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Switch(
                    checked = enabled,
                    onCheckedChange = onEnabledChange
                )
            }

            Button(
                onClick = onOpenPermission,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    if (permission) {
                        tr(
                            language,
                            "Uprawnienie DND: przyznane",
                            "DND permission: granted"
                        )
                    } else {
                        tr(
                            language,
                            "Nadaj dostęp do Nie przeszkadzać",
                            "Grant Do Not Disturb access"
                        )
                    }
                )
            }

            Text(
                tr(
                    language,
                    "Usługa działa jako widoczne powiadomienie, aby Android nie usypiał monitorowania czujnika.",
                    "The service uses a visible notification to help Android keep sensor monitoring active."
                ),
                color = Subtle,
                style = MaterialTheme.typography.bodySmall
            )
        }

        Section(
            tr(language, "Harmonogram", "Schedule")
        ) {
            SettingSwitch(
                tr(
                    language,
                    "Ogranicz działanie do godzin",
                    "Limit operation to specific hours"
                ),
                schedule,
                onScheduleChange
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TimeButton(
                    tr(language, "Od", "From"),
                    start,
                    Modifier.weight(1f),
                    onStartChange
                )

                TimeButton(
                    tr(language, "Do", "To"),
                    end,
                    Modifier.weight(1f),
                    onEndChange
                )
            }

            Text(
                tr(language, "Dni tygodnia", "Days of the week"),
                color = Color.White,
                fontWeight = FontWeight.Medium
            )

            val names = if (
                language == Settings.LANGUAGE_ENGLISH
            ) {
                listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
            } else {
                listOf("Pn", "Wt", "Śr", "Cz", "Pt", "Sb", "Nd")
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                names.forEachIndexed { index, name ->
                    val bit = 1 shl index

                    FilterChip(
                        selected = days and bit != 0,
                        onClick = {
                            onDaysChange(days xor bit)
                        },
                        label = { Text(name) }
                    )
                }
            }

            Text(
                tr(
                    language,
                    "Harmonogram dotyczy momentu aktywacji. Gdy okno czasowe się kończy, aplikacja przywraca poprzedni stan DND.",
                    "The schedule controls when automation may activate. When the time window ends, the app restores the previous DND state."
                ),
                color = Subtle,
                style = MaterialTheme.typography.bodySmall
            )
        }

        Section(
            tr(
                language,
                "Warunki wykluczające",
                "Exclusion conditions"
            )
        ) {
            SettingSwitch(
                tr(
                    language,
                    "Nie działaj, gdy latarka jest włączona",
                    "Do not activate while the flashlight is on"
                ),
                torch,
                onTorchChange
            )

            SettingSwitch(
                tr(
                    language,
                    "Nie działaj podczas odtwarzania multimediów",
                    "Do not activate during media playback"
                ),
                media,
                onMediaChange
            )

            SettingSwitch(
                tr(
                    language,
                    "Nie działaj, gdy podłączone są słuchawki",
                    "Do not activate when headphones are connected"
                ),
                headphones,
                onHeadphonesChange
            )

            SettingSwitch(
                tr(
                    language,
                    "Nie działaj, gdy ekran jest odblokowany",
                    "Do not activate while the screen is unlocked"
                ),
                unlockedScreen,
                onUnlockedScreenChange
            )

            SettingSwitch(
                tr(
                    language,
                    "Nie działaj podczas używania aparatu",
                    "Do not activate while the camera is in use"
                ),
                camera,
                onCameraChange
            )

            Text(
                tr(
                    language,
                    "Minimalny poziom baterii: $battery% (0 = bez ograniczenia)",
                    "Minimum battery level: $battery% (0 = no limit)"
                ),
                color = Color.White
            )

            Slider(
                value = battery.toFloat(),
                onValueChange = {
                    onBatteryChange(it.toInt())
                },
                onValueChangeFinished = onBatteryCommit,
                valueRange = 0f..50f,
                steps = 9
            )
        }

        Text(
            "Version $version • Flip Silence",
            color = Color(0xFF718096),
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

@Composable
private fun SettingsScaffold(
    language: String,
    title: String,
    onBack: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) {
                Text(
                    "‹  ${tr(language, "Wróć", "Back")}",
                    color = Accent
                )
            }

            Spacer(Modifier.weight(1f))

            Text(
                "FLIP SILENCE",
                color = Accent,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelLarge
            )
        }

        Text(
            title,
            color = Color.White,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )

        content()

        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun SoundConfiguration(
    language: String,
    selectedType: String,
    selectedName: String,
    volume: Int,
    onVolumeChange: (Int) -> Unit,
    onVolumeCommit: () -> Unit,
    onDefault: () -> Unit,
    onSystem: () -> Unit,
    onCustom: () -> Unit,
    onPreview: () -> Unit,
    refreshKey: Int
) {
    key(refreshKey) {
        Section(
            tr(language, "Wybrany dźwięk", "Selected sound")
        ) {
            Text(
                selectedName,
                color = Accent,
                fontWeight = FontWeight.SemiBold
            )

            HorizontalDivider(color = DividerColor)

            SoundTypeChoice(
                tr(
                    language,
                    "Domyślny sygnał aplikacji",
                    "Default app sound"
                ),
                selectedType == Settings.SOUND_DEFAULT,
                onDefault
            )

            SoundTypeChoice(
                tr(
                    language,
                    "Dźwięk systemowy",
                    "System sound"
                ),
                selectedType == Settings.SOUND_SYSTEM,
                onSystem
            )

            SoundTypeChoice(
                tr(
                    language,
                    "Własny plik audio",
                    "Custom audio file"
                ),
                selectedType == Settings.SOUND_CUSTOM,
                onCustom
            )

            HorizontalDivider(color = DividerColor)

            Text(
                tr(
                    language,
                    "Głośność: $volume%",
                    "Volume: $volume%"
                ),
                color = Color.White,
                fontWeight = FontWeight.Medium
            )

            Slider(
                value = volume.toFloat(),
                onValueChange = {
                    onVolumeChange(it.toInt())
                },
                onValueChangeFinished = onVolumeCommit,
                valueRange = 0f..100f,
                steps = 9
            )

            OutlinedButton(
                onClick = onPreview,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    tr(language, "Odsłuchaj", "Preview")
                )
            }
        }

        Text(
            tr(
                language,
                "Wybierz dźwięk domyślny, systemowy albo własny plik audio. Ustawienia dźwięku i głośności włączania i wyłączania są niezależne.",
                "Choose the default sound, a system sound, or your own audio file. Enable and disable sound and volume settings are independent."
            ),
            color = Subtle,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun NavigationItem(
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF26364D)
        ),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    title,
                    color = Color.White,
                    fontWeight = FontWeight.Medium
                )

                Text(
                    subtitle,
                    color = Muted,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Text(
                "›",
                color = Accent,
                style = MaterialTheme.typography.headlineMedium
            )
        }
    }
}

@Composable
private fun SoundTypeChoice(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            color = Color.White,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodyMedium
        )

        RadioButton(
            selected = selected,
            onClick = onClick
        )
    }
}

@Composable
private fun StreamChoice(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            color = Color.White,
            modifier = Modifier.weight(1f)
        )

        RadioButton(
            selected = selected,
            onClick = onClick
        )
    }
}

@Composable
private fun LanguageChoice(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            color = Color.White,
            modifier = Modifier.weight(1f)
        )

        RadioButton(
            selected = selected,
            onClick = onClick
        )
    }
}

@Composable
private fun Section(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = Panel
        ),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(
            Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                title,
                color = Accent,
                fontWeight = FontWeight.Bold
            )

            content()
        }
    }
}

@Composable
private fun SettingSwitch(
    label: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            color = Color.White,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodyMedium
        )

        Switch(
            checked = checked,
            onCheckedChange = onChange
        )
    }
}

@Composable
private fun TimeButton(
    label: String,
    minutes: Int,
    modifier: Modifier = Modifier,
    onSet: (Int) -> Unit
) {
    val context = LocalContext.current

    OutlinedButton(
        modifier = modifier,
        onClick = {
            TimePickerDialog(
                context,
                { _, hour, minute ->
                    onSet(hour * 60 + minute)
                },
                minutes / 60,
                minutes % 60,
                true
            ).show()
        }
    ) {
        Text(
            "$label  ${
                String.format(
                    Locale.getDefault(),
                    "%02d:%02d",
                    minutes / 60,
                    minutes % 60
                )
            }"
        )
    }
}

private fun getSelectedSoundName(
    context: Context,
    type: String,
    uri: String?,
    customFile: String?,
    toneIndex: Int,
    language: String
): String {
    return when (type) {
        Settings.SOUND_DEFAULT -> {
            val toneName = when (toneIndex) {
                1 -> tr(language, "Potwierdzenie", "Confirm")
                2 -> tr(language, "Podwójny", "Double")
                else -> tr(language, "Krótki", "Short")
            }

            tr(
                language,
                "Domyślny sygnał ($toneName)",
                "Default sound ($toneName)"
            )
        }

        Settings.SOUND_SYSTEM -> {
            if (uri.isNullOrBlank()) {
                tr(
                    language,
                    "Nie wybrano dźwięku systemowego",
                    "No system sound selected"
                )
            } else {
                try {
                    RingtoneManager.getRingtone(
                        context,
                        Uri.parse(uri)
                    )?.getTitle(context)
                        ?: tr(
                            language,
                            "Dźwięk systemowy",
                            "System sound"
                        )
                } catch (_: Exception) {
                    tr(
                        language,
                        "Dźwięk systemowy",
                        "System sound"
                    )
                }
            }
        }

        Settings.SOUND_CUSTOM -> {
            if (customFile.isNullOrBlank()) {
                tr(
                    language,
                    "Nie wybrano pliku audio",
                    "No audio file selected"
                )
            } else {
                customFile
            }
        }

        else -> tr(
            language,
            "Nieznany dźwięk",
            "Unknown sound"
        )
    }
}

private fun tr(
    language: String,
    polish: String,
    english: String
): String {
    return if (
        language == Settings.LANGUAGE_ENGLISH
    ) {
        english
    } else {
        polish
    }
}

private fun getAppVersion(context: Context): String {
    return try {
        val packageInfo = context.packageManager.getPackageInfo(
            context.packageName,
            0
        )

        packageInfo.versionName ?: "Unknown"
    } catch (_: Exception) {
        "Unknown"
    }
}

private fun hasDndAccess(context: Context): Boolean {
    val notificationManager =
        context.getSystemService(
            Context.NOTIFICATION_SERVICE
        ) as NotificationManager

    return notificationManager.isNotificationPolicyAccessGranted
}

private fun updateService(
    context: Context,
    start: Boolean
) {
    val intent = Intent(
        context,
        FlipMonitorService::class.java
    )

    if (start) {
        ContextCompat.startForegroundService(
            context,
            intent
        )
    } else {
        context.stopService(intent)
    }
}

private fun playSelectedSound(
    context: Context,
    type: String,
    uri: String?,
    customFile: String?,
    toneIndex: Int,
    volume: Int,
    stream: String,
    language: String
) {
    if (volume <= 0) {
        return
    }

    val audioUsage = when (stream) {
        Settings.STREAM_NOTIFICATION ->
            AudioAttributes.USAGE_NOTIFICATION

        Settings.STREAM_ALARM ->
            AudioAttributes.USAGE_ALARM

        else ->
            AudioAttributes.USAGE_MEDIA
    }

    if (type == Settings.SOUND_DEFAULT) {
        val tone = when (toneIndex) {
            1 -> ToneGenerator.TONE_PROP_ACK
            2 -> ToneGenerator.TONE_PROP_BEEP2
            else -> ToneGenerator.TONE_PROP_BEEP
        }

        val audioStream = when (stream) {
            Settings.STREAM_NOTIFICATION ->
                AudioManager.STREAM_NOTIFICATION

            Settings.STREAM_ALARM ->
                AudioManager.STREAM_ALARM

            else ->
                AudioManager.STREAM_MUSIC
        }

        try {
            val generator = ToneGenerator(
                audioStream,
                volume.coerceIn(0, 100)
            )

            generator.startTone(tone, 650)

            Handler(Looper.getMainLooper()).postDelayed({
                try {
                    generator.release()
                } catch (_: Exception) {
                }
            }, 900L)

        } catch (_: Exception) {
        }

        return
    }

    val soundUri: Uri? = when (type) {
        Settings.SOUND_SYSTEM -> {
            uri?.let {
                try {
                    Uri.parse(it)
                } catch (_: Exception) {
                    null
                }
            }
        }

        Settings.SOUND_CUSTOM -> {
            if (customFile.isNullOrBlank()) {
                null
            } else {
                val file = File(
                    File(context.filesDir, "sounds"),
                    customFile
                )

                if (file.exists()) {
                    Uri.fromFile(file)
                } else {
                    null
                }
            }
        }

        else -> null
    }

    if (soundUri == null) {
        Toast.makeText(
            context,
            tr(
                language,
                "Nie wybrano dźwięku lub plik nie istnieje.",
                "No sound selected or the file does not exist."
            ),
            Toast.LENGTH_SHORT
        ).show()

        return
    }

    try {
        val player = MediaPlayer()

        player.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(audioUsage)
                .setContentType(
                    AudioAttributes.CONTENT_TYPE_SONIFICATION
                )
                .build()
        )

        val normalizedVolume =
            volume.coerceIn(0, 100) / 100f

        player.setVolume(
            normalizedVolume,
            normalizedVolume
        )

        player.setDataSource(
            context,
            soundUri
        )

        player.setOnPreparedListener {
            it.start()
        }

        player.setOnCompletionListener {
            it.release()
        }

        player.setOnErrorListener { mediaPlayer, _, _ ->
            mediaPlayer.release()
            true
        }

        player.prepareAsync()

    } catch (_: Exception) {
        Toast.makeText(
            context,
            tr(
                language,
                "Nie udało się odtworzyć wybranego dźwięku.",
                "Could not play the selected sound."
            ),
            Toast.LENGTH_LONG
        ).show()
    }
}