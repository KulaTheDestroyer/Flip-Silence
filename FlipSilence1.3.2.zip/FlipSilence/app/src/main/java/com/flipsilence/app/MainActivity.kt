package com.flipsilence.app

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings as AndroidSettings
import android.provider.MediaStore
import android.content.ContentUris
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import kotlinx.coroutines.delay
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

private val Bg = Color(0xFF101827)
private val HeaderNavy = Color(0xFF071A3D)
private val Panel = Color(0xFF1D2A3D)
private val Accent = Color(0xFF9BAEFF)
private val Muted = Color(0xFFB8C4D6)
private val Subtle = Color(0xFF9EADC2)
private val DividerColor = Color(0xFF34445B)
private const val SUPPORT_URL = "https://buymeacoffee.com/kulathedestroyer"

private enum class SoundTarget {
    ENABLE,
    DISABLE
}

private data class AudioFileItem(
    val uri: Uri,
    val name: String,
    val folder: String
)

private enum class SettingsPage {
    HOME,
    SETTINGS,
    NOTIFICATIONS,
    EXCLUSIONS,
    SOUNDS,
    SOUND_ENABLE,
    SOUND_DISABLE,
    CUSTOM_BROWSER,
    ABOUT
}

private class SoundPreviewController(private val context: Context) {
    private var player: MediaPlayer? = null
    private var toneGenerator: ToneGenerator? = null
    private val handler = Handler(Looper.getMainLooper())
    private var toneRelease: Runnable? = null

    fun stop() {
        toneRelease?.let(handler::removeCallbacks)
        toneRelease = null
        runCatching { toneGenerator?.stopTone() }
        runCatching { toneGenerator?.release() }
        toneGenerator = null
        runCatching { player?.stop() }
        runCatching { player?.release() }
        player = null
    }

    fun play(type: String, customFile: String?, toneIndex: Int, volume: Int, stream: String, language: String) {
        stop()
        if (volume <= 0) return
        val audioUsage = when (stream) {
            Settings.STREAM_NOTIFICATION -> AudioAttributes.USAGE_NOTIFICATION
            Settings.STREAM_ALARM -> AudioAttributes.USAGE_ALARM
            else -> AudioAttributes.USAGE_MEDIA
        }
        if (type == Settings.SOUND_DEFAULT) {
            val audioStream = when (stream) {
                Settings.STREAM_NOTIFICATION -> AudioManager.STREAM_NOTIFICATION
                Settings.STREAM_ALARM -> AudioManager.STREAM_ALARM
                else -> AudioManager.STREAM_MUSIC
            }
            val tone = when (toneIndex) {
                1 -> ToneGenerator.TONE_PROP_ACK
                2 -> ToneGenerator.TONE_PROP_BEEP2
                else -> ToneGenerator.TONE_PROP_BEEP
            }
            runCatching {
                val generator = ToneGenerator(audioStream, volume.coerceIn(0, 100))
                toneGenerator = generator
                generator.startTone(tone, 650)
                val release = Runnable {
                    runCatching { generator.release() }
                    if (toneGenerator === generator) toneGenerator = null
                    toneRelease = null
                }
                toneRelease = release
                handler.postDelayed(release, 900L)
            }
            return
        }
        val soundUri = when (type) {
            Settings.SOUND_NOTIFICATION -> runCatching {
                RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_NOTIFICATION)
            }.getOrNull()
            Settings.SOUND_CUSTOM -> customFile?.takeIf { it.isNotBlank() }?.let {
                File(File(context.filesDir, "sounds"), it).takeIf(File::exists)?.let { Uri.fromFile(it) }
            }
            else -> null
        }
        if (soundUri == null) {
            Toast.makeText(context, tr(language, "Nie wybrano dźwięku lub plik nie istnieje.", "No sound selected or the file does not exist."), Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val newPlayer = MediaPlayer()
            player = newPlayer
            newPlayer.setAudioAttributes(AudioAttributes.Builder().setUsage(audioUsage).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            val normalized = volume.coerceIn(0, 100) / 100f
            newPlayer.setVolume(normalized, normalized)
            newPlayer.setDataSource(context, soundUri)
            newPlayer.setOnPreparedListener { prepared ->
                if (player === prepared) prepared.start() else runCatching { prepared.release() }
            }
            newPlayer.setOnCompletionListener { completed ->
                if (player === completed) player = null
                runCatching { completed.release() }
            }
            newPlayer.setOnErrorListener { failed, _, _ ->
                if (player === failed) player = null
                runCatching { failed.release() }
                true
            }
            newPlayer.prepareAsync()
        } catch (_: Exception) {
            stop()
            Toast.makeText(context, tr(language, "Nie udało się odtworzyć wybranego dźwięku.", "Could not play the selected sound."), Toast.LENGTH_LONG).show()
        }
    }
}

class MainActivity : ComponentActivity() {

    private val notificationPermission =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        if (
            Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(
                Manifest.permission.POST_NOTIFICATIONS
            )
        }

        setContent {
            FlipSilenceScreen()
        }
    }
}

@Composable
private fun FlipSilenceScreen() {
    val context = LocalContext.current

    var language by remember {
        mutableStateOf(Settings.language(context))
    }

    val navigation = remember {
        mutableStateListOf(SettingsPage.HOME)
    }

    val currentPage = navigation.last()
    val settingsScrollStates = remember { mutableMapOf<SettingsPage, ScrollState>() }
    fun scrollStateFor(page: SettingsPage) =
        settingsScrollStates.getOrPut(page) { ScrollState(0) }

    var navigatingForward by remember { mutableStateOf(true) }

    fun navigate(page: SettingsPage) {
        if (navigation.lastOrNull() != page) {
            navigatingForward = true
            navigation.add(page)
        }
    }

    fun goBack() {
        if (navigation.size > 1) {
            navigatingForward = false
            navigation.removeAt(navigation.lastIndex)
        }
    }

    var enabled by remember {
        mutableStateOf(Settings.enabled(context))
    }

    var schedule by remember {
        mutableStateOf(Settings.scheduleEnabled(context))
    }

    var start by remember {
        mutableIntStateOf(Settings.startMinute(context))
    }

    var end by remember {
        mutableIntStateOf(Settings.endMinute(context))
    }

    var days by remember {
        mutableIntStateOf(Settings.daysMask(context))
    }

    var delayValue by remember {
        mutableFloatStateOf(Settings.delayMs(context).toFloat())
    }

    var sensitivity by remember {
        mutableFloatStateOf(Settings.sensitivity(context).toFloat())
    }

    var torch by remember {
        mutableStateOf(Settings.blockTorch(context))
    }

    var media by remember {
        mutableStateOf(Settings.blockMedia(context))
    }

    var headphones by remember {
        mutableStateOf(Settings.blockHeadphones(context))
    }

    var unlockedScreen by remember {
        mutableStateOf(Settings.blockUnlockedScreen(context))
    }

    var camera by remember {
        mutableStateOf(Settings.blockCamera(context))
    }

    var battery by remember {
        mutableIntStateOf(Settings.minBattery(context))
    }

    var permission by remember {
        mutableStateOf(hasDndAccess(context))
    }

    var showDndPermissionDialog by remember { mutableStateOf(false) }
    var pendingEnableAfterPermission by remember { mutableStateOf(false) }

    var dndAlarms by remember {
        mutableStateOf(Settings.allowDndAlarms(context))
    }

    var dndCalls by remember {
        mutableStateOf(Settings.allowDndCalls(context))
    }

    var dndRepeatCallers by remember {
        mutableStateOf(Settings.allowDndRepeatCallers(context))
    }

    var dndMessages by remember {
        mutableStateOf(Settings.allowDndMessages(context))
    }

    var dndReminders by remember {
        mutableStateOf(Settings.allowDndReminders(context))
    }

    var dndEvents by remember {
        mutableStateOf(Settings.allowDndEvents(context))
    }

    var dndMedia by remember {
        mutableStateOf(Settings.allowDndMedia(context))
    }

    var dndSystem by remember {
        mutableStateOf(Settings.allowDndSystem(context))
    }

    var soundEnable by remember {
        mutableStateOf(Settings.soundOnEnable(context))
    }

    var soundDisable by remember {
        mutableStateOf(Settings.soundOnDisable(context))
    }

    // Niezależna głośność dźwięku włączania i wyłączania DND.
    var soundOnVolume by remember {
        mutableIntStateOf(Settings.soundOnVolume(context))
    }

    var soundOffVolume by remember {
        mutableIntStateOf(Settings.soundOffVolume(context))
    }

    var soundStream by remember {
        mutableStateOf(Settings.soundStream(context))
    }

    var vibrationEnable by remember {
        mutableStateOf(Settings.vibrationOnEnable(context))
    }

    var vibrationDisable by remember {
        mutableStateOf(Settings.vibrationOnDisable(context))
    }

    var showLanguageDialog by remember { mutableStateOf(false) }
    var showVibrationDialog by remember { mutableStateOf(false) }
    var showStreamDialog by remember { mutableStateOf(false) }
    var draftVibrationEnable by remember { mutableStateOf(vibrationEnable) }
    var draftVibrationDisable by remember { mutableStateOf(vibrationDisable) }
    var soundOnType by remember { mutableStateOf(Settings.soundOnType(context)) }
    var soundOffType by remember { mutableStateOf(Settings.soundOffType(context)) }

    var showStatusNotification by remember {
        mutableStateOf(Settings.showStatusNotification(context))
    }

    var showNotificationWarning by remember {
        mutableStateOf(false)
    }

    var refreshSounds by remember {
        mutableIntStateOf(0)
    }

    var audioFiles by remember { mutableStateOf<List<AudioFileItem>>(emptyList()) }
    var selectedAudio by remember { mutableStateOf<Uri?>(null) }
    var selectedAudioFolder by remember { mutableStateOf("") }
    var audioPreview by remember { mutableStateOf<MediaPlayer?>(null) }
    val soundPreviewController = remember(context) { SoundPreviewController(context) }

    BackHandler(enabled = navigation.size > 1) {
        if (currentPage == SettingsPage.CUSTOM_BROWSER && selectedAudioFolder.isNotBlank()) {
            runCatching { audioPreview?.stop() }
            runCatching { audioPreview?.release() }
            audioPreview = null
            selectedAudioFolder = selectedAudioFolder.substringBeforeLast("/", "")
            selectedAudio = null
        } else {
            goBack()
        }
    }

    DisposableEffect(currentPage) {
        onDispose {
            if (currentPage == SettingsPage.CUSTOM_BROWSER) {
                runCatching { audioPreview?.stop() }
                runCatching { audioPreview?.release() }
                audioPreview = null
            }
            if (currentPage == SettingsPage.SOUND_ENABLE || currentPage == SettingsPage.SOUND_DISABLE) {
                soundPreviewController.stop()
            }
        }
    }

    var pendingSoundTarget by remember {
        mutableStateOf(SoundTarget.ENABLE)
    }

    var showSupportDialog by remember {
        mutableStateOf(false)
    }

    var showChangelog by remember {
        mutableStateOf(false)
    }

    var showToneDialog by remember { mutableStateOf(false) }
    var pendingTone by remember { mutableIntStateOf(0) }

    val changelogText = remember {
        runCatching {
            context.assets.open("CHANGELOG.md").bufferedReader().use { it.readText() }
        }.getOrElse {
            "Changelog is unavailable."
        }
    }

    LaunchedEffect(Unit) {
        delay(5000L)
        showSupportDialog = true
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            audioFiles = loadAudioFiles(context)
            navigate(SettingsPage.CUSTOM_BROWSER)
        } else {
            Toast.makeText(
                context,
                tr(language, "Dostęp do plików audio nie został przyznany.", "Audio access was not granted."),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    fun openSystemSoundPicker(target: SoundTarget) {
        // This source always reads Android's current default notification URI.
        // It never launches the system ringtone picker or changes device settings.
        if (target == SoundTarget.ENABLE) {
            soundOnType = Settings.SOUND_NOTIFICATION
            Settings.setSoundOnType(context, soundOnType)
        } else {
            soundOffType = Settings.SOUND_NOTIFICATION
            Settings.setSoundOffType(context, soundOffType)
        }
        refreshSounds++
    }

    fun openCustomSoundPicker(target: SoundTarget) {
        pendingSoundTarget = target
        selectedAudio = null
        selectedAudioFolder = ""
        val permissionName = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (
            ContextCompat.checkSelfPermission(context, permissionName) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            audioFiles = loadAudioFiles(context)
            navigate(SettingsPage.CUSTOM_BROWSER)
        } else {
            audioPermissionLauncher.launch(permissionName)
        }
    }

    fun startAudioPreview(uri: Uri) {
        try {
            runCatching { audioPreview?.stop() }
            runCatching { audioPreview?.release() }
            audioPreview = MediaPlayer().apply {
                setDataSource(context, uri)
                setOnPreparedListener { it.start() }
                setOnCompletionListener {
                    it.release()
                    audioPreview = null
                }
                setOnErrorListener { player, _, _ ->
                    player.release()
                    audioPreview = null
                    true
                }
                prepareAsync()
            }
        } catch (_: Exception) {
            runCatching { audioPreview?.release() }
            audioPreview = null
            Toast.makeText(
                context,
                tr(language, "Nie można odtworzyć tego pliku.", "Cannot play this file."),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    fun previewSound(target: SoundTarget) {
        val type = if (target == SoundTarget.ENABLE) Settings.soundOnType(context) else Settings.soundOffType(context)
        val customFile = if (target == SoundTarget.ENABLE) Settings.soundOnCustomFile(context) else Settings.soundOffCustomFile(context)
        val volume = if (target == SoundTarget.ENABLE) soundOnVolume else soundOffVolume
        val toneIndex = if (target == SoundTarget.ENABLE) Settings.soundOnTone(context) else Settings.soundOffTone(context)
        soundPreviewController.play(type, customFile, toneIndex, volume, soundStream, language)
    }

    fun updateDndSetting(
        value: Boolean,
        setter: (Boolean) -> Unit
    ) {
        setter(value)

        if (enabled) {
            updateService(context, true)
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Bg,
            surface = Panel
        )
    ) {
        SideEffect {
            (context as? Activity)?.window?.let { window ->
                window.statusBarColor = HeaderNavy.toArgb()
                window.navigationBarColor = Bg.toArgb()
            }
        }
        AnimatedContent(
            targetState = currentPage,
            transitionSpec = {
                if (navigatingForward) {
                    (slideInHorizontally(
                        initialOffsetX = { it },
                        animationSpec = tween(230)
                    ) + fadeIn(tween(180))) togetherWith
                        (slideOutHorizontally(
                            targetOffsetX = { -it / 4 },
                            animationSpec = tween(230)
                        ) + fadeOut(tween(180)))
                } else {
                    (slideInHorizontally(
                        initialOffsetX = { -it / 4 },
                        animationSpec = tween(230)
                    ) + fadeIn(tween(180))) togetherWith
                        (slideOutHorizontally(
                            targetOffsetX = { it },
                            animationSpec = tween(230)
                        ) + fadeOut(tween(180)))
                }
            },
            label = "settings-navigation"
        ) { page ->
        when (page) {

            SettingsPage.HOME -> {
                MainHomeScreen(
                    language = language,
                    enabled = enabled,
                    onEnabledChange = { value ->
                        if (value && !hasDndAccess(context)) {
                            pendingEnableAfterPermission = true
                            showDndPermissionDialog = true
                        } else {
                            enabled = value
                            Settings.setEnabled(context, value)
                            updateService(context, value)
                        }
                    },
                    permission = permission,
                    onOpenPermission = {
                        context.startActivity(
                            Intent(
                                AndroidSettings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS
                            )
                        )
                    },
                    schedule = schedule,
                    onScheduleChange = {
                        schedule = it
                        Settings.setScheduleEnabled(context, it)

                        if (enabled) {
                            updateService(context, true)
                        }
                    },
                    start = start,
                    end = end,
                    onStartChange = {
                        start = it
                        Settings.setStartMinute(context, it)

                        if (enabled) {
                            updateService(context, true)
                        }
                    },
                    onEndChange = {
                        end = it
                        Settings.setEndMinute(context, it)

                        if (enabled) {
                            updateService(context, true)
                        }
                    },
                    days = days,
                    onDaysChange = {
                        days = it
                        Settings.setDaysMask(context, it)

                        if (enabled) {
                            updateService(context, true)
                        }
                    },
                    torch = torch,
                    onTorchChange = {
                        torch = it
                        Settings.setBlockTorch(context, it)
                    },
                    media = media,
                    onMediaChange = {
                        media = it
                        Settings.setBlockMedia(context, it)
                    },
                    headphones = headphones,
                    onHeadphonesChange = {
                        headphones = it
                        Settings.setBlockHeadphones(context, it)
                    },
                    unlockedScreen = unlockedScreen,
                    onUnlockedScreenChange = {
                        unlockedScreen = it
                        Settings.setBlockUnlockedScreen(context, it)
                    },
                    camera = camera,
                    onCameraChange = {
                        camera = it
                        Settings.setBlockCamera(context, it)
                    },
                    battery = battery,
                    onBatteryChange = {
                        battery = it
                    },
                    onBatteryCommit = {
                        Settings.setMinBattery(context, battery)
                        if (enabled) {
                            updateService(context, true)
                        }
                    },
                    onOpenSettings = {
                        navigate(SettingsPage.SETTINGS)
                    },
                    showStatusNotification = showStatusNotification,
                    onStatusNotificationChange = { value ->
                        if (value) {
                            showStatusNotification = true
                            Settings.setShowStatusNotification(context, true)
                            if (enabled) updateService(context, true)
                        } else {
                            showNotificationWarning = true
                        }
                    },
                    version = getAppVersion(context)
                )
            }

            SettingsPage.SETTINGS -> {
                SettingsScaffold(
                    language = language,
                    title = tr(language, "Ustawienia", "Settings"),
                    onBack = ::goBack,
                    scrollState = scrollStateFor(page)
                ) {
                    Section(tr(language, "OGÓLNE", "GENERAL"), Icons.Default.Tune) {
                        NavigationItem(
                            title = tr(language, "Język", "Language"),
                            subtitle = if (language == Settings.LANGUAGE_ENGLISH) "English" else "Polski",
                            leadingIcon = Icons.Default.Language,
                            onClick = { showLanguageDialog = true }
                        )
                        NavigationItem(
                            title = tr(language, "Wibracje", "Vibrations"),
                            subtitle = tr(language, "Ustawienia wibracji przy zmianie DND", "Vibration settings for DND changes"),
                            leadingIcon = Icons.Default.Vibration,
                            onClick = {
                                draftVibrationEnable = vibrationEnable
                                draftVibrationDisable = vibrationDisable
                                showVibrationDialog = true
                            }
                        )
                    }

                    Section(tr(language, "DŹWIĘKI", "SOUNDS"), Icons.AutoMirrored.Filled.VolumeUp) {
                        NavigationItem(
                            title = tr(language, "Dźwięki i sygnały", "Sounds and Signals"),
                            subtitle = tr(language, "Niezależne dźwięki włączania i wyłączania", "Independent enable and disable sounds"),
                            onClick = { navigate(SettingsPage.SOUNDS) }
                        )
                        NavigationItem(
                            title = tr(language, "Wybór strumienia audio", "Audio Stream Selection"),
                            subtitle = tr(language, "Wybierz kanał odtwarzania sygnałów", "Choose the audio stream used for signals"),
                            onClick = { showStreamDialog = true }
                        )
                    }

                    Section(tr(language, "DZIAŁANIE", "OPERATION")) {
                        NavigationItem(
                            title = tr(language, "Dozwolone wyjątki", "Allowed Exceptions"),
                            subtitle = tr(language, "Kategorie dozwolone podczas trybu Nie przeszkadzać", "Categories allowed during Do Not Disturb"),
                            leadingIcon = Icons.Default.Check,
                            onClick = { navigate(SettingsPage.NOTIFICATIONS) }
                        )
                        NavigationItem(
                            title = tr(language, "Warunki wykluczające", "Exclusion Conditions"),
                            subtitle = tr(language, "Kiedy aplikacja nie powinna aktywować DND", "When the app should not activate DND"),
                            leadingIcon = Icons.Default.Close,
                            onClick = { navigate(SettingsPage.EXCLUSIONS) }
                        )

                        Text(
                            tr(language, "Czułość: ${sensitivity.toInt()}%", "Sensitivity: ${sensitivity.toInt()}%"),
                            color = Color.White,
                            fontWeight = FontWeight.Medium
                        )
                        Slider(
                            value = sensitivity,
                            onValueChange = { sensitivity = it },
                            onValueChangeFinished = {
                                Settings.setSensitivity(context, sensitivity.toInt())
                                if (enabled) updateService(context, true)
                            },
                            valueRange = 0f..100f,
                            steps = 9
                        )
                        HorizontalDivider(color = DividerColor)
                        Text(
                            tr(language, "Opóźnienie: ${delayValue.toInt()} ms", "Delay: ${delayValue.toInt()} ms"),
                            color = Color.White,
                            fontWeight = FontWeight.Medium
                        )
                        Slider(
                            value = delayValue,
                            onValueChange = { delayValue = it },
                            onValueChangeFinished = {
                                Settings.setDelayMs(context, delayValue.toInt())
                                if (enabled) updateService(context, true)
                            },
                            valueRange = 0f..2000f,
                            steps = 7
                        )
                    }

                    NavigationItem(
                        title = tr(language, "Informacje", "About"),
                        subtitle = tr(language, "Informacje o aplikacji i changelog", "App information and changelog"),
                        leadingIcon = Icons.Default.Info,
                        onClick = { navigate(SettingsPage.ABOUT) }
                    )
                }
            }

            SettingsPage.NOTIFICATIONS -> {
                SettingsScaffold(
                    language = language,
                    title = tr(
                        language,
                        "Dozwolone wyjątki",
                        "Allowed Exceptions"
                    ),
                    onBack = ::goBack,
                    scrollState = scrollStateFor(page)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            tr(
                                language,
                                "Wybierz, które kategorie powiadomień mogą być słyszalne podczas działania trybu Nie przeszkadzać.",
                                "Choose which notification categories may be audible while Do Not Disturb is active."
                            ),
                            color = Muted,
                            style = MaterialTheme.typography.bodySmall
                        )

                        SettingSwitch(
                            tr(language, "Alarmy i budziki", "Alarms and alarm clocks"),
                            dndAlarms
                        ) {
                            dndAlarms = it
                            updateDndSetting(it) {
                                Settings.setAllowDndAlarms(context, it)
                            }
                        }

                        SettingSwitch(
                            tr(language, "Połączenia", "Calls"),
                            dndCalls
                        ) {
                            dndCalls = it
                            updateDndSetting(it) {
                                Settings.setAllowDndCalls(context, it)
                            }
                        }

                        SettingSwitch(
                            tr(
                                language,
                                "Powtarzające się połączenia",
                                "Repeat callers"
                            ),
                            dndRepeatCallers
                        ) {
                            dndRepeatCallers = it
                            updateDndSetting(it) {
                                Settings.setAllowDndRepeatCallers(context, it)
                            }
                        }

                        SettingSwitch(
                            tr(language, "Wiadomości", "Messages"),
                            dndMessages
                        ) {
                            dndMessages = it
                            updateDndSetting(it) {
                                Settings.setAllowDndMessages(context, it)
                            }
                        }

                        SettingSwitch(
                            tr(language, "Przypomnienia", "Reminders"),
                            dndReminders
                        ) {
                            dndReminders = it
                            updateDndSetting(it) {
                                Settings.setAllowDndReminders(context, it)
                            }
                        }

                        SettingSwitch(
                            tr(language, "Wydarzenia", "Events"),
                            dndEvents
                        ) {
                            dndEvents = it
                            updateDndSetting(it) {
                                Settings.setAllowDndEvents(context, it)
                            }
                        }

                        SettingSwitch(
                            tr(language, "Multimedia", "Media"),
                            dndMedia
                        ) {
                            dndMedia = it
                            updateDndSetting(it) {
                                Settings.setAllowDndMedia(context, it)
                            }
                        }

                        SettingSwitch(
                            tr(language, "Dźwięki systemowe", "System sounds"),
                            dndSystem
                        ) {
                            dndSystem = it
                            updateDndSetting(it) {
                                Settings.setAllowDndSystem(context, it)
                            }
                        }

                        Text(
                            tr(
                                language,
                                "Domyślnie dozwolone są wyłącznie alarmy i budziki. Zmiany zostaną zastosowane przy następnym włączeniu DND.",
                                "Only alarms are allowed by default. Changes will be applied the next time DND is enabled."
                            ),
                            color = Subtle,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }


                }
            }

            SettingsPage.EXCLUSIONS -> {
                SettingsScaffold(
                    language = language,
                    title = tr(language, "Warunki wykluczające", "Exclusion Conditions"),
                    onBack = ::goBack,
                    scrollState = scrollStateFor(page)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SettingSwitch(tr(language, "Nie działaj, gdy latarka jest włączona", "Do not activate while flashlight is on"), torch) {
                            torch = it
                            Settings.setBlockTorch(context, it)
                            if (enabled) updateService(context, true)
                        }
                        SettingSwitch(tr(language, "Nie działaj podczas odtwarzania multimediów", "Do not activate during media playback"), media) {
                            media = it
                            Settings.setBlockMedia(context, it)
                            if (enabled) updateService(context, true)
                        }
                        SettingSwitch(tr(language, "Nie działaj, gdy podłączone są słuchawki", "Do not activate when headphones are connected"), headphones) {
                            headphones = it
                            Settings.setBlockHeadphones(context, it)
                            if (enabled) updateService(context, true)
                        }
                        SettingSwitch(tr(language, "Nie działaj, gdy ekran jest odblokowany", "Do not activate while screen is unlocked"), unlockedScreen) {
                            unlockedScreen = it
                            Settings.setBlockUnlockedScreen(context, it)
                            if (enabled) updateService(context, true)
                        }
                        SettingSwitch(tr(language, "Nie działaj podczas używania aparatu", "Do not activate while camera is in use"), camera) {
                            camera = it
                            Settings.setBlockCamera(context, it)
                            if (enabled) updateService(context, true)
                        }
                        Text(tr(language, "Minimalny poziom baterii: $battery% (0 = bez ograniczenia)", "Minimum battery level: $battery% (0 = no limit)"), color = Color.White)
                        Slider(
                            value = battery.toFloat(),
                            onValueChange = { battery = it.toInt() },
                            onValueChangeFinished = {
                                Settings.setMinBattery(context, battery)
                                if (enabled) updateService(context, true)
                            },
                            valueRange = 0f..50f,
                            steps = 9
                        )
                    }
                }
            }

            SettingsPage.SOUNDS -> {
                SettingsScaffold(
                    language = language,
                    title = tr(
                        language,
                        "Dźwięki i sygnały",
                        "Sounds and signals"
                    ),
                    onBack = ::goBack,
                    scrollState = scrollStateFor(page)
                ) {
                    Section(null) {
                        SettingSwitch(
                            tr(
                                language,
                                "Odtwórz dźwięk przy włączaniu DND",
                                "Play a sound when enabling DND"
                            ),
                            soundEnable
                        ) {
                            soundEnable = it
                            Settings.setSoundOnEnable(context, it)
                        }

                        NavigationItem(
                            title = tr(
                                language,
                                "Dźwięk włączania",
                                "Enable sound"
                            ),
                            subtitle = getSelectedSoundName(
                                context,
                                soundOnType,
                                Settings.soundOnUri(context),
                                Settings.soundOnCustomDisplayName(context) ?: Settings.soundOnCustomFile(context),
                                Settings.soundOnTone(context),
                                language
                            ),
                            onClick = {
                                navigate(SettingsPage.SOUND_ENABLE)
                            }
                        )

                        HorizontalDivider(color = DividerColor)

                        SettingSwitch(
                            tr(
                                language,
                                "Odtwórz dźwięk przy wyłączaniu DND",
                                "Play a sound when disabling DND"
                            ),
                            soundDisable
                        ) {
                            soundDisable = it
                            Settings.setSoundOnDisable(context, it)
                        }

                        NavigationItem(
                            title = tr(
                                language,
                                "Dźwięk wyłączania",
                                "Disable sound"
                            ),
                            subtitle = getSelectedSoundName(
                                context,
                                soundOffType,
                                Settings.soundOffUri(context),
                                Settings.soundOffCustomDisplayName(context) ?: Settings.soundOffCustomFile(context),
                                Settings.soundOffTone(context),
                                language
                            ),
                            onClick = {
                                navigate(SettingsPage.SOUND_DISABLE)
                            }
                        )
                    }


                }
            }

            SettingsPage.SOUND_ENABLE,
            SettingsPage.SOUND_DISABLE -> {
                val target = if (
                    page == SettingsPage.SOUND_ENABLE
                ) {
                    SoundTarget.ENABLE
                } else {
                    SoundTarget.DISABLE
                }

                val selectedType = if (
                    target == SoundTarget.ENABLE
                ) {
                    soundOnType
                } else {
                    soundOffType
                }

                val selectedUri = if (
                    target == SoundTarget.ENABLE
                ) {
                    Settings.soundOnUri(context)
                } else {
                    Settings.soundOffUri(context)
                }

                val selectedFile = if (
                    target == SoundTarget.ENABLE
                ) {
                    Settings.soundOnCustomFile(context)
                } else {
                    Settings.soundOffCustomFile(context)
                }

                val selectedVolume = if (
                    target == SoundTarget.ENABLE
                ) {
                    soundOnVolume
                } else {
                    soundOffVolume
                }

                SettingsScaffold(
                    language = language,
                    title = if (target == SoundTarget.ENABLE) {
                        tr(
                            language,
                            "Dźwięk włączania",
                            "Enable sound"
                        )
                    } else {
                        tr(
                            language,
                            "Dźwięk wyłączania",
                            "Disable sound"
                        )
                    },
                    onBack = ::goBack,
                    scrollState = scrollStateFor(page)
                ) {
                    SoundConfiguration(
                        language = language,
                        selectedType = selectedType,
                        selectedName = getSelectedSoundName(
                            context,
                            selectedType,
                            selectedUri,
                            if (target == SoundTarget.ENABLE) Settings.soundOnCustomDisplayName(context) ?: selectedFile else Settings.soundOffCustomDisplayName(context) ?: selectedFile,
                            if (target == SoundTarget.ENABLE) Settings.soundOnTone(context) else Settings.soundOffTone(context),
                            language
                        ),
                        volume = selectedVolume,
                        onVolumeChange = { value ->
                            if (target == SoundTarget.ENABLE) {
                                soundOnVolume = value
                            } else {
                                soundOffVolume = value
                            }
                        },
                        onVolumeCommit = {
                            if (target == SoundTarget.ENABLE) {
                                Settings.setSoundOnVolume(
                                    context,
                                    soundOnVolume
                                )
                            } else {
                                Settings.setSoundOffVolume(
                                    context,
                                    soundOffVolume
                                )
                            }
                        },
                        onDefault = {
                            pendingSoundTarget = target
                            pendingTone = if (target == SoundTarget.ENABLE) {
                                Settings.soundOnTone(context)
                            } else {
                                Settings.soundOffTone(context)
                            }
                            showToneDialog = true
                        },
                        onSystem = {
                            openSystemSoundPicker(target)
                        },
                        onCustom = {
                            openCustomSoundPicker(target)
                        },
                        onPreview = {
                            previewSound(target)
                        },
                        refreshKey = refreshSounds
                    )
                }
            }

            SettingsPage.CUSTOM_BROWSER -> {
                val childFolders = remember(audioFiles, selectedAudioFolder) {
                    audioFiles.mapNotNull { item ->
                        val prefix = if (selectedAudioFolder.isBlank()) "" else "$selectedAudioFolder/"
                        if (!item.folder.startsWith(prefix) || item.folder == selectedAudioFolder) null
                        else item.folder.removePrefix(prefix).substringBefore("/")
                    }.distinct().sorted()
                }
                val filesInFolder = remember(audioFiles, selectedAudioFolder) {
                    audioFiles.filter { it.folder == selectedAudioFolder }
                }
                val browserScrollState = rememberScrollState()
                Column(Modifier.fillMaxSize().background(Bg)) {
                    PageHeader(
                        language = language,
                        title = tr(language, "Wybierz plik audio", "Choose an audio file"),
                        onBack = {
                            if (selectedAudioFolder.isNotBlank()) {
                                runCatching { audioPreview?.stop() }; runCatching { audioPreview?.release() }; audioPreview = null
                                selectedAudioFolder = selectedAudioFolder.substringBeforeLast("/", "")
                                selectedAudio = null
                            } else {
                                runCatching { audioPreview?.stop() }; runCatching { audioPreview?.release() }; audioPreview = null
                                goBack()
                            }
                        }
                    )
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        Column(
                            Modifier.fillMaxSize().verticalScroll(browserScrollState).padding(horizontal = 20.dp, vertical = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (selectedAudioFolder.isNotBlank()) {
                                TextButton(onClick = {
                                    runCatching { audioPreview?.stop() }; runCatching { audioPreview?.release() }; audioPreview = null
                                    selectedAudioFolder = selectedAudioFolder.substringBeforeLast("/", "")
                                    selectedAudio = null
                                }) { Text(tr(language, "← Folder wyżej", "← Parent folder")) }
                                Text(selectedAudioFolder, color = Muted, style = MaterialTheme.typography.bodySmall)
                            }
                            childFolders.forEach { folderName ->
                                NavigationItem(
                                    title = folderName,
                                    subtitle = tr(language, "Folder", "Folder"),
                                    onClick = {
                                        runCatching { audioPreview?.stop() }; runCatching { audioPreview?.release() }; audioPreview = null
                                        selectedAudioFolder = if (selectedAudioFolder.isBlank()) folderName else "$selectedAudioFolder/$folderName"
                                        selectedAudio = null
                                    }
                                )
                            }
                            if (audioFiles.isEmpty()) Text(tr(language, "Nie znaleziono plików audio.", "No audio files were found."), color = Muted)
                            if (childFolders.isEmpty() && filesInFolder.isEmpty() && audioFiles.isNotEmpty()) {
                                Text(tr(language, "Ten folder nie zawiera plików audio.", "This folder contains no audio files."), color = Muted)
                            }
                            filesInFolder.forEach { item ->
                                Card(
                                    onClick = {
                                        selectedAudio = item.uri
                                        startAudioPreview(item.uri)
                                    },
                                    colors = CardDefaults.cardColors(containerColor = Panel)
                                ) {
                                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                                        Text(item.name, color = Color.White, fontWeight = FontWeight.Medium)
                                        Text(item.folder, color = Subtle, style = MaterialTheme.typography.bodySmall)
                                        if (selectedAudio == item.uri) Text(tr(language, "Wybrany do odsłuchu", "Selected for preview"), color = Accent)
                                    }
                                }
                            }
                        }
                        ScrollIndicator(browserScrollState, Modifier.align(Alignment.CenterEnd))
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                runCatching { audioPreview?.stop() }; runCatching { audioPreview?.release() }; audioPreview = null
                                selectedAudio = null
                                goBack()
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text(tr(language, "Anuluj", "Cancel")) }
                        Button(
                            onClick = {
                                val uri = selectedAudio
                                if (uri != null) {
                                    try {
                                        val directory = File(context.filesDir, "sounds")
                                        if (!directory.exists()) directory.mkdirs()
                                        val originalName = audioFiles.firstOrNull { it.uri == uri }?.name ?: "custom.audio"
                                        val safeName = if (pendingSoundTarget == SoundTarget.ENABLE) "sound_on" else "sound_off"
                                        val ext = originalName.substringAfterLast('.', "audio").let { ".$it" }
                                        val destination = File(directory, safeName + ext)
                                        context.contentResolver.openInputStream(uri)?.use { input ->
                                            FileOutputStream(destination).use { output -> input.copyTo(output) }
                                        } ?: throw IllegalStateException("Cannot read selected audio")
                                        if (pendingSoundTarget == SoundTarget.ENABLE) {
                                            soundOnType = Settings.SOUND_CUSTOM
                                            Settings.setSoundOnType(context, soundOnType)
                                            Settings.setSoundOnCustomFile(context, destination.name)
                                            Settings.setSoundOnCustomDisplayName(context, originalName)
                                        } else {
                                            soundOffType = Settings.SOUND_CUSTOM
                                            Settings.setSoundOffType(context, soundOffType)
                                            Settings.setSoundOffCustomFile(context, destination.name)
                                            Settings.setSoundOffCustomDisplayName(context, originalName)
                                        }
                                        runCatching { audioPreview?.stop() }; runCatching { audioPreview?.release() }; audioPreview = null
                                        refreshSounds++
                                        goBack()
                                    } catch (_: Exception) {
                                        Toast.makeText(context, tr(language, "Nie udało się skopiować pliku audio.", "Could not copy the audio file."), Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            enabled = selectedAudio != null,
                            modifier = Modifier.weight(1f)
                        ) { Text(tr(language, "OK", "OK")) }
                    }
                    AppFooter(getAppVersion(context))
                }
            }

            SettingsPage.ABOUT -> {
                SettingsScaffold(
                    language = language,
                    title = tr(language, "Informacje", "About"),
                    onBack = ::goBack,
                    scrollState = scrollStateFor(page),
                    rightActionLabel = "Changelog",
                    onRightAction = { showChangelog = true },
                    centerContentVertically = true
                ) {
                    Text(
                        tr(
                            language,
                            "Projekt robiony hobbystycznie w wolnych chwilach. Mam nadzieję, że komuś się przyda.\nAplikacja jest całkowicie darmowa, jeśli jednak bardzo Ci się spodobała, rozważ wsparcie.",
                            "This project is made as a hobby in my spare time. I hope someone finds it useful.\nThe app is completely free, but if you really enjoyed it, consider supporting the project."
                        ),
                        color = Color.White,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )

                    Button(
                        onClick = {
                            runCatching {
                                context.startActivity(
                                    Intent(Intent.ACTION_VIEW, Uri.parse(SUPPORT_URL))
                                )
                            }.onFailure {
                                Toast.makeText(
                                    context,
                                    tr(language, "Nie można otworzyć strony wsparcia.", "Could not open the support page."),
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        },
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Text(tr(language, "Wesprzyj", "Buy Me a Coffee"))
                    }
                }
            }
        }

        }

        if (showLanguageDialog) {
            val languageOptions = listOf(
                Settings.LANGUAGE_ENGLISH to "English",
                Settings.LANGUAGE_POLISH to "Polski"
            ).sortedBy { it.second.lowercase(Locale.ROOT) }

            Dialog(onDismissRequest = { showLanguageDialog = false }) {
                Surface(shape = RoundedCornerShape(22.dp), color = Panel) {
                    Column(
                        Modifier.widthIn(min = 260.dp).padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        languageOptions.forEach { (code, label) ->
                            LanguageChoice(
                                label = label,
                                selected = language == code
                            ) {
                                language = code
                                Settings.setLanguage(context, code)
                                showLanguageDialog = false
                            }
                        }
                    }
                }
            }
        }

        if (showVibrationDialog) {
            Dialog(onDismissRequest = { showVibrationDialog = false }) {
                Surface(shape = RoundedCornerShape(22.dp), color = Panel) {
                    Column(
                        Modifier.widthIn(min = 280.dp).padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SettingSwitch(
                            tr(language, "Wibracja przy włączaniu DND", "Vibrate when enabling DND"),
                            draftVibrationEnable
                        ) { draftVibrationEnable = it }
                        SettingSwitch(
                            tr(language, "Wibracja przy wyłączaniu DND", "Vibrate when disabling DND"),
                            draftVibrationDisable
                        ) { draftVibrationDisable = it }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { showVibrationDialog = false }) {
                                Text(tr(language, "Anuluj", "Cancel"))
                            }
                            TextButton(onClick = {
                                vibrationEnable = draftVibrationEnable
                                vibrationDisable = draftVibrationDisable
                                Settings.setVibrationOnEnable(context, vibrationEnable)
                                Settings.setVibrationOnDisable(context, vibrationDisable)
                                showVibrationDialog = false
                            }) {
                                Text("OK")
                            }
                        }
                    }
                }
            }
        }

        if (showStreamDialog) {
            Dialog(onDismissRequest = { showStreamDialog = false }) {
                Surface(shape = RoundedCornerShape(22.dp), color = Panel) {
                    Column(
                        Modifier.widthIn(min = 260.dp).padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StreamChoice(tr(language, "Multimedia", "Media"), soundStream == Settings.STREAM_MEDIA) {
                            soundStream = Settings.STREAM_MEDIA
                            Settings.setSoundStream(context, soundStream)
                            showStreamDialog = false
                        }
                        StreamChoice(tr(language, "Powiadomienia", "Notifications"), soundStream == Settings.STREAM_NOTIFICATION) {
                            soundStream = Settings.STREAM_NOTIFICATION
                            Settings.setSoundStream(context, soundStream)
                            showStreamDialog = false
                        }
                        StreamChoice(tr(language, "Alarmy", "Alarms"), soundStream == Settings.STREAM_ALARM) {
                            soundStream = Settings.STREAM_ALARM
                            Settings.setSoundStream(context, soundStream)
                            showStreamDialog = false
                        }
                    }
                }
            }
        }

        if (showDndPermissionDialog) {
            AlertDialog(
                onDismissRequest = {
                    showDndPermissionDialog = false
                    pendingEnableAfterPermission = false
                },
                title = {
                    Text(tr(language, "Nadaj dostęp aplikacji", "Grant app access"))
                },
                text = {
                    Text(
                        tr(
                            language,
                            "Flip Silence potrzebuje uprawnienia do zmieniania trybu Nie przeszkadzać. Naciśnij OK, aby otworzyć odpowiednie ustawienia Androida.",
                            "Flip Silence needs permission to change Do Not Disturb. Tap OK to open the relevant Android settings."
                        )
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showDndPermissionDialog = false
                            context.startActivity(
                                Intent(AndroidSettings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                            )
                        }
                    ) { Text("OK") }
                },
                containerColor = Panel,
                titleContentColor = Color.White,
                textContentColor = Muted
            )
        }

        if (showNotificationWarning) {
            AlertDialog(
                onDismissRequest = {
                    showNotificationWarning = false
                },
                title = {
                    Text(
                        tr(
                            language,
                            "Wyłączyć powiadomienie?",
                            "Disable notification?"
                        )
                    )
                },
                text = {
                    Text(
                        tr(
                            language,
                            "Wyłączenie powiadomienia może wpłynąć na działanie aplikacji w tle. Android może nadal wymagać widocznego powiadomienia usługi pierwszego planu.",
                            "Disabling this notification may affect background operation. Android may still require a visible foreground-service notification."
                        )
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showStatusNotification = false
                            Settings.setShowStatusNotification(
                                context,
                                false
                            )
                            showNotificationWarning = false
                        }
                    ) {
                        Text(
                            tr(language, "Wyłącz", "Disable")
                        )
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            showNotificationWarning = false
                        }
                    ) {
                        Text(
                            tr(language, "Anuluj", "Cancel")
                        )
                    }
                },
                containerColor = Panel,
                titleContentColor = Color.White,
                textContentColor = Muted
            )
        }

        if (showSupportDialog) {
            AlertDialog(
                onDismissRequest = {
                    showSupportDialog = false
                },
                title = {
                    Text(
                        tr(
                            language,
                            "Rozważ wsparcie projektu",
                            "Consider supporting the project"
                        )
                    )
                },
                text = {
                    Text(
                        tr(
                            language,
                            "Jeśli Flip Silence jest dla Ciebie przydatny, rozważ wsparcie dalszego rozwoju projektu.",
                            "If Flip Silence is useful to you, consider supporting the continued development of the project."
                        )
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showSupportDialog = false
                            runCatching {
                                context.startActivity(
                                    Intent(Intent.ACTION_VIEW, Uri.parse(SUPPORT_URL))
                                )
                            }.onFailure {
                                Toast.makeText(
                                    context,
                                    tr(language, "Nie można otworzyć strony wsparcia.", "Could not open the support page."),
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    ) {
                        Text(
                            tr(language, "Wesprzyj", "Buy Me a Coffee")
                        )
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            showSupportDialog = false
                        }
                    ) {
                        Text(
                            tr(language, "Anuluj", "Cancel")
                        )
                    }
                },
                containerColor = Panel,
                titleContentColor = Color.White,
                textContentColor = Muted
            )
        }

        if (showToneDialog) {
            val toneLabels = listOf(
                tr(language, "Krótki", "Short"),
                tr(language, "Potwierdzenie", "Confirmation"),
                tr(language, "Podwójny", "Double")
            )
            AlertDialog(
                onDismissRequest = { showToneDialog = false },
                title = { Text(tr(language, "Wybierz sygnał", "Choose a tone")) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        toneLabels.forEachIndexed { index, label ->
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable {
                                    pendingTone = index
                                    val volume = if (pendingSoundTarget == SoundTarget.ENABLE) soundOnVolume else soundOffVolume
                                    soundPreviewController.play(Settings.SOUND_DEFAULT, null, index, volume, soundStream, language)
                                }.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(label, color = Color.White, modifier = Modifier.weight(1f))
                                RadioButton(selected = pendingTone == index, onClick = null)
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            if (pendingSoundTarget == SoundTarget.ENABLE) {
                                Settings.setSoundOnType(context, Settings.SOUND_DEFAULT)
                                Settings.setSoundOnTone(context, pendingTone)
                            } else {
                                Settings.setSoundOffType(context, Settings.SOUND_DEFAULT)
                                Settings.setSoundOffTone(context, pendingTone)
                            }
                            refreshSounds++
                            showToneDialog = false
                        }
                    ) { Text("OK") }
                },
                dismissButton = {
                    TextButton(onClick = { showToneDialog = false }) {
                        Text(tr(language, "Anuluj", "Cancel"))
                    }
                },
                containerColor = Panel,
                titleContentColor = Color.White,
                textContentColor = Muted
            )
        }

        if (showChangelog) {
            AlertDialog(
                onDismissRequest = { showChangelog = false },
                title = { Text("Changelog") },
                text = {
                    Column(
                        Modifier
                            .heightIn(max = 480.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        Text(changelogText, color = Muted)
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showChangelog = false }) {
                        Text("OK")
                    }
                },
                containerColor = Panel,
                titleContentColor = Color.White,
                textContentColor = Muted
            )
        }
    }

    val lifecycleOwner = context as? LifecycleOwner
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                val granted = hasDndAccess(context)
                permission = granted
                refreshSounds++
                if (granted && pendingEnableAfterPermission) {
                    pendingEnableAfterPermission = false
                    enabled = true
                    Settings.setEnabled(context, true)
                    updateService(context, true)
                }
            }
        }
        lifecycleOwner?.lifecycle?.addObserver(observer)
        onDispose { lifecycleOwner?.lifecycle?.removeObserver(observer) }
    }

    LaunchedEffect(Unit) {
        permission = hasDndAccess(context)
    }
}

@Composable
private fun MainHomeScreen(
    language: String,
    enabled: Boolean,
    onEnabledChange: (Boolean) -> Unit,
    permission: Boolean,
    onOpenPermission: () -> Unit,
    schedule: Boolean,
    onScheduleChange: (Boolean) -> Unit,
    start: Int,
    end: Int,
    onStartChange: (Int) -> Unit,
    onEndChange: (Int) -> Unit,
    days: Int,
    onDaysChange: (Int) -> Unit,
    torch: Boolean,
    onTorchChange: (Boolean) -> Unit,
    media: Boolean,
    onMediaChange: (Boolean) -> Unit,
    headphones: Boolean,
    onHeadphonesChange: (Boolean) -> Unit,
    unlockedScreen: Boolean,
    onUnlockedScreenChange: (Boolean) -> Unit,
    camera: Boolean,
    onCameraChange: (Boolean) -> Unit,
    battery: Int,
    onBatteryChange: (Int) -> Unit,
    onBatteryCommit: () -> Unit,
    onOpenSettings: () -> Unit,
    showStatusNotification: Boolean,
    onStatusNotificationChange: (Boolean) -> Unit,
    version: String
) {
    val scrollState = rememberScrollState()
    Column(Modifier.fillMaxSize().background(Bg)) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            Column(
                Modifier.fillMaxSize().verticalScroll(scrollState)
            ) {
            Row(
                modifier = Modifier.fillMaxWidth().background(HeaderNavy).windowInsetsPadding(WindowInsets.statusBars).padding(horizontal = 20.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Flip Silence",
                    color = Color.White,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier.size(44.dp).clip(RoundedCornerShape(50)).background(Panel)
                ) {
                    Icon(Icons.Default.Settings, contentDescription = tr(language, "Ustawienia", "Settings"), tint = Color.White)
                }
            }

            Column(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    tr(language, "Cisza jednym\nodwróceniem.", "Silence with a\nsingle flip."),
                    color = Color.White,
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    tr(
                        language,
                        "Odwróć telefon ekranem do dołu, aby włączyć Nie przeszkadzać. Odwróć go ekranem do góry, aby przywrócić poprzedni stan.",
                        "Turn your phone face down to enable Do Not Disturb. Turn it face up to restore the previous state."
                    ),
                    color = Muted
                )

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).clickable { onEnabledChange(!enabled) }.padding(horizontal = 18.dp, vertical = 20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(tr(language, "Aktywuj Flip Silence", "Activate Flip Silence"), color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        Switch(checked = enabled, onCheckedChange = null)
                    }
                }

                Section(tr(language, "Harmonogram", "Schedule")) {
                    SettingSwitch(
                        tr(language, "Ogranicz działanie do godzin", "Limit operation to specific hours"),
                        schedule,
                        onScheduleChange
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        TimeButton(tr(language, "Od", "From"), start, Modifier.weight(1f), onStartChange)
                        TimeButton(tr(language, "Do", "To"), end, Modifier.weight(1f), onEndChange)
                    }

                    Text(tr(language, "Dni tygodnia", "Days of the week"), color = Color.White, fontWeight = FontWeight.Medium)
                    val names = if (language == Settings.LANGUAGE_ENGLISH) {
                        listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
                    } else {
                        listOf("Pn", "Wt", "Śr", "Cz", "Pt", "Sb", "Nd")
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        names.forEachIndexed { index, name ->
                            val bit = 1 shl index
                            FilterChip(
                                selected = days and bit != 0,
                                onClick = { onDaysChange(days xor bit) },
                                label = { Text(name) }
                            )
                        }
                    }

                    Text(
                        tr(
                            language,
                            "Harmonogram dotyczy momentu aktywacji. Gdy okno czasowe się kończy, aplikacja przywraca poprzedni stan DND.",
                            "The schedule controls when automation may activate. When the time window ends, the app restores the previous DND state."
                        ),
                        color = Subtle,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    SettingSwitch(
                        tr(language, "Powiadomienie o działaniu aplikacji", "App operation notification"),
                        showStatusNotification,
                        onStatusNotificationChange
                    )
                }

            }
            }
            ScrollIndicator(scrollState, Modifier.align(Alignment.CenterEnd))
        }
        AppFooter(version)
    }
}

@Composable
private fun PageHeader(
    language: String,
    title: String,
    onBack: () -> Unit,
    rightActionLabel: String? = null,
    onRightAction: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier.fillMaxWidth().background(HeaderNavy).windowInsetsPadding(WindowInsets.statusBars).padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier.size(42.dp).clip(RoundedCornerShape(50)).background(Panel)
        ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = tr(language, "Wstecz", "Back"), tint = Accent)
        }
        Spacer(Modifier.width(8.dp))
        Text(
            title,
            color = Color.White,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f)
        )
        if (rightActionLabel != null && onRightAction != null) {
            FilledTonalButton(
                onClick = onRightAction,
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = Panel, contentColor = Accent)
            ) {
                Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(rightActionLabel)
            }
        }
    }
}

@Composable
private fun AppFooter(version: String) {
    Text(
        "Version $version • Flip Silence",
        color = Color(0xFF718096),
        style = MaterialTheme.typography.labelSmall,
        modifier = Modifier.fillMaxWidth().windowInsetsPadding(WindowInsets.navigationBars).padding(horizontal = 20.dp, vertical = 12.dp),
        textAlign = androidx.compose.ui.text.style.TextAlign.Center
    )
}

@Composable
private fun ScrollIndicator(scrollState: ScrollState, modifier: Modifier = Modifier) {
    if (scrollState.maxValue > 0 && scrollState.isScrollInProgress) {
        Canvas(modifier.width(4.dp).fillMaxHeight().padding(vertical = 4.dp)) {
            val trackHeight = size.height
            if (trackHeight <= 0f) return@Canvas
            val minThumb = 24.dp.toPx()
            val maxScroll = scrollState.maxValue.toFloat()
            val thumbHeight = (trackHeight * trackHeight / (trackHeight + maxScroll)).coerceIn(minThumb.coerceAtMost(trackHeight), trackHeight)
            val travel = (trackHeight - thumbHeight).coerceAtLeast(0f)
            val fraction = (scrollState.value.toFloat() / maxScroll).coerceIn(0f, 1f)
            val thumbWidth = 3.dp.toPx()
            drawRoundRect(
                color = Accent.copy(alpha = 0.82f),
                topLeft = androidx.compose.ui.geometry.Offset((size.width - thumbWidth) / 2f, travel * fraction),
                size = androidx.compose.ui.geometry.Size(thumbWidth, thumbHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(thumbWidth / 2f)
            )
        }
    }
}

@Composable
private fun SettingsScaffold(
    language: String,
    title: String,
    onBack: () -> Unit,
    scrollState: ScrollState,
    rightActionLabel: String? = null,
    onRightAction: (() -> Unit)? = null,
    centerContentVertically: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    val context = LocalContext.current
    val version = getAppVersion(context)
    Column(Modifier.fillMaxSize().background(Bg)) {
        PageHeader(language, title, onBack, rightActionLabel, onRightAction)
        Box(Modifier.weight(1f).fillMaxWidth()) {
            BoxWithConstraints(Modifier.fillMaxSize()) {
                Column(
                    Modifier.fillMaxWidth().heightIn(min = maxHeight).verticalScroll(scrollState).padding(horizontal = 20.dp, vertical = 16.dp),
                    verticalArrangement = if (centerContentVertically) {
                        Arrangement.spacedBy(16.dp, Alignment.CenterVertically)
                    } else {
                        Arrangement.spacedBy(16.dp)
                    }
                ) {
                    content()
                    Spacer(Modifier.height(8.dp))
                }
            }
            ScrollIndicator(scrollState, Modifier.align(Alignment.CenterEnd))
        }
        AppFooter(version)
    }
}

@Composable
private fun SoundConfiguration(
    language: String,
    selectedType: String,
    selectedName: String,
    volume: Int,
    onVolumeChange: (Int) -> Unit,
    onVolumeCommit: () -> Unit,
    onDefault: () -> Unit,
    onSystem: () -> Unit,
    onCustom: () -> Unit,
    onPreview: () -> Unit,
    refreshKey: Int
) {
    key(refreshKey) {
        Section(
            tr(language, "Wybrany dźwięk", "Selected sound")
        ) {
            Text(
                selectedName,
                color = Accent,
                fontWeight = FontWeight.SemiBold
            )

            HorizontalDivider(color = DividerColor)

            SoundTypeChoice(
                tr(
                    language,
                    "Dźwięk Flip Silence",
                    "Flip Silence Sound"
                ),
                selectedType == Settings.SOUND_DEFAULT,
                onDefault
            )

            SoundTypeChoice(
                tr(
                    language,
                    "Dźwięk powiadomienia",
                    "Notification sound"
                ),
                selectedType == Settings.SOUND_NOTIFICATION,
                onSystem
            )

            SoundTypeChoice(
                tr(
                    language,
                    "Własny plik audio",
                    "Custom audio file"
                ),
                selectedType == Settings.SOUND_CUSTOM,
                onCustom
            )

            HorizontalDivider(color = DividerColor)

            Text(
                tr(
                    language,
                    "Głośność: $volume%",
                    "Volume: $volume%"
                ),
                color = Color.White,
                fontWeight = FontWeight.Medium
            )

            Slider(
                value = volume.toFloat(),
                onValueChange = {
                    onVolumeChange(it.toInt())
                },
                onValueChangeFinished = onVolumeCommit,
                valueRange = 0f..100f,
                steps = 9
            )

            OutlinedButton(
                onClick = onPreview,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    tr(language, "Odsłuchaj", "Preview")
                )
            }
        }

        Text(
            tr(
                language,
                "Wybierz dźwięk Flip Silence, aktualny dźwięk powiadomienia albo własny plik audio. Ustawienia włączania i wyłączania są niezależne.",
                "Choose a Flip Silence tone, the current notification sound, or your own audio file. Enable and disable settings are independent."
            ),
            color = Subtle,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun NavigationItem(
    title: String,
    subtitle: String,
    leadingIcon: ImageVector? = null,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF26364D)
        ),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (leadingIcon != null) {
                Icon(leadingIcon, contentDescription = null, tint = Color.White, modifier = Modifier.size(21.dp))
                Spacer(Modifier.width(12.dp))
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    title,
                    color = Color.White,
                    fontWeight = FontWeight.Medium
                )

                Text(
                    subtitle,
                    color = Muted,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Text(
                "›",
                color = Accent,
                style = MaterialTheme.typography.headlineMedium
            )
        }
    }
}

@Composable
private fun SoundTypeChoice(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        RadioButton(selected = selected, onClick = null)
    }
}

@Composable
private fun StreamChoice(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f))
        RadioButton(selected = selected, onClick = null)
    }
}

@Composable
private fun LanguageChoice(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f))
        RadioButton(selected = selected, onClick = null)
    }
}

@Composable
private fun Section(
    title: String?,
    leadingIcon: ImageVector? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = Panel
        ),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(
            Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (title != null) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    if (leadingIcon != null) Icon(leadingIcon, contentDescription = null, tint = Color.White, modifier = Modifier.size(19.dp))
                    Text(title, color = Accent, fontWeight = FontWeight.Bold)
                }
            }

            content()
        }
    }
}

@Composable
private fun SettingSwitch(
    label: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { onChange(!checked) }.padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = null)
    }
}

@Composable
private fun TimeButton(
    label: String,
    minutes: Int,
    modifier: Modifier = Modifier,
    onSet: (Int) -> Unit
) {
    val context = LocalContext.current

    OutlinedButton(
        modifier = modifier,
        onClick = {
            TimePickerDialog(
                context,
                { _, hour, minute ->
                    onSet(hour * 60 + minute)
                },
                minutes / 60,
                minutes % 60,
                true
            ).show()
        }
    ) {
        Text(
            "$label  ${
                String.format(
                    Locale.getDefault(),
                    "%02d:%02d",
                    minutes / 60,
                    minutes % 60
                )
            }"
        )
    }
}

private fun loadAudioFiles(context: Context): List<AudioFileItem> {
    val results = mutableListOf<AudioFileItem>()
    val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val projection = if (Build.VERSION.SDK_INT >= 29) {
        arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.RELATIVE_PATH
        )
    } else {
        arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.DATA
        )
    }
    try {
        context.contentResolver.query(
            collection,
            projection,
            null,
            null,
            "${MediaStore.Audio.Media.DISPLAY_NAME} COLLATE NOCASE ASC"
        )?.use { cursor ->
            val idIndex = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val nameIndex = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val folderColumn = if (Build.VERSION.SDK_INT >= 29) {
                MediaStore.Audio.Media.RELATIVE_PATH
            } else {
                MediaStore.Audio.Media.DATA
            }
            val folderIndex = cursor.getColumnIndex(folderColumn)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idIndex)
                val name = cursor.getString(nameIndex) ?: "Audio"
                val rawPath = if (folderIndex >= 0) cursor.getString(folderIndex) ?: "" else ""
                val folder = if (Build.VERSION.SDK_INT >= 29) {
                    rawPath.trimEnd('/')
                } else {
                    val externalRoot = Environment.getExternalStorageDirectory().absolutePath
                    (File(rawPath).parent ?: "").removePrefix(externalRoot).trimStart('/')
                }
                results += AudioFileItem(
                    ContentUris.withAppendedId(collection, id),
                    name,
                    folder
                )
            }
        }
    } catch (_: Exception) {
    }
    return results
}

private fun getSelectedSoundName(
    context: Context,
    type: String,
    uri: String?,
    customFile: String?,
    toneIndex: Int,
    language: String
): String {
    return when (type) {
        Settings.SOUND_DEFAULT -> {
            val toneName = when (toneIndex) {
                1 -> tr(language, "Potwierdzenie", "Confirmation")
                2 -> tr(language, "Podwójny", "Double")
                else -> tr(language, "Krótki", "Short")
            }

            toneName
        }

        Settings.SOUND_NOTIFICATION -> {
            try {
                val notificationUri = RingtoneManager.getActualDefaultRingtoneUri(
                    context,
                    RingtoneManager.TYPE_NOTIFICATION
                )
                if (notificationUri != null) {
                    RingtoneManager.getRingtone(context, notificationUri)?.getTitle(context)
                        ?: tr(language, "Dźwięk powiadomienia", "Notification sound")
                } else {
                    tr(language, "Brak ustawionego dźwięku powiadomienia", "No notification sound set")
                }
            } catch (_: Exception) {
                tr(language, "Dźwięk powiadomienia", "Notification sound")
            }
        }

        Settings.SOUND_CUSTOM -> {
            if (customFile.isNullOrBlank()) {
                tr(
                    language,
                    "Nie wybrano pliku audio",
                    "No audio file selected"
                )
            } else {
                customFile
            }
        }

        else -> tr(
            language,
            "Nieznany dźwięk",
            "Unknown sound"
        )
    }
}

private fun tr(
    language: String,
    polish: String,
    english: String
): String {
    return if (
        language == Settings.LANGUAGE_ENGLISH
    ) {
        english
    } else {
        polish
    }
}

private fun getAppVersion(context: Context): String {
    return try {
        val packageInfo = context.packageManager.getPackageInfo(
            context.packageName,
            0
        )

        packageInfo.versionName ?: "Unknown"
    } catch (_: Exception) {
        "Unknown"
    }
}

private fun hasDndAccess(context: Context): Boolean {
    val notificationManager =
        context.getSystemService(
            Context.NOTIFICATION_SERVICE
        ) as NotificationManager

    return notificationManager.isNotificationPolicyAccessGranted
}

private fun updateService(
    context: Context,
    start: Boolean
) {
    val intent = Intent(
        context,
        FlipMonitorService::class.java
    )

    if (start) {
        ContextCompat.startForegroundService(
            context,
            intent
        )
    } else {
        context.stopService(intent)
    }
}

