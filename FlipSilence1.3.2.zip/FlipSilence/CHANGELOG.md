# Flip Silence — Changelog

## 1.3.2

- Replaced the Language, Vibrations, and Audio Stream Selection pages with compact dialog-based selectors.
- Made language and audio-stream choices immediate, with full-row selection; vibration changes now use explicit OK and Cancel confirmation.
- Extended the navy header treatment edge-to-edge across the home screen and all remaining pages.
- Added a consistent app-name and version footer to every screen.
- Removed section headers from DND sounds, Allowed Exceptions, and Exclusion Conditions; retained the Allowed Exceptions description.
- Centered the About page content vertically between its header and footer.
- Added a right-side scroll indicator that appears only while scrollable content is moving.
- Improved immediate sound-source selection state handling.
- Updated GitHub Actions to Node.js 24-compatible action releases and serialized builds to reduce cache-write collisions.
- Updated the deprecated auto-mirrored Volume Up icon usage.
- Updated app version to 1.3.2.

## 1.3.1

- Refined the main screen with a solid navy header banner, a prominent activation card, and the app-operation notification toggle below the schedule.
- Reordered the Sounds and Signals and Audio Stream Selection settings entries.
- Improved settings section and navigation icons, back-button alignment, and header spacing.
- Made vibration toggles and sound-source choices fully clickable across their rows, with subtle touch feedback.
- Added consistent touch feedback to interactive controls.
- Fixed sound preview playback so a new preview restarts the sound and stops/releases any previous preview; previews are stopped when leaving sound configuration.
- Simplified the Flip Silence tone selector by removing redundant Preview buttons; selecting a tone previews it.
- Removed Preview and Stop controls from the custom audio browser; selecting a file previews it, while Cancel and OK remain fixed at the bottom.
- Fixed immediate selection-state and notification-sound label updates.
- Preserved and displayed the original filename for selected custom audio files.
- Fixed the About page paragraph break.
- Updated app version to 1.3.1.

## 1.3.0


- Redesigned the main screen and settings navigation with consistent headers and horizontal page transitions.
- Reorganized settings into General, Sounds, and Operation sections.
- Added first-launch language detection based on the Android system language. Manual language selection is retained afterward.
- Updated language selection labels to “Polski” and “English”.
- Added independent Flip Silence tones for DND activation and deactivation, with tone previews.
- Added Notification sound as a read-only sound source; the app does not change the device's default notification sound.
- Improved custom audio selection with in-app browsing and preview before confirmation.
- Added playback-completion sequencing: the activation sound finishes before DND is enabled; DND is disabled before the deactivation sound plays.
- Added an emergency fallback so DND activation is not left pending if sound playback fails.
- Renamed and reorganized allowed DND exceptions, vibration settings, and audio stream selection.
- Added immediate schedule persistence and service reevaluation when schedule settings change.
- Added an activation switch with an explicit prompt when Do Not Disturb access is missing.
- Added an About page, an in-app changelog dialog, and project-support links.
- Updated the README and project documentation.

## 1.2.0

- Added separate sound volume settings for DND activation and deactivation.
- Added configurable audio stream selection, with alarms selected by default.
- Improved sound settings and selected-sound labels.
- Added and refined exclusion conditions and monitoring settings.

## 1.1.1

- Maintenance and stability updates.

## 1.0.1

- Added separate confirmation-sound controls for enabling and disabling DND.
- Added three built-in confirmation tones.
- Added sound-volume control and optional vibration.
- Confirmation sounds play only when the app actually changes the DND state.
