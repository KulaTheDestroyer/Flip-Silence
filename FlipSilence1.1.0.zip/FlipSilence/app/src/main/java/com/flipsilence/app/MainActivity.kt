
package com.flipsilence.app

import android.Manifest
import android.app.TimePickerDialog
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.media.RingtoneManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

private val Bg = Color(0xFF101827)
private val Panel = Color(0xFF1D2A3D)
private val Accent = Color(0xFF9BAEFF)
private val Muted = Color(0xFFB8C4D6)

private enum class SoundTarget {
    ENABLE, DISABLE
}

class MainActivity : ComponentActivity() {
    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (
            Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            FlipSilenceScreen()
        }
    }
}

@Composable
private fun FlipSilenceScreen() {
    val context = LocalContext.current

    var language by remember {
        mutableStateOf(Settings.language(context))
    }

    var showSettings by remember {
        mutableStateOf(false)
    }

    var enabled by remember { mutableStateOf(Settings.enabled(context)) }
    var schedule by remember { mutableStateOf(Settings.scheduleEnabled(context)) }
    var start by remember { mutableIntStateOf(Settings.startMinute(context)) }
    var end by remember { mutableIntStateOf(Settings.endMinute(context)) }
    var days by remember { mutableIntStateOf(Settings.daysMask(context)) }
    var delay by remember { mutableFloatStateOf(Settings.delayMs(context).toFloat()) }

    var torch by remember { mutableStateOf(Settings.blockTorch(context)) }
    var media by remember { mutableStateOf(Settings.blockMedia(context)) }
    var headphones by remember { mutableStateOf(Settings.blockHeadphones(context)) }
    var unlockedScreen by remember { mutableStateOf(Settings.blockUnlockedScreen(context)) }
    var camera by remember { mutableStateOf(Settings.blockCamera(context)) }

    var battery by remember { mutableIntStateOf(Settings.minBattery(context)) }
    var permission by remember { mutableStateOf(hasDndAccess(context)) }

    var soundEnable by remember { mutableStateOf(Settings.soundOnEnable(context)) }
    var soundDisable by remember { mutableStateOf(Settings.soundOnDisable(context)) }
    var soundVolume by remember { mutableIntStateOf(Settings.soundVolume(context)) }
    var soundTone by remember { mutableIntStateOf(Settings.soundTone(context)) }
    var soundStream by remember { mutableStateOf(Settings.soundStream(context)) }

    var vibrationEnable by remember {
        mutableStateOf(Settings.vibrationOnEnable(context))
    }
    var vibrationDisable by remember {
        mutableStateOf(Settings.vibrationOnDisable(context))
    }

    var refreshSounds by remember { mutableIntStateOf(0) }
    var pendingSoundTarget by remember { mutableStateOf(SoundTarget.ENABLE) }

    val ringtonePicker = androidx.activity.compose.rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val uri = result.data?.getParcelableExtra<Uri>(
                RingtoneManager.EXTRA_RINGTONE_PICKED_URI
            )

            if (uri != null) {
                when (pendingSoundTarget) {
                    SoundTarget.ENABLE -> {
                        Settings.setSoundOnType(context, Settings.SOUND_SYSTEM)
                        Settings.setSoundOnUri(context, uri.toString())
                    }
                    SoundTarget.DISABLE -> {
                        Settings.setSoundOffType(context, Settings.SOUND_SYSTEM)
                        Settings.setSoundOffUri(context, uri.toString())
                    }
                }
                refreshSounds++
            }
        }
    }

    val customPicker = androidx.activity.compose.rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                val directory = File(context.filesDir, "sounds")
                if (!directory.exists()) directory.mkdirs()

                val fileName = if (pendingSoundTarget == SoundTarget.ENABLE) {
                    "sound_on"
                } else {
                    "sound_off"
                }

                val extension = when (context.contentResolver.getType(uri)) {
                    "audio/mpeg" -> ".mp3"
                    "audio/wav", "audio/x-wav" -> ".wav"
                    "audio/ogg", "application/ogg" -> ".ogg"
                    "audio/mp4", "audio/m4a" -> ".m4a"
                    else -> ".audio"
                }

                val destination = File(directory, fileName + extension)

                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(destination).use { output ->
                        input.copyTo(output)
                    }
                } ?: throw IllegalStateException("Nie można otworzyć pliku")

                when (pendingSoundTarget) {
                    SoundTarget.ENABLE -> {
                        Settings.setSoundOnType(context, Settings.SOUND_CUSTOM)
                        Settings.setSoundOnCustomFile(context, destination.name)
                    }
                    SoundTarget.DISABLE -> {
                        Settings.setSoundOffType(context, Settings.SOUND_CUSTOM)
                        Settings.setSoundOffCustomFile(context, destination.name)
                    }
                }

                refreshSounds++
            } catch (_: Exception) {
                android.widget.Toast.makeText(
                    context,
                    tr(language, "Nie udało się skopiować pliku audio.", "Could not copy the audio file."),
                    android.widget.Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    fun openSystemSoundPicker(target: SoundTarget) {
        pendingSoundTarget = target

        val existing = if (target == SoundTarget.ENABLE) {
            Settings.soundOnUri(context)
        } else {
            Settings.soundOffUri(context)
        }

        val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(
                RingtoneManager.EXTRA_RINGTONE_TYPE,
                RingtoneManager.TYPE_ALL
            )
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
            putExtra(
                RingtoneManager.EXTRA_RINGTONE_TITLE,
                tr(language, "Wybierz dźwięk", "Choose a sound")
            )
            if (!existing.isNullOrBlank()) {
                putExtra(
                    RingtoneManager.EXTRA_RINGTONE_EXISTING_URI,
                    Uri.parse(existing)
                )
            }
        }

        ringtonePicker.launch(intent)
    }

    fun openCustomSoundPicker(target: SoundTarget) {
        pendingSoundTarget = target
        customPicker.launch(arrayOf("audio/*"))
    }

    fun previewSound(target: SoundTarget) {
        val type = if (target == SoundTarget.ENABLE) {
            Settings.soundOnType(context)
        } else {
            Settings.soundOffType(context)
        }

        val uri = if (target == SoundTarget.ENABLE) {
            Settings.soundOnUri(context)
        } else {
            Settings.soundOffUri(context)
        }

        val fileName = if (target == SoundTarget.ENABLE) {
            Settings.soundOnCustomFile(context)
        } else {
            Settings.soundOffCustomFile(context)
        }

        playSelectedSound(
            context = context,
            type = type,
            uri = uri,
            customFile = fileName,
            toneIndex = soundTone,
            volume = soundVolume,
            stream = soundStream
        )
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Bg,
            surface = Panel
        )
    ) {
        if (showSettings) {
            SettingsScreen(
                language = language,
                onLanguageChange = {
                    language = it
                    Settings.setLanguage(context, it)
                },
                onBack = { showSettings = false }
            )
        } else {
            Column(
                Modifier
                    .fillMaxSize()
                    .background(Bg)
                    .safeDrawingPadding()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "FLIP SILENCE",
                        color = Accent,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )

                    TextButton(onClick = { showSettings = true }) {
                        Text("⚙", color = Accent, style = MaterialTheme.typography.headlineMedium)
                    }
                }

                Text(
                    tr(language, "Cisza jednym\nodwróceniem.", "Silence with a\nsingle flip."),
                    color = Color.White,
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    tr(
                        language,
                        "Odwróć telefon ekranem do dołu, aby włączyć Nie przeszkadzać. Odwróć go ekranem do góry, aby przywrócić poprzedni stan.",
                        "Turn your phone face down to enable Do Not Disturb. Turn it face up to restore the previous state."
                    ),
                    color = Muted
                )

                Card(
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Column(
                        Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    tr(language, "Automatyzacja", "Automation"),
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    if (enabled) {
                                        tr(language, "Monitorowanie położenia aktywne", "Orientation monitoring is active")
                                    } else {
                                        tr(language, "Automatyzacja wyłączona", "Automation is disabled")
                                    },
                                    color = Muted,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }

                            Switch(
                                checked = enabled,
                                onCheckedChange = { value ->
                                    if (value && !hasDndAccess(context)) {
                                        context.startActivity(
                                            Intent(AndroidSettings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                                        )
                                    } else {
                                        enabled = value
                                        Settings.setEnabled(context, value)
                                        updateService(context, value)
                                    }
                                }
                            )
                        }

                        Button(
                            onClick = {
                                context.startActivity(
                                    Intent(AndroidSettings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                                )
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                if (permission) {
                                    tr(language, "Uprawnienie DND: przyznane", "DND permission: granted")
                                } else {
                                    tr(language, "Nadaj dostęp do Nie przeszkadzać", "Grant Do Not Disturb access")
                                }
                            )
                        }

                        Text(
                            tr(
                                language,
                                "Usługa działa jako widoczne powiadomienie, aby Android nie usypiał monitorowania czujnika.",
                                "The service uses a visible notification to help Android keep sensor monitoring active."
                            ),
                            color = Color(0xFF9EADC2),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                Section(tr(language, "Harmonogram", "Schedule")) {
                    SettingSwitch(
                        tr(language, "Ogranicz działanie do godzin", "Limit operation to specific hours"),
                        schedule
                    ) {
                        schedule = it
                        Settings.setScheduleEnabled(context, it)
                        if (enabled) updateService(context, true)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        TimeButton(
                            tr(language, "Od", "From"),
                            start,
                            Modifier.weight(1f)
                        ) {
                            start = it
                            Settings.setStartMinute(context, it)
                        }

                        TimeButton(
                            tr(language, "Do", "To"),
                            end,
                            Modifier.weight(1f)
                        ) {
                            end = it
                            Settings.setEndMinute(context, it)
                        }
                    }

                    Text(
                        tr(language, "Dni tygodnia", "Days of the week"),
                        color = Color.White,
                        fontWeight = FontWeight.Medium
                    )

                    val names = if (language == Settings.LANGUAGE_ENGLISH) {
                        listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
                    } else {
                        listOf("Pn", "Wt", "Śr", "Cz", "Pt", "Sb", "Nd")
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        names.forEachIndexed { index, name ->
                            val bit = 1 shl index
                            FilterChip(
                                selected = days and bit != 0,
                                onClick = {
                                    days = days xor bit
                                    Settings.setDaysMask(context, days)
                                },
                                label = { Text(name) }
                            )
                        }
                    }

                    Text(
                        tr(
                            language,
                            "Harmonogram dotyczy momentu aktywacji. Gdy okno czasowe się kończy, aplikacja przywraca poprzedni stan DND.",
                            "The schedule controls when automation may activate. When the time window ends, the app restores the previous DND state."
                        ),
                        color = Color(0xFF9EADC2),
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Section(tr(language, "Warunki wykluczające", "Exclusion conditions")) {
                    SettingSwitch(
                        tr(language, "Nie działaj, gdy latarka jest włączona", "Do not activate while the flashlight is on"),
                        torch
                    ) {
                        torch = it
                        Settings.setBlockTorch(context, it)
                    }

                    SettingSwitch(
                        tr(language, "Nie działaj podczas odtwarzania multimediów", "Do not activate during media playback"),
                        media
                    ) {
                        media = it
                        Settings.setBlockMedia(context, it)
                    }

                    SettingSwitch(
                        tr(language, "Nie działaj, gdy podłączone są słuchawki", "Do not activate when headphones are connected"),
                        headphones
                    ) {
                        headphones = it
                        Settings.setBlockHeadphones(context, it)
                    }

                    SettingSwitch(
                        tr(language, "Nie działaj, gdy ekran jest odblokowany", "Do not activate while the screen is unlocked"),
                        unlockedScreen
                    ) {
                        unlockedScreen = it
                        Settings.setBlockUnlockedScreen(context, it)
                    }

                    SettingSwitch(
                        tr(language, "Nie działaj podczas używania aparatu", "Do not activate while the camera is in use"),
                        camera
                    ) {
                        camera = it
                        Settings.setBlockCamera(context, it)
                    }

                    Text(
                        tr(
                            language,
                            "Minimalny poziom baterii: ${battery}% (0 = bez ograniczenia)",
                            "Minimum battery level: ${battery}% (0 = no limit)"
                        ),
                        color = Color.White
                    )

                    Slider(
                        value = battery.toFloat(),
                        onValueChange = { battery = it.toInt() },
                        onValueChangeFinished = {
                            Settings.setMinBattery(context, battery)
                        },
                        valueRange = 0f..50f,
                        steps = 9
                    )
                }

                Section(tr(language, "Dźwięki i sygnały", "Sounds and signals")) {
                    SettingSwitch(
                        tr(language, "Odtwórz dźwięk przy włączaniu DND", "Play a sound when enabling DND"),
                        soundEnable
                    ) {
                        soundEnable = it
                        Settings.setSoundOnEnable(context, it)
                    }

                    SoundEditor(
                        title = tr(language, "Dźwięk włączenia", "Enable sound"),
                        type = Settings.soundOnType(context),
                        onDefault = {
                            Settings.setSoundOnType(context, Settings.SOUND_DEFAULT)
                            refreshSounds++
                        },
                        onSystem = {
                            openSystemSoundPicker(SoundTarget.ENABLE)
                        },
                        onCustom = {
                            openCustomSoundPicker(SoundTarget.ENABLE)
                        },
                        onPreview = {
                            previewSound(SoundTarget.ENABLE)
                        },
                        language = language,
                        refreshKey = refreshSounds
                    )

                    Divider(color = Color(0xFF34445B))

                    SettingSwitch(
                        tr(language, "Odtwórz dźwięk przy wyłączaniu DND", "Play a sound when disabling DND"),
                        soundDisable
                    ) {
                        soundDisable = it
                        Settings.setSoundOnDisable(context, it)
                    }

                    SoundEditor(
                        title = tr(language, "Dźwięk wyłączenia", "Disable sound"),
                        type = Settings.soundOffType(context),
                        onDefault = {
                            Settings.setSoundOffType(context, Settings.SOUND_DEFAULT)
                            refreshSounds++
                        },
                        onSystem = {
                            openSystemSoundPicker(SoundTarget.DISABLE)
                        },
                        onCustom = {
                            openCustomSoundPicker(SoundTarget.DISABLE)
                        },
                        onPreview = {
                            previewSound(SoundTarget.DISABLE)
                        },
                        language = language,
                        refreshKey = refreshSounds
                    )

                    Divider(color = Color(0xFF34445B))

                    Text(
                        tr(language, "Strumień dźwięku", "Audio stream"),
                        color = Color.White,
                        fontWeight = FontWeight.Medium
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        StreamChoice(
                            tr(language, "Multimedia", "Media"),
                            soundStream == Settings.STREAM_MEDIA
                        ) {
                            soundStream = Settings.STREAM_MEDIA
                            Settings.setSoundStream(context, soundStream)
                        }

                        StreamChoice(
                            tr(language, "Powiadomienia", "Notifications"),
                            soundStream == Settings.STREAM_NOTIFICATION
                        ) {
                            soundStream = Settings.STREAM_NOTIFICATION
                            Settings.setSoundStream(context, soundStream)
                        }

                        StreamChoice(
                            tr(language, "Alarm", "Alarm"),
                            soundStream == Settings.STREAM_ALARM
                        ) {
                            soundStream = Settings.STREAM_ALARM
                            Settings.setSoundStream(context, soundStream)
                        }
                    }

                    // RODZAJ DOMYŚLNEGO SYGNAŁU
                    Text(
                        tr(
                            language,
                            "Rodzaj domyślnego sygnału",
                            "Default sound tone"
                        ),
                        color = Color.White,
                        fontWeight = FontWeight.Medium
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val tones = if (language == Settings.LANGUAGE_ENGLISH) {
                            listOf("Short", "Confirm", "Double")
                        } else {
                            listOf("Krótki", "Potwierdzenie", "Podwójny")
                        }

                        tones.forEachIndexed { index, label ->
                            FilterChip(
                                selected = soundTone == index,
                                onClick = {
                                    soundTone = index
                                    Settings.setSoundTone(context, index)
                                },
                                label = { Text(label) }
                            )
                        }
                    }

                    Text(
                        tr(language, "Głośność sygnału: $soundVolume%", "Sound volume: $soundVolume%"),
                        color = Color.White
                    )

                    Slider(
                        value = soundVolume.toFloat(),
                        onValueChange = { soundVolume = it.toInt() },
                        onValueChangeFinished = {
                            Settings.setSoundVolume(context, soundVolume)
                        },
                        valueRange = 0f..100f,
                        steps = 9
                    )

                    SettingSwitch(
                        tr(language, "Wibracja przy włączaniu DND", "Vibrate when enabling DND"),
                        vibrationEnable
                    ) {
                        vibrationEnable = it
                        Settings.setVibrationOnEnable(context, it)
                    }

                    SettingSwitch(
                        tr(language, "Wibracja przy wyłączaniu DND", "Vibrate when disabling DND"),
                        vibrationDisable
                    ) {
                        vibrationDisable = it
                        Settings.setVibrationOnDisable(context, it)
                    }

                    Text(
                        tr(
                            language,
                            "Wybierz osobny dźwięk dla włączenia i wyłączenia DND. Możesz użyć dźwięku domyślnego, dźwięku systemowego albo własnego pliku audio.",
                            "Choose separate sounds for enabling and disabling DND. You can use the default sound, a system sound, or your own audio file."
                        ),
                        color = Color(0xFF9EADC2),
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Section(tr(language, "Czułość i opóźnienie", "Sensitivity and delay")) {
                    Text(
                        tr(
                            language,
                            "Opóźnienie przed zmianą DND: ${delay.toInt()} ms",
                            "Delay before changing DND: ${delay.toInt()} ms"
                        ),
                        color = Color.White
                    )

                    Slider(
                        value = delay,
                        onValueChange = { delay = it },
                        onValueChangeFinished = {
                            Settings.setDelayMs(context, delay.toInt())
                            if (enabled) updateService(context, true)
                        },
                        valueRange = 0f..2000f,
                        steps = 7
                    )

                    Text(
                        tr(
                            language,
                            "Wyższa wartość pomaga uniknąć przypadkowego uruchomienia podczas odkładania telefonu.",
                            "A longer delay helps prevent accidental activation when putting the phone down."
                        ),
                        color = Color(0xFF9EADC2),
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Text(
                    "Version 1.1.0 • Flip Silence",
                    color = Color(0xFF718096),
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }
        }
    }

    LaunchedEffect(Unit) {
        permission = hasDndAccess(context)
    }

    LaunchedEffect(showSettings) {
        if (!showSettings) {
            permission = hasDndAccess(context)
        }
    }
}

@Composable
private fun SettingsScreen(
    language: String,
    onLanguageChange: (String) -> Unit,
    onBack: () -> Unit
) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Bg,
            surface = Panel
        )
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .background(Bg)
                .safeDrawingPadding()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onBack) {
                    Text(
                        "‹  ${tr(language, "Wróć", "Back")}",
                        color = Accent
                    )
                }

                Spacer(Modifier.weight(1f))

                Text(
                    tr(language, "USTAWIENIA", "SETTINGS"),
                    color = Accent,
                    fontWeight = FontWeight.Bold
                )
            }

            Text(
                tr(language, "Język aplikacji", "Application language"),
                color = Color.White,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = Panel),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(
                    Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    LanguageChoice(
                        label = "Polish",
                        selected = language == Settings.LANGUAGE_POLISH
                    ) {
                        onLanguageChange(Settings.LANGUAGE_POLISH)
                    }

                    LanguageChoice(
                        label = "English",
                        selected = language == Settings.LANGUAGE_ENGLISH
                    ) {
                        onLanguageChange(Settings.LANGUAGE_ENGLISH)
                    }
                }
            }

            Text(
                tr(
                    language,
                    "Wybrany język zostanie zapamiętany i będzie używany również po ponownym uruchomieniu aplikacji.",
                    "Your selected language will be saved and used after restarting the application."
                ),
                color = Muted,
                style = MaterialTheme.typography.bodySmall
            )

            Spacer(Modifier.weight(1f))

            Text(
                "Flip Silence 1.1.0",
                color = Color(0xFF718096),
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
        }
    }
}

@Composable
private fun LanguageChoice(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            color = Color.White,
            modifier = Modifier.weight(1f)
        )

        RadioButton(
            selected = selected,
            onClick = onClick
        )
    }
}

@Composable
private fun SoundEditor(
    title: String,
    type: String,
    onDefault: () -> Unit,
    onSystem: () -> Unit,
    onCustom: () -> Unit,
    onPreview: () -> Unit,
    language: String,
    refreshKey: Int
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            title,
            color = Color.White,
            fontWeight = FontWeight.Medium
        )

        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            SoundTypeChoice(
                tr(language, "Domyślny sygnał aplikacji", "Default app sound"),
                type == Settings.SOUND_DEFAULT,
                onDefault
            )

            SoundTypeChoice(
                tr(language, "Dźwięk systemowy", "System sound"),
                type == Settings.SOUND_SYSTEM,
                onSystem
            )

            SoundTypeChoice(
                tr(language, "Własny plik audio", "Custom audio file"),
                type == Settings.SOUND_CUSTOM,
                onCustom
            )
        }

        OutlinedButton(
            onClick = onPreview,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(tr(language, "Odsłuchaj", "Preview"))
        }
    }
}

@Composable
private fun SoundTypeChoice(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            color = Color.White,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodyMedium
        )

        RadioButton(
            selected = selected,
            onClick = onClick
        )
    }
}

@Composable
private fun StreamChoice(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            color = Color.White,
            modifier = Modifier.weight(1f)
        )

        RadioButton(
            selected = selected,
            onClick = onClick
        )
    }
}

@Composable
private fun Section(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(
            Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                title,
                color = Accent,
                fontWeight = FontWeight.Bold
            )
            content()
        }
    }
}

@Composable
private fun SettingSwitch(
    label: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            label,
            color = Color.White,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodyMedium
        )

        Switch(
            checked = checked,
            onCheckedChange = onChange
        )
    }
}

@Composable
private fun TimeButton(
    label: String,
    minutes: Int,
    modifier: Modifier = Modifier,
    onSet: (Int) -> Unit
) {
    val context = LocalContext.current

    OutlinedButton(
        modifier = modifier,
        onClick = {
            TimePickerDialog(
                context,
                { _, hour, minute ->
                    onSet(hour * 60 + minute)
                },
                minutes / 60,
                minutes % 60,
                true
            ).show()
        }
    ) {
        Text(
            "$label  ${
                String.format(
                    Locale.getDefault(),
                    "%02d:%02d",
                    minutes / 60,
                    minutes % 60
                )
            }"
        )
    }
}

private fun tr(
    language: String,
    polish: String,
    english: String
): String {
    return if (language == Settings.LANGUAGE_ENGLISH) english else polish
}

private fun hasDndAccess(context: Context): Boolean {
    val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    return notificationManager.isNotificationPolicyAccessGranted
}

private fun updateService(context: Context, start: Boolean) {
    val intent = Intent(context, FlipMonitorService::class.java)

    if (start) {
        ContextCompat.startForegroundService(context, intent)
    } else {
        context.stopService(intent)
    }
}

private fun playSelectedSound(
    context: Context,
    type: String,
    uri: String?,
    customFile: String?,
    toneIndex: Int,
    volume: Int,
    stream: String
) {
    if (volume <= 0) return

    val audioUsage = when (stream) {
        Settings.STREAM_NOTIFICATION -> AudioAttributes.USAGE_NOTIFICATION
        Settings.STREAM_ALARM -> AudioAttributes.USAGE_ALARM
        else -> AudioAttributes.USAGE_MEDIA
    }

    if (type == Settings.SOUND_DEFAULT) {
        val tone = when (toneIndex) {
            1 -> ToneGenerator.TONE_PROP_ACK
            2 -> ToneGenerator.TONE_PROP_BEEP2
            else -> ToneGenerator.TONE_PROP_BEEP
        }

        val audioStream = when (stream) {
            Settings.STREAM_NOTIFICATION -> AudioManager.STREAM_NOTIFICATION
            Settings.STREAM_ALARM -> AudioManager.STREAM_ALARM
            else -> AudioManager.STREAM_MUSIC
        }

        try {
            val generator = ToneGenerator(
                audioStream,
                volume.coerceIn(0, 100)
            )

            generator.startTone(tone, 650)

            android.os.Handler(android.os.Looper.getMainLooper())
                .postDelayed({
                    try {
                        generator.release()
                    } catch (_: Exception) {
                    }
                }, 900L)
        } catch (_: Exception) {
        }

        return
    }

    val soundUri: Uri? = when (type) {
        Settings.SOUND_SYSTEM -> {
            uri?.let { Uri.parse(it) }
        }

        Settings.SOUND_CUSTOM -> {
            if (customFile.isNullOrBlank()) {
                null
            } else {
                val file = File(File(context.filesDir, "sounds"), customFile)
                if (file.exists()) Uri.fromFile(file) else null
            }
        }

        else -> null
    }

    if (soundUri == null) {
        android.widget.Toast.makeText(
            context,
            "Nie wybrano dźwięku lub plik nie istnieje.",
            android.widget.Toast.LENGTH_SHORT
        ).show()
        return
    }

    try {
        val player = MediaPlayer()

        player.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(audioUsage)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )

        player.setVolume(
            volume.coerceIn(0, 100) / 100f,
            volume.coerceIn(0, 100) / 100f
        )

        player.setDataSource(context, soundUri)

        player.setOnPreparedListener {
            it.start()
        }

        player.setOnCompletionListener {
            it.release()
        }

        player.setOnErrorListener { mp, _, _ ->
            mp.release()
            true
        }

        player.prepareAsync()
    } catch (_: Exception) {
        android.widget.Toast.makeText(
            context,
            "Nie udało się odtworzyć wybranego dźwięku.",
            android.widget.Toast.LENGTH_SHORT
        ).show()
    }
}
