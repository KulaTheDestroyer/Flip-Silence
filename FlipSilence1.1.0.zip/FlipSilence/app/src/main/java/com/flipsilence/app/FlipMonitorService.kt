
package com.flipsilence.app

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.AudioPlaybackConfiguration
import android.media.MediaPlayer
import android.media.ToneGenerator
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import androidx.core.app.NotificationCompat
import java.io.File
import java.util.Calendar

class FlipMonitorService : Service(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private lateinit var notificationManager: NotificationManager
    private lateinit var audioManager: AudioManager
    private lateinit var cameraManager: CameraManager

    private val handler = Handler(Looper.getMainLooper())

    private var faceDown = false
    private var pendingFaceDown: Boolean? = null
    private var pendingRunnable: Runnable? = null

    private var torchOn = false
    private var torchCallback: CameraManager.TorchCallback? = null
    private var cameraAvailabilityCallback: CameraManager.AvailabilityCallback? = null

    private var sensorAvailable = false

    // Monitorowanie aktywnych sesji multimedialnych.
    private var mediaPlaying = false
    private var playbackMonitoringAvailable = false

    // Kamery aktualnie używane przez aplikacje.
    private val busyCameras = mutableSetOf<String>()

    // Odtwarzanie dźwięków potwierdzających.
    private var mediaPlayer: MediaPlayer? = null
    private var toneGenerator: ToneGenerator? = null
    private var toneReleaseRunnable: Runnable? = null

    // Zabezpieczenie przed odtwarzaniem podczas zamykania usługi.
    private var destroying = false

    private val periodicCheck = object : Runnable {
        override fun run() {
            evaluateAutomation()
            handler.postDelayed(this, 15_000L)
        }
    }

    // Monitorowanie odtwarzania audio (Android 8.0+).
    private val playbackCallback =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            object : AudioManager.AudioPlaybackCallback() {
                override fun onPlaybackConfigChanged(
                    configs: MutableList<AudioPlaybackConfiguration>
                ) {
                    updateMediaPlayback(configs)
                }
            }
        } else {
            null
        }

    private fun updateMediaPlayback(
    configs: List<AudioPlaybackConfiguration>
) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return

    mediaPlaying = try {
        configs.any { config ->
            config.isActive() &&
                config.audioAttributes.usage ==
                AudioAttributes.USAGE_MEDIA
        }
    } catch (e: Exception) {
        Log.w(TAG, "Could not inspect audio playback configurations", e)
        false
    }

    evaluateAutomation()
}

    // Monitorowanie dostępności kamer.
    private fun registerCameraAvailabilityCallback() {
        val callback = object : CameraManager.AvailabilityCallback() {

            override fun onCameraUnavailable(cameraId: String) {
                synchronized(busyCameras) {
                    busyCameras.add(cameraId)
                }
                evaluateAutomation()
            }

            override fun onCameraAvailable(cameraId: String) {
                synchronized(busyCameras) {
                    busyCameras.remove(cameraId)
                }
                evaluateAutomation()
            }
        }

        cameraAvailabilityCallback = callback

        try {
            cameraManager.registerAvailabilityCallback(callback, handler)
        } catch (e: Exception) {
            Log.w(TAG, "Camera availability monitoring unavailable", e)
        }
    }

    private fun registerPlaybackCallback() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return

        try {
            val callback = playbackCallback ?: return

            audioManager.registerAudioPlaybackCallback(callback, handler)
            playbackMonitoringAvailable = true

            try {
                updateMediaPlayback(audioManager.activePlaybackConfigurations)
            } catch (e: SecurityException) {
                Log.w(TAG, "Cannot read active playback configurations", e)
            }
        } catch (e: Exception) {
            playbackMonitoringAvailable = false
            mediaPlaying = false
            Log.w(TAG, "Audio playback monitoring unavailable", e)
        }
    }

    override fun onCreate() {
        super.onCreate()

        notificationManager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        audioManager =
            getSystemService(Context.AUDIO_SERVICE) as AudioManager

        sensorManager =
            getSystemService(Context.SENSOR_SERVICE) as SensorManager

        cameraManager =
            getSystemService(Context.CAMERA_SERVICE) as CameraManager

        createNotificationChannel()

        startForeground(
            NOTIFICATION_ID,
            buildNotification()
        )

        val sensor =
            sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        if (sensor != null) {
            sensorAvailable = sensorManager.registerListener(
                this,
                sensor,
                SensorManager.SENSOR_DELAY_NORMAL
            )
        }

        registerTorchCallback()
        registerCameraAvailabilityCallback()
        registerPlaybackCallback()

        handler.post(periodicCheck)
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {
        if (!Settings.enabled(this)) {
            stopSelf()
            return START_NOT_STICKY
        }

        evaluateAutomation()
        return START_STICKY
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return

        val z = event.values[2]

        val candidate = when {
            z < -7.2f -> true
            z > 7.2f -> false
            else -> null
        }

        if (candidate == null) {
            pendingFaceDown = null
            pendingRunnable?.let(handler::removeCallbacks)
            pendingRunnable = null
            return
        }

        if (candidate == faceDown) {
            pendingFaceDown = null
            pendingRunnable?.let(handler::removeCallbacks)
            pendingRunnable = null
            return
        }

        if (pendingFaceDown == candidate && pendingRunnable != null) {
            return
        }

        pendingFaceDown = candidate
        pendingRunnable?.let(handler::removeCallbacks)

        val runnable = Runnable {
            if (pendingFaceDown == candidate) {
                faceDown = candidate
                pendingFaceDown = null
                pendingRunnable = null
                evaluateAutomation()
            }
        }

        pendingRunnable = runnable

        handler.postDelayed(
            runnable,
            Settings.delayMs(this).toLong().coerceAtLeast(0L)
        )
    }

    override fun onAccuracyChanged(
        sensor: Sensor?,
        accuracy: Int
    ) = Unit

    // GŁÓWNA LOGIKA AUTOMATYZACJI

    private fun evaluateAutomation() {
        if (!Settings.enabled(this)) {
            restoreDndIfOwned()
            stopSelf()
            return
        }

        val allowedBySchedule =
            !Settings.scheduleEnabled(this) || isWithinSchedule()

        val allowedByConditions = !isExcluded()

        if (!allowedBySchedule || !allowedByConditions || !faceDown) {
            restoreDndIfOwned()
            return
        }

        enableDndIfAllowed()
    }

    private fun enableDndIfAllowed() {
        if (!notificationManager.isNotificationPolicyAccessGranted) return

        if (Settings.wasOurs(this)) return

        val current =
            notificationManager.currentInterruptionFilter

        if (current == NotificationManager.INTERRUPTION_FILTER_NONE) return

        Settings.setPreviousFilter(this, current)

        try {
            notificationManager.setInterruptionFilter(
                NotificationManager.INTERRUPTION_FILTER_NONE
            )

            Settings.setWasOurs(this, true)
            playConfirmation(enable = true)

        } catch (e: SecurityException) {
            Log.w(TAG, "No permission to change DND", e)
        }
    }

    private fun restoreDndIfOwned() {
        if (!Settings.wasOurs(this)) return

        if (notificationManager.isNotificationPolicyAccessGranted) {
            try {
                if (
                    notificationManager.currentInterruptionFilter ==
                    NotificationManager.INTERRUPTION_FILTER_NONE
                ) {
                    notificationManager.setInterruptionFilter(
                        Settings.previousFilter(this)
                    )

                    playConfirmation(enable = false)
                }
            } catch (e: SecurityException) {
                Log.w(TAG, "Could not restore previous DND state", e)
            }
        }

        Settings.setWasOurs(this, false)
    }

    // DŹWIĘK I WIBRACJA

    private fun playConfirmation(enable: Boolean) {
        if (destroying) return

        val soundEnabled =
            if (enable) Settings.soundOnEnable(this)
            else Settings.soundOnDisable(this)

        val vibrationEnabled =
            if (enable) Settings.vibrationOnEnable(this)
            else Settings.vibrationOnDisable(this)

        if (soundEnabled && Settings.soundVolume(this) > 0) {
            playConfiguredSound(enable)
        }

        if (vibrationEnabled) {
            vibrate()
        }
    }

    private fun playConfiguredSound(enable: Boolean) {
        val soundType =
            if (enable) Settings.soundOnType(this)
            else Settings.soundOffType(this)

        val soundUri =
            if (enable) Settings.soundOnUri(this)
            else Settings.soundOffUri(this)

        val customFile =
            if (enable) Settings.soundOnCustomFile(this)
            else Settings.soundOffCustomFile(this)

        when (soundType) {
            Settings.SOUND_SYSTEM -> {
                if (!soundUri.isNullOrBlank()) {
                    playMediaSound(Uri.parse(soundUri), null)
                } else {
                    playDefaultTone()
                }
            }

            Settings.SOUND_CUSTOM -> {
                if (!customFile.isNullOrBlank() && File(customFile).isFile) {
                    playMediaSound(null, customFile)
                } else {
                    Log.w(TAG, "Custom sound file is missing; using default tone")
                    playDefaultTone()
                }
            }

            else -> playDefaultTone()
        }
    }

    private fun selectedAudioStream(): Int {
        return when (Settings.soundStream(this)) {
            Settings.STREAM_NOTIFICATION -> AudioManager.STREAM_NOTIFICATION
            Settings.STREAM_ALARM -> AudioManager.STREAM_ALARM
            else -> AudioManager.STREAM_MUSIC
        }
    }

    private fun selectedAudioUsage(): Int {
        return when (Settings.soundStream(this)) {
            Settings.STREAM_NOTIFICATION -> AudioAttributes.USAGE_NOTIFICATION
            Settings.STREAM_ALARM -> AudioAttributes.USAGE_ALARM
            else -> AudioAttributes.USAGE_MEDIA
        }
    }

    private fun playDefaultTone() {
        if (destroying) return

        val volume = Settings.soundVolume(this).coerceIn(0, 100)
        if (volume <= 0) return

        val tone = when (Settings.soundTone(this)) {
            1 -> ToneGenerator.TONE_PROP_ACK
            2 -> ToneGenerator.TONE_PROP_BEEP2
            else -> ToneGenerator.TONE_PROP_BEEP
        }

        try {
            releaseToneGenerator()

            val generator = ToneGenerator(
                selectedAudioStream(),
                volume
            )

            toneGenerator = generator
            generator.startTone(tone, 650)

            val releaseRunnable = Runnable {
                if (toneGenerator === generator) {
                    releaseToneGenerator()
                }
            }

            toneReleaseRunnable = releaseRunnable
            handler.postDelayed(releaseRunnable, 900L)

        } catch (e: Exception) {
            Log.w(TAG, "Could not play confirmation tone", e)
            releaseToneGenerator()
        }
    }

    private fun playMediaSound(uri: Uri?, filePath: String?) {
        if (destroying) return

        val volume = Settings.soundVolume(this).coerceIn(0, 100)
        if (volume <= 0) return

        releaseMediaPlayer()
        releaseToneGenerator()

        val player = MediaPlayer()
        mediaPlayer = player

        try {
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(selectedAudioUsage())
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )

            if (uri != null) {
                player.setDataSource(this, uri)
            } else if (!filePath.isNullOrBlank()) {
                player.setDataSource(filePath)
            } else {
                releaseMediaPlayer()
                playDefaultTone()
                return
            }

            val normalizedVolume = volume / 100f
            player.setVolume(normalizedVolume, normalizedVolume)

            player.setOnCompletionListener { completedPlayer ->
                if (mediaPlayer === completedPlayer) {
                    releaseMediaPlayer()
                }
            }

            player.setOnErrorListener { failedPlayer, what, extra ->
                Log.w(
                    TAG,
                    "Confirmation sound playback error: what=$what extra=$extra"
                )

                if (mediaPlayer === failedPlayer) {
                    releaseMediaPlayer()
                    playDefaultTone()
                }

                true
            }

            player.setOnPreparedListener { preparedPlayer ->
                if (mediaPlayer === preparedPlayer && !destroying) {
                    try {
                        preparedPlayer.start()
                    } catch (e: Exception) {
                        Log.w(TAG, "Could not start confirmation sound", e)
                        releaseMediaPlayer()
                        playDefaultTone()
                    }
                }
            }

            player.prepareAsync()

        } catch (e: Exception) {
            Log.w(TAG, "Could not prepare confirmation sound", e)
            releaseMediaPlayer()
            playDefaultTone()
        }
    }

    private fun releaseMediaPlayer() {
        val player = mediaPlayer
        mediaPlayer = null

        if (player != null) {
            try {
                player.setOnCompletionListener(null)
                player.setOnPreparedListener(null)
                player.setOnErrorListener(null)
                player.reset()
                player.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun releaseToneGenerator() {
        toneReleaseRunnable?.let(handler::removeCallbacks)
        toneReleaseRunnable = null

        val generator = toneGenerator
        toneGenerator = null

        try {
            generator?.release()
        } catch (_: Exception) {
        }
    }

    private fun vibrate() {
        if (destroying) return

        try {
            if (Build.VERSION.SDK_INT >= 31) {
                val vibrator =
                    (getSystemService(Context.VIBRATOR_MANAGER_SERVICE)
                        as VibratorManager).defaultVibrator

                if (vibrator.hasVibrator()) {
                    vibrator.vibrate(
                        android.os.VibrationEffect.createOneShot(
                            140,
                            190
                        )
                    )
                }
            } else {
                @Suppress("DEPRECATION")
                val vibrator =
                    getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

                @Suppress("DEPRECATION")
                vibrator.vibrate(140L)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not vibrate", e)
        }
    }

    // WYKLUCZENIE: EKRAN ODBLOKOWANY

    private fun isScreenUnlocked(): Boolean {
        return try {
            val powerManager =
                getSystemService(Context.POWER_SERVICE) as PowerManager

            val keyguardManager =
                getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager

            powerManager.isInteractive &&
                !keyguardManager.isKeyguardLocked
        } catch (e: Exception) {
            Log.w(TAG, "Could not determine screen lock state", e)
            false
        }
    }

    // WYKLUCZENIE: APARAT UŻYWANY

    private fun isCameraInUse(): Boolean {
        return synchronized(busyCameras) {
            busyCameras.isNotEmpty()
        }
    }

    // WYKLUCZENIE: AKTYWNE MULTIMEDIA

    private fun isMediaPlaying(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return false
        if (!playbackMonitoringAvailable) return false
        return mediaPlaying
    }

    // WSZYSTKIE WARUNKI WYKLUCZENIA

    private fun isExcluded(): Boolean {
        if (Settings.blockTorch(this) && torchOn) {
            return true
        }

        if (Settings.blockMedia(this) && isMediaPlaying()) {
            return true
        }

        if (
            Settings.blockUnlockedScreen(this) &&
            isScreenUnlocked()
        ) {
            return true
        }

        if (
            Settings.blockCamera(this) &&
            isCameraInUse()
        ) {
            return true
        }

        if (
            Settings.blockHeadphones(this) &&
            headphonesConnected()
        ) {
            return true
        }

        val threshold = Settings.minBattery(this)

        if (threshold > 0 && batteryPercent() < threshold) {
            return true
        }

        return false
    }

    // SŁUCHAWKI

    private fun headphonesConnected(): Boolean {
    return audioManager
        .getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        .any { device ->
            when (device.type) {
                AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
                AudioDeviceInfo.TYPE_WIRED_HEADSET,
                AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
                AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
                AudioDeviceInfo.TYPE_USB_HEADSET -> true

                else -> {
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                        device.type == AudioDeviceInfo.TYPE_BLE_HEADSET
                }
            }
        }
}

    // BATERIA

    private fun batteryPercent(): Int {
        val intent = registerReceiver(
            null,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        ) ?: return 100

        val level =
            intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)

        val scale =
            intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)

        return if (level >= 0 && scale > 0) {
            level * 100 / scale
        } else {
            100
        }
    }

    // HARMONOGRAM

    private fun isWithinSchedule(): Boolean {
        val start = Settings.startMinute(this)
        val end = Settings.endMinute(this)

        if (start == end) return false

        val cal = Calendar.getInstance()

        val now =
            cal.get(Calendar.HOUR_OF_DAY) * 60 +
                cal.get(Calendar.MINUTE)

        val todayBit =
            dayBit(cal.get(Calendar.DAY_OF_WEEK))

        val previous =
            (cal.clone() as Calendar).apply {
                add(Calendar.DAY_OF_YEAR, -1)
            }

        val previousBit =
            dayBit(previous.get(Calendar.DAY_OF_WEEK))

        return if (start < end) {
            now >= start &&
                now < end &&
                (Settings.daysMask(this) and todayBit != 0)
        } else {
            (now >= start &&
                (Settings.daysMask(this) and todayBit != 0)) ||
                (now < end &&
                    (Settings.daysMask(this) and previousBit != 0))
        }
    }

    private fun dayBit(calendarDay: Int): Int {
        val index =
            if (calendarDay == Calendar.SUNDAY) {
                6
            } else {
                calendarDay - Calendar.MONDAY
            }

        return 1 shl index
    }

    // LATARKA

    private fun registerTorchCallback() {
        val callback = object : CameraManager.TorchCallback() {

            override fun onTorchModeChanged(
                cameraId: String,
                enabled: Boolean
            ) {
                torchOn = enabled
                evaluateAutomation()
            }

            override fun onTorchModeUnavailable(cameraId: String) {
                // Sama niedostępność kamery nie oznacza,
                // że latarka jest włączona.
            }
        }

        torchCallback = callback

        try {
            cameraManager.registerTorchCallback(callback, handler)
        } catch (e: Exception) {
            Log.w(TAG, "Torch callback unavailable", e)
        }
    }

    // POWIADOMIENIE

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Flip Silence – monitoring",
                NotificationManager.IMPORTANCE_LOW
            )

            channel.description =
                "Keeps phone orientation automation active"

            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode)
            .setContentTitle("Flip Silence is active")
            .setContentText(
                if (faceDown) {
                    "Phone face down – checking conditions"
                } else {
                    "Waiting for phone to be flipped"
                }
            )
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

    // ZAMYKANIE USŁUGI

    override fun onDestroy() {
        destroying = true

        handler.removeCallbacks(periodicCheck)

        pendingRunnable?.let {
            handler.removeCallbacks(it)
        }
        pendingRunnable = null

        sensorManager.unregisterListener(this)

        try {
            torchCallback?.let {
                cameraManager.unregisterTorchCallback(it)
            }
        } catch (_: Exception) {
        }

        try {
            cameraAvailabilityCallback?.let {
                cameraManager.unregisterAvailabilityCallback(it)
            }
        } catch (_: Exception) {
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                playbackCallback?.let {
                    audioManager.unregisterAudioPlaybackCallback(it)
                }
            } catch (_: Exception) {
            }
        }

        releaseMediaPlayer()
        releaseToneGenerator()

        restoreDndIfOwned()

        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val TAG = "FlipSilence"
        private const val CHANNEL_ID = "flip_silence_monitor"
        private const val NOTIFICATION_ID = 4107
    }
}
