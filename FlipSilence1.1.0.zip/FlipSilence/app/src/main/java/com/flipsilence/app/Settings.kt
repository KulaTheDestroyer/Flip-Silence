
package com.flipsilence.app

import android.content.Context

object Settings {
    private const val PREFS = "flip_silence_settings"

    private fun p(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // GŁÓWNE USTAWIENIA

    fun enabled(c: Context) = p(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) =
        p(c).edit().putBoolean("enabled", v).apply()

    // HARMONOGRAM

    fun scheduleEnabled(c: Context) =
        p(c).getBoolean("schedule_enabled", false)

    fun setScheduleEnabled(c: Context, v: Boolean) =
        p(c).edit().putBoolean("schedule_enabled", v).apply()

    fun startMinute(c: Context) =
        p(c).getInt("start_minute", 22 * 60)

    fun endMinute(c: Context) =
        p(c).getInt("end_minute", 7 * 60)

    fun setStartMinute(c: Context, v: Int) =
        p(c).edit().putInt("start_minute", v).apply()

    fun setEndMinute(c: Context, v: Int) =
        p(c).edit().putInt("end_minute", v).apply()

    fun daysMask(c: Context) =
        p(c).getInt("days_mask", 127)

    fun setDaysMask(c: Context, v: Int) =
        p(c).edit().putInt("days_mask", v).apply()

    // OPÓŹNIENIE

    fun delayMs(c: Context) =
        p(c).getInt("delay_ms", 500)

    fun setDelayMs(c: Context, v: Int) =
        p(c).edit().putInt("delay_ms", v).apply()

    // WYKLUCZENIA

    fun blockTorch(c: Context) =
        p(c).getBoolean("block_torch", true)

    fun setBlockTorch(c: Context, v: Boolean) =
        p(c).edit().putBoolean("block_torch", v).apply()

    fun blockMedia(c: Context) =
        p(c).getBoolean("block_media", true)

    fun setBlockMedia(c: Context, v: Boolean) =
        p(c).edit().putBoolean("block_media", v).apply()

    fun blockHeadphones(c: Context) =
        p(c).getBoolean("block_headphones", false)

    fun setBlockHeadphones(c: Context, v: Boolean) =
        p(c).edit().putBoolean("block_headphones", v).apply()

    // Nowe wykluczenie: ekran odblokowany

    fun blockUnlockedScreen(c: Context) =
        p(c).getBoolean("block_unlocked_screen", true)

    fun setBlockUnlockedScreen(c: Context, v: Boolean) =
        p(c).edit().putBoolean("block_unlocked_screen", v).apply()

    // Nowe wykluczenie: aparat używany

    fun blockCamera(c: Context) =
        p(c).getBoolean("block_camera", true)

    fun setBlockCamera(c: Context, v: Boolean) =
        p(c).edit().putBoolean("block_camera", v).apply()

    // MINIMALNY POZIOM BATERII

    fun minBattery(c: Context) =
        p(c).getInt("min_battery", 0)

    fun setMinBattery(c: Context, v: Int) =
        p(c).edit().putInt("min_battery", v.coerceIn(0, 100)).apply()

    // DŹWIĘKI WŁĄCZENIA I WYŁĄCZENIA

    fun soundOnEnable(c: Context) =
        p(c).getBoolean("sound_on_enable", true)

    fun setSoundOnEnable(c: Context, v: Boolean) =
        p(c).edit().putBoolean("sound_on_enable", v).apply()

    fun soundOnDisable(c: Context) =
        p(c).getBoolean("sound_on_disable", true)

    fun setSoundOnDisable(c: Context, v: Boolean) =
        p(c).edit().putBoolean("sound_on_disable", v).apply()

    // GŁOŚNOŚĆ DŹWIĘKU

    fun soundVolume(c: Context) =
        p(c).getInt("sound_volume", 65)

    fun setSoundVolume(c: Context, v: Int) =
        p(c).edit().putInt("sound_volume", v.coerceIn(0, 100)).apply()

    // STRUMIEŃ GŁOŚNOŚCI

    const val STREAM_MEDIA = "media"
    const val STREAM_NOTIFICATION = "notification"
    const val STREAM_ALARM = "alarm"

    fun soundStream(c: Context) =
        p(c).getString("sound_stream", STREAM_MEDIA) ?: STREAM_MEDIA

    fun setSoundStream(c: Context, v: String) {
        val valid = when (v) {
            STREAM_MEDIA,
            STREAM_NOTIFICATION,
            STREAM_ALARM -> v
            else -> STREAM_MEDIA
        }

        p(c).edit().putString("sound_stream", valid).apply()
    }

    // WYBÓR ŹRÓDŁA DŹWIĘKU

    const val SOUND_DEFAULT = "default"
    const val SOUND_SYSTEM = "system"
    const val SOUND_CUSTOM = "custom"

    // Dźwięk włączenia DND

    fun soundOnType(c: Context) =
        p(c).getString("sound_on_type", SOUND_DEFAULT) ?: SOUND_DEFAULT

    fun setSoundOnType(c: Context, v: String) =
        p(c).edit().putString("sound_on_type", v).apply()

    fun soundOnUri(c: Context) =
        p(c).getString("sound_on_uri", null)

    fun setSoundOnUri(c: Context, v: String?) =
        p(c).edit().putString("sound_on_uri", v).apply()

    fun soundOnCustomFile(c: Context) =
        p(c).getString("sound_on_custom_file", null)

    fun setSoundOnCustomFile(c: Context, v: String?) =
        p(c).edit().putString("sound_on_custom_file", v).apply()

    // Dźwięk wyłączenia DND

    fun soundOffType(c: Context) =
        p(c).getString("sound_off_type", SOUND_DEFAULT) ?: SOUND_DEFAULT

    fun setSoundOffType(c: Context, v: String) =
        p(c).edit().putString("sound_off_type", v).apply()

    fun soundOffUri(c: Context) =
        p(c).getString("sound_off_uri", null)

    fun setSoundOffUri(c: Context, v: String?) =
        p(c).edit().putString("sound_off_uri", v).apply()

    fun soundOffCustomFile(c: Context) =
        p(c).getString("sound_off_custom_file", null)

    fun setSoundOffCustomFile(c: Context, v: String?) =
        p(c).edit().putString("sound_off_custom_file", v).apply()

    // STARSZE USTAWIENIE TONU - ZACHOWANE DLA KOMPATYBILNOŚCI

    fun soundTone(c: Context) =
        p(c).getInt("sound_tone", 0)

    fun setSoundTone(c: Context, v: Int) =
        p(c).edit().putInt("sound_tone", v.coerceIn(0, 2)).apply()

    // WIBRACJE

    fun vibration(c: Context) =
        p(c).getBoolean("vibration", false)

    fun setVibration(c: Context, v: Boolean) =
        p(c).edit().putBoolean("vibration", v).apply()

    fun vibrationOnEnable(c: Context) =
        p(c).getBoolean("vibration_on_enable", vibration(c))

    fun setVibrationOnEnable(c: Context, v: Boolean) =
        p(c).edit().putBoolean("vibration_on_enable", v).apply()

    fun vibrationOnDisable(c: Context) =
        p(c).getBoolean("vibration_on_disable", vibration(c))

    fun setVibrationOnDisable(c: Context, v: Boolean) =
        p(c).edit().putBoolean("vibration_on_disable", v).apply()

    // JĘZYK APLIKACJI

    const val LANGUAGE_POLISH = "pl"
    const val LANGUAGE_ENGLISH = "en"

    fun language(c: Context) =
        p(c).getString("language", LANGUAGE_POLISH) ?: LANGUAGE_POLISH

    fun setLanguage(c: Context, v: String) {
        val valid = when (v) {
            LANGUAGE_ENGLISH -> LANGUAGE_ENGLISH
            else -> LANGUAGE_POLISH
        }

        p(c).edit().putString("language", valid).apply()
    }

    // ZARZĄDZANIE TRYBEM NIE PRZESZKADZAĆ

    fun wasOurs(c: Context) =
        p(c).getBoolean("dnd_owned", false)

    fun setWasOurs(c: Context, v: Boolean) =
        p(c).edit().putBoolean("dnd_owned", v).apply()

    fun previousFilter(c: Context) =
        p(c).getInt("previous_filter", 1)

    fun setPreviousFilter(c: Context, v: Int) =
        p(c).edit().putInt("previous_filter", v).apply()
}
