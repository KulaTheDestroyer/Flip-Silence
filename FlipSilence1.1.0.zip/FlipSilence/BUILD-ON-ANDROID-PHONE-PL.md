# Jak zbudować APK Flip Silence wyłącznie telefonem

Projekt można skompilować w chmurze przez GitHub Actions. Nie trzeba instalować Android Studio ani SDK na telefonie.

## 1. Utwórz repozytorium GitHub
1. Otwórz https://github.com/new w przeglądarce telefonu i zaloguj się (lub utwórz konto).
2. Nazwij repozytorium `FlipSilence`.
3. Ustaw `Public` albo `Private`, zaznacz dodanie pliku README i utwórz repozytorium.

## 2. Dodaj pliki projektu
1. Rozpakuj ZIP na telefonie.
2. Otwórz repozytorium na GitHubie w Chrome. W razie potrzeby włącz „Wersja na komputer”.
3. Wybierz `Add file` → `Upload files`.
4. Prześlij zawartość folderu `FlipSilence` (nie sam folder): pliki `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, folder `app` oraz folder `.github`.
5. Zatwierdź przez `Commit changes` do gałęzi `main`.

Ważne: folder `.github/workflows` zawiera instrukcję automatycznego budowania APK. Jeśli menedżer plików ukrywa foldery zaczynające się kropką, włącz pokazywanie ukrytych plików.

## 3. Pobierz APK
1. Na GitHubie otwórz zakładkę `Actions` w repozytorium.
2. Wybierz przebieg `Build Flip Silence APK`.
3. Poczekaj, aż zakończy się na zielono (`Success`).
4. Otwórz zakończony przebieg i na dole sekcji `Artifacts` pobierz `Flip-Silence-debug-APK`.
5. Rozpakuj pobrany artefakt ZIP. W środku będzie `app-debug.apk`.
6. Otwórz APK i zezwól przeglądarce/menedżerowi plików na instalowanie nieznanych aplikacji, jeśli Android o to poprosi.

## Uwagi
- To debug APK do prywatnych testów, nie wersja do Google Play.
- Po instalacji trzeba nadać aplikacji dostęp do trybu Nie przeszkadzać i zezwolić na powiadomienia/usługę w tle.
- Na Realme może być konieczne ustawienie baterii aplikacji na „Bez ograniczeń” oraz zezwolenie na autostart.
- Pierwsza kompilacja może potrwać kilka minut.
