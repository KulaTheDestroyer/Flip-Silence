# Flip Silence — Android project

Native Android app (Kotlin + Jetpack Compose) for face-down / face-up Do Not Disturb automation.

## Included in this first MVP

- Accelerometer-based face-down and face-up detection.
- Configurable activation delay (0–2000 ms).
- Do Not Disturb activation and restoration of the previous interruption filter.
- Ownership tracking: the app does not turn off DND if it was already enabled manually, and it avoids overwriting a later manual DND change.
- One daily time window, selected weekdays, including windows crossing midnight.
- Exclusions for active flashlight, media playback, connected headphones, and a configurable low-battery threshold.
- Foreground monitoring service and restart after device boot (when enabled).

## Requirements

- Android Studio with Android SDK Platform 36 installed.
- JDK 17.
- Gradle 8.11.1 / Android Gradle Plugin 8.10.1 (the Gradle distribution is declared in `gradle/wrapper/gradle-wrapper.properties`).

The project contains the Gradle wrapper distribution settings. If Android Studio reports that `gradle-wrapper.jar` is missing, run `gradle wrapper --gradle-version 8.11.1` from this project root on a machine with Gradle installed, then reopen/sync the project. Open the folder in Android Studio, allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK will be generated at:

`app/build/outputs/apk/debug/app-debug.apk`

## First launch

1. Install and open Flip Silence.
2. Grant **Do Not Disturb access** using the button in the app.
3. Enable the automation. Android may also ask for notification permission.
4. Keep the persistent Flip Silence notification enabled while monitoring is active.
5. On Realme UI, if background monitoring is stopped, set battery usage for Flip Silence to **Unrestricted / Allow background activity** and allow auto-launch if that setting is present.

## Important Android limitations

- Android requires explicit user-granted Notification Policy Access before an app can change DND.
- The monitoring service is a `specialUse` foreground service. For distribution through Google Play, the developer must complete the relevant foreground-service declaration/review; this project is intended first for personal sideloading/testing.
- Media detection uses Android's `AudioManager.isMusicActive`; some app/device combinations may not report every playback session identically.
- Torch state depends on the camera torch callback. Some OEM camera stacks may delay or omit initial state callbacks.
- Face-down detection uses accelerometer gravity on the Z axis. Sensor orientation and thresholds should be tested on the target Realme device and can be tuned if needed.
- This MVP provides one time window per day-pattern. Multiple independent windows, app-specific exclusions, Bluetooth-device selection, and a diagnostics screen are planned follow-up features.
- Android/OEM battery management can still stop background services. The persistent notification and battery-optimization settings reduce, but cannot universally eliminate, that risk.

## Build status in this environment

The source project is prepared. This execution environment does not contain Android SDK Platform 36 or a Gradle installation, so an APK cannot be compiled or device-tested here. Build it in Android Studio using the steps above.

### Dźwięki potwierdzające
W ustawieniach aplikacji można niezależnie włączyć sygnał przy aktywacji i dezaktywacji DND, wybrać jeden z trzech krótkich tonów, ustawić jego głośność oraz włączyć wibrację. Sygnał aktywacji jest odtwarzany bezpośrednio przed zmianą DND, a sygnał dezaktywacji po przywróceniu poprzedniego filtra. Dźwięk korzysta ze strumienia multimediów; rzeczywista słyszalność zależy od poziomu głośności i polityki audio urządzenia.
