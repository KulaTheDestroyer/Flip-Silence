# Flip Silence – zmiany

## 1.0.1 – dźwięki potwierdzające
- Osobny przełącznik sygnału przy włączaniu DND.
- Osobny przełącznik sygnału przy wyłączaniu DND.
- Trzy krótkie sygnały do wyboru.
- Regulacja głośności sygnału.
- Opcjonalna wibracja przy zmianie trybu.
- Sygnał jest odtwarzany tylko przy rzeczywistej zmianie stanu zarządzanej przez aplikację.
