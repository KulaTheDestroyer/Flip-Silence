
package com.flipsilence.app

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.AudioPlaybackConfiguration
import android.media.MediaPlayer
import android.media.ToneGenerator
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import androidx.core.app.NotificationCompat
import java.io.File
import java.util.Calendar

class FlipMonitorService : Service(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private lateinit var notificationManager: NotificationManager
    private lateinit var audioManager: AudioManager
    private lateinit var cameraManager: CameraManager

    private val handler = Handler(Looper.getMainLooper())

    private var faceDown = false
    private var pendingFaceDown: Boolean? = null
    private var pendingRunnable: Runnable? = null

    private var torchOn = false
    private var torchCallback: CameraManager.TorchCallback? = null
    private var cameraAvailabilityCallback: CameraManager.AvailabilityCallback? = null

    private var sensorAvailable = false

    private var mediaPlaying = false
    private var playbackMonitoringAvailable = false

    private val busyCameras = mutableSetOf<String>()

    // Odtwarzanie dźwięków.
    private var mediaPlayer: MediaPlayer? = null
    private var toneGenerator: ToneGenerator? = null
    private var toneReleaseRunnable: Runnable? = null
    private var mediaTimeoutRunnable: Runnable? = null

    // Oczekująca zmiana DND.
    private var pendingDndEnable = false
    private var pendingDndGeneration = 0

    private var destroying = false

    private val dndBackupPreferences by lazy {
        getSharedPreferences(DND_BACKUP_PREFS, Context.MODE_PRIVATE)
    }

    private val periodicCheck = object : Runnable {
        override fun run() {
            if (destroying) return

            evaluateAutomation()
            handler.postDelayed(this, 15_000L)
        }
    }

    private val playbackCallback =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            object : AudioManager.AudioPlaybackCallback() {
                override fun onPlaybackConfigChanged(
                    configs: MutableList<AudioPlaybackConfiguration>
                ) {
                    updateMediaPlayback(configs)
                }
            }
        } else {
            null
        }

    private fun updateMediaPlayback(
        configs: List<AudioPlaybackConfiguration>
    ) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return

        mediaPlaying = try {
            configs.any { config ->
                config.audioAttributes.usage ==
                    AudioAttributes.USAGE_MEDIA
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not inspect audio playback configurations", e)
            false
        }

        evaluateAutomation()
    }

    // MONITOROWANIE KAMER

    private fun registerCameraAvailabilityCallback() {
        val callback = object : CameraManager.AvailabilityCallback() {

            override fun onCameraUnavailable(cameraId: String) {
                synchronized(busyCameras) {
                    busyCameras.add(cameraId)
                }
                evaluateAutomation()
            }

            override fun onCameraAvailable(cameraId: String) {
                synchronized(busyCameras) {
                    busyCameras.remove(cameraId)
                }
                evaluateAutomation()
            }
        }

        cameraAvailabilityCallback = callback

        try {
            cameraManager.registerAvailabilityCallback(callback, handler)
        } catch (e: Exception) {
            Log.w(TAG, "Camera availability monitoring unavailable", e)
        }
    }

    // MONITOROWANIE MULTIMEDIÓW

    private fun registerPlaybackCallback() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return

        try {
            val callback = playbackCallback ?: return

            audioManager.registerAudioPlaybackCallback(callback, handler)
            playbackMonitoringAvailable = true

            try {
                updateMediaPlayback(audioManager.activePlaybackConfigurations)
            } catch (e: SecurityException) {
                Log.w(TAG, "Cannot read active playback configurations", e)
            }
        } catch (e: Exception) {
            playbackMonitoringAvailable = false
            mediaPlaying = false
            Log.w(TAG, "Audio playback monitoring unavailable", e)
        }
    }

    // START USŁUGI

    override fun onCreate() {
        super.onCreate()

        notificationManager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        audioManager =
            getSystemService(Context.AUDIO_SERVICE) as AudioManager

        sensorManager =
            getSystemService(Context.SENSOR_SERVICE) as SensorManager

        cameraManager =
            getSystemService(Context.CAMERA_SERVICE) as CameraManager

        createNotificationChannel()

        startForeground(
            NOTIFICATION_ID,
            buildNotification()
        )

        val sensor =
            sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        if (sensor != null) {
            sensorAvailable = sensorManager.registerListener(
                this,
                sensor,
                SensorManager.SENSOR_DELAY_NORMAL
            )
        }

        registerTorchCallback()
        registerCameraAvailabilityCallback()
        registerPlaybackCallback()

        handler.post(periodicCheck)
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {
        if (!Settings.enabled(this)) {
            stopSelf()
            return START_NOT_STICKY
        }

        evaluateAutomation()
        return START_STICKY
    }

    // CZUJNIK POŁOŻENIA

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return

        val z = event.values[2]

        val candidate = when {
            z < -7.2f -> true
            z > 7.2f -> false
            else -> null
        }

        if (candidate == null) {
            pendingFaceDown = null
            pendingRunnable?.let(handler::removeCallbacks)
            pendingRunnable = null
            return
        }

        if (candidate == faceDown) {
            pendingFaceDown = null
            pendingRunnable?.let(handler::removeCallbacks)
            pendingRunnable = null
            return
        }

        if (pendingFaceDown == candidate && pendingRunnable != null) {
            return
        }

        pendingFaceDown = candidate
        pendingRunnable?.let(handler::removeCallbacks)

        val runnable = Runnable {
            if (pendingFaceDown == candidate && !destroying) {
                faceDown = candidate
                pendingFaceDown = null
                pendingRunnable = null
                evaluateAutomation()
            }
        }

        pendingRunnable = runnable

        handler.postDelayed(
            runnable,
            Settings.delayMs(this).toLong().coerceAtLeast(0L)
        )
    }

    override fun onAccuracyChanged(
        sensor: Sensor?,
        accuracy: Int
    ) = Unit

    // GŁÓWNA LOGIKA AUTOMATYZACJI

    private fun shouldEnableDndNow(): Boolean {
        if (destroying || !Settings.enabled(this)) return false

        val allowedBySchedule =
            !Settings.scheduleEnabled(this) || isWithinSchedule()

        val allowedByConditions = !isExcluded()

        return allowedBySchedule && allowedByConditions && faceDown
    }

    private fun evaluateAutomation() {
        if (destroying) return

        if (!Settings.enabled(this)) {
            cancelPendingDndEnable()
            restoreDndIfOwned()
            stopSelf()
            return
        }

        if (!shouldEnableDndNow()) {
            cancelPendingDndEnable()
            restoreDndIfOwned()
            return
        }

        enableDndIfAllowed()
    }

    // WŁĄCZANIE DND

    private fun enableDndIfAllowed() {
        if (destroying) return
        if (!notificationManager.isNotificationPolicyAccessGranted) return
        if (Settings.wasOurs(this)) return
        if (pendingDndEnable) return
        if (!shouldEnableDndNow()) return

        val currentFilter =
            notificationManager.currentInterruptionFilter

        // Nie przejmujemy żadnego trybu DND ustawionego ręcznie.
        if (currentFilter != NotificationManager.INTERRUPTION_FILTER_ALL) {
            return
        }

        val previousPolicy = try {
            notificationManager.notificationPolicy
        } catch (e: Exception) {
            Log.w(TAG, "Could not read previous DND policy", e)
            return
        }

        val newPolicy = createConfiguredPolicy(previousPolicy)

        // Zapisujemy stan sprzed rozpoczęcia odtwarzania dźwięku.
        savePreviousPolicy(previousPolicy)
        Settings.setPreviousFilter(this, currentFilter)

        pendingDndEnable = true
        val generation = ++pendingDndGeneration

        playConfirmation(enable = true) {
            // Callback może wykonać się po anulowaniu odtwarzania.
            if (
                destroying ||
                !pendingDndEnable ||
                generation != pendingDndGeneration
            ) {
                return@playConfirmation
            }

            if (!shouldEnableDndNow()) {
                cancelPendingDndEnable()
                return@playConfirmation
            }

            // Sprawdzamy, czy użytkownik nie zmienił DND
            // ręcznie podczas odtwarzania dźwięku.
            if (!isOriginalDndStateStillActive()) {
                Log.i(
                    TAG,
                    "DND state changed externally during confirmation; activation cancelled"
                )

                pendingDndEnable = false
                clearDndBackup()
                return@playConfirmation
            }

            try {
                notificationManager.setNotificationPolicy(newPolicy)

                notificationManager.setInterruptionFilter(
                    NotificationManager.INTERRUPTION_FILTER_PRIORITY
                )

                saveAppliedPolicy(newPolicy)

                Settings.setWasOurs(this, true)
                pendingDndEnable = false

                Log.i(TAG, "DND enabled with configured priority policy")

            } catch (e: SecurityException) {
                Log.w(TAG, "No permission to change DND", e)
                pendingDndEnable = false
                restoreSavedPolicyAfterFailedEnable(newPolicy)

            } catch (e: Exception) {
                Log.e(TAG, "Could not enable DND", e)
                pendingDndEnable = false
                restoreSavedPolicyAfterFailedEnable(newPolicy)
            }
        }
    }

    private fun isOriginalDndStateStillActive(): Boolean {
        return try {
            val currentFilter =
                notificationManager.currentInterruptionFilter

            val originalFilter = Settings.previousFilter(this)

            val currentPolicy =
                notificationManager.notificationPolicy

            val previousPolicy = getPreviousPolicy()

            currentFilter == originalFilter &&
                previousPolicy != null &&
                policiesEqual(currentPolicy, previousPolicy)

        } catch (e: Exception) {
            Log.w(TAG, "Could not verify original DND state", e)
            false
        }
    }

    private fun createConfiguredPolicy(
        previous: NotificationManager.Policy
    ): NotificationManager.Policy {

        var categories = 0

        if (Settings.allowDndAlarms(this)) {
            categories = categories or
                NotificationManager.Policy.PRIORITY_CATEGORY_ALARMS
        }

        if (Settings.allowDndCalls(this)) {
            categories = categories or
                NotificationManager.Policy.PRIORITY_CATEGORY_CALLS
        }

        if (Settings.allowDndRepeatCallers(this)) {
            categories = categories or
                NotificationManager.Policy.PRIORITY_CATEGORY_REPEAT_CALLERS
        }

        if (Settings.allowDndMessages(this)) {
            categories = categories or
                NotificationManager.Policy.PRIORITY_CATEGORY_MESSAGES
        }

        if (Settings.allowDndReminders(this)) {
            categories = categories or
                NotificationManager.Policy.PRIORITY_CATEGORY_REMINDERS
        }

        if (Settings.allowDndEvents(this)) {
            categories = categories or
                NotificationManager.Policy.PRIORITY_CATEGORY_EVENTS
        }

        if (Settings.allowDndMedia(this)) {
            categories = categories or
                NotificationManager.Policy.PRIORITY_CATEGORY_MEDIA
        }

        if (Settings.allowDndSystem(this)) {
            categories = categories or
                NotificationManager.Policy.PRIORITY_CATEGORY_SYSTEM
        }

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            NotificationManager.Policy(
                categories,
                previous.priorityCallSenders,
                previous.priorityMessageSenders,
                previous.suppressedVisualEffects,
                previous.priorityConversationSenders
            )
        } else {
            NotificationManager.Policy(
                categories,
                previous.priorityCallSenders,
                previous.priorityMessageSenders,
                previous.suppressedVisualEffects
            )
        }
    }

    // KOPIA POPRZEDNIEJ POLITYKI DND

    private fun savePreviousPolicy(policy: NotificationManager.Policy) {
        val editor = dndBackupPreferences.edit()

        editor.putBoolean(KEY_BACKUP_EXISTS, true)
        editor.putInt(KEY_PREVIOUS_CATEGORIES, policy.priorityCategories)
        editor.putInt(KEY_PREVIOUS_CALL_SENDERS, policy.priorityCallSenders)
        editor.putInt(KEY_PREVIOUS_MESSAGE_SENDERS, policy.priorityMessageSenders)
        editor.putInt(KEY_PREVIOUS_SUPPRESSED_EFFECTS, policy.suppressedVisualEffects)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            editor.putInt(
                KEY_PREVIOUS_CONVERSATION_SENDERS,
                policy.priorityConversationSenders
            )
        }

        editor.apply()
    }

    private fun getPreviousPolicy(): NotificationManager.Policy? {
        if (!dndBackupPreferences.getBoolean(KEY_BACKUP_EXISTS, false)) {
            return null
        }

        val categories =
            dndBackupPreferences.getInt(KEY_PREVIOUS_CATEGORIES, 0)

        val callSenders =
            dndBackupPreferences.getInt(KEY_PREVIOUS_CALL_SENDERS, 0)

        val messageSenders =
            dndBackupPreferences.getInt(KEY_PREVIOUS_MESSAGE_SENDERS, 0)

        val suppressedEffects =
            dndBackupPreferences.getInt(KEY_PREVIOUS_SUPPRESSED_EFFECTS, 0)

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                NotificationManager.Policy(
                    categories,
                    callSenders,
                    messageSenders,
                    suppressedEffects,
                    dndBackupPreferences.getInt(
                        KEY_PREVIOUS_CONVERSATION_SENDERS,
                        0
                    )
                )
            } else {
                NotificationManager.Policy(
                    categories,
                    callSenders,
                    messageSenders,
                    suppressedEffects
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Could not rebuild previous DND policy", e)
            null
        }
    }

    private fun saveAppliedPolicy(policy: NotificationManager.Policy) {
        val editor = dndBackupPreferences.edit()

        editor.putInt(KEY_APPLIED_CATEGORIES, policy.priorityCategories)
        editor.putInt(KEY_APPLIED_CALL_SENDERS, policy.priorityCallSenders)
        editor.putInt(KEY_APPLIED_MESSAGE_SENDERS, policy.priorityMessageSenders)
        editor.putInt(KEY_APPLIED_SUPPRESSED_EFFECTS, policy.suppressedVisualEffects)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            editor.putInt(
                KEY_APPLIED_CONVERSATION_SENDERS,
                policy.priorityConversationSenders
            )
        }

        editor.apply()
    }

    private fun isAppliedPolicyStillActive(): Boolean {
        return try {
            val current = notificationManager.notificationPolicy

            val sameBasePolicy =
                current.priorityCategories ==
                    dndBackupPreferences.getInt(KEY_APPLIED_CATEGORIES, -1) &&
                current.priorityCallSenders ==
                    dndBackupPreferences.getInt(KEY_APPLIED_CALL_SENDERS, -1) &&
                current.priorityMessageSenders ==
                    dndBackupPreferences.getInt(KEY_APPLIED_MESSAGE_SENDERS, -1) &&
                current.suppressedVisualEffects ==
                    dndBackupPreferences.getInt(KEY_APPLIED_SUPPRESSED_EFFECTS, -1)

            if (!sameBasePolicy) {
                false
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                current.priorityConversationSenders ==
                    dndBackupPreferences.getInt(
                        KEY_APPLIED_CONVERSATION_SENDERS,
                        -1
                    )
            } else {
                true
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not verify active DND policy", e)
            false
        }
    }

    private fun policiesEqual(
        first: NotificationManager.Policy,
        second: NotificationManager.Policy
    ): Boolean {
        val sameBaseFields =
            first.priorityCategories == second.priorityCategories &&
            first.priorityCallSenders == second.priorityCallSenders &&
            first.priorityMessageSenders == second.priorityMessageSenders &&
            first.suppressedVisualEffects == second.suppressedVisualEffects

        if (!sameBaseFields) return false

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            first.priorityConversationSenders ==
                second.priorityConversationSenders
        } else {
            true
        }
    }

    private fun clearDndBackup() {
        dndBackupPreferences.edit().clear().apply()
    }

    private fun restoreSavedPolicyAfterFailedEnable(
        attemptedPolicy: NotificationManager.Policy
    ) {
        if (!notificationManager.isNotificationPolicyAccessGranted) {
            clearDndBackup()
            return
        }

        val previousPolicy = getPreviousPolicy()

        if (previousPolicy == null) {
            clearDndBackup()
            return
        }

        try {
            val currentPolicy = notificationManager.notificationPolicy
            val currentFilter = notificationManager.currentInterruptionFilter
            val previousFilter = Settings.previousFilter(this)

            // Przywracamy politykę tylko wtedy, gdy nadal jest to
            // polityka ustawiona przez naszą próbę aktywacji.
            if (!policiesEqual(currentPolicy, attemptedPolicy)) {
                Log.i(
                    TAG,
                    "Policy changed externally after failed activation; leaving it intact"
                )
                clearDndBackup()
                return
            }

            notificationManager.setNotificationPolicy(previousPolicy)

            // Nie zmieniamy filtra, jeśli użytkownik zdążył
            // przełączyć go na inny tryb.
            if (
                currentFilter ==
                    NotificationManager.INTERRUPTION_FILTER_PRIORITY ||
                currentFilter == previousFilter
            ) {
                notificationManager.setInterruptionFilter(previousFilter)
            }

            Log.i(TAG, "Previous DND policy restored after failed activation")

        } catch (e: Exception) {
            Log.w(TAG, "Could not restore policy after failed enable", e)
        } finally {
            clearDndBackup()
        }
    }

    // ANULOWANIE OCZEKUJĄCEGO WŁĄCZENIA DND

    private fun cancelPendingDndEnable() {
        if (!pendingDndEnable) return

        pendingDndEnable = false
        pendingDndGeneration++

        releaseMediaPlayer()
        releaseToneGenerator()

        // W trakcie oczekiwania nie zmieniliśmy jeszcze DND,
        // więc nie ma potrzeby zachowywać kopii.
        if (!Settings.wasOurs(this)) {
            clearDndBackup()
        }

        Log.d(TAG, "Pending DND activation cancelled")
    }

    // PRZYWRACANIE DND

    private fun restoreDndIfOwned() {
        if (!Settings.wasOurs(this)) return

        if (!notificationManager.isNotificationPolicyAccessGranted) {
            // Zachowujemy informację o własności i backup.
            // Dzięki temu po ponownym przyznaniu dostępu
            // serwis będzie mógł jeszcze spróbować przywrócić stan.
            Log.w(TAG, "DND access revoked; previous policy backup retained")
            return
        }

        try {
            val currentFilter =
                notificationManager.currentInterruptionFilter

            // Przywracamy ustawienia tylko wtedy, gdy nadal aktywne
            // są zarówno nasz filtr, jak i nasza polityka.
            if (
                currentFilter ==
                    NotificationManager.INTERRUPTION_FILTER_PRIORITY &&
                isAppliedPolicyStillActive()
            ) {
                val previousPolicy = getPreviousPolicy()

                if (previousPolicy == null) {
                    Log.e(TAG, "Previous DND policy backup is missing")
                    return
                }

                val previousFilter = Settings.previousFilter(this)

                notificationManager.setNotificationPolicy(previousPolicy)

                notificationManager.setInterruptionFilter(previousFilter)

                Settings.setWasOurs(this, false)
                clearDndBackup()

                Log.i(TAG, "Previous DND policy and filter restored")

                // Dźwięk wyłączenia odtwarzamy dopiero po przywróceniu DND.
                playConfirmation(enable = false)
                return
            }

            Log.i(
                TAG,
                "DND was changed externally; leaving current settings intact"
            )

            // Użytkownik zmienił tryb lub politykę.
            // Nie przywracamy starego stanu i nie odtwarzamy
            // dźwięku potwierdzającego nasze wyłączenie.
            Settings.setWasOurs(this, false)
            clearDndBackup()

        } catch (e: SecurityException) {
            Log.w(TAG, "Could not restore previous DND state", e)
        } catch (e: Exception) {
            Log.e(TAG, "Error while restoring DND", e)
        }
    }

    // DŹWIĘK I WIBRACJA

    private fun playConfirmation(
        enable: Boolean,
        onFinished: () -> Unit = {}
    ) {
        if (destroying) {
            onFinished()
            return
        }

        val soundEnabled =
            if (enable) Settings.soundOnEnable(this)
            else Settings.soundOnDisable(this)

        val vibrationEnabled =
            if (enable) Settings.vibrationOnEnable(this)
            else Settings.vibrationOnDisable(this)

        if (vibrationEnabled) {
            vibrate()
        }

        if (soundEnabled && Settings.soundVolume(this) > 0) {
            playConfiguredSound(enable, onFinished)
        } else {
            onFinished()
        }
    }

    private fun playConfiguredSound(
        enable: Boolean,
        onFinished: () -> Unit
    ) {
        val soundType =
            if (enable) Settings.soundOnType(this)
            else Settings.soundOffType(this)

        val soundUri =
            if (enable) Settings.soundOnUri(this)
            else Settings.soundOffUri(this)

        val customFile =
            if (enable) Settings.soundOnCustomFile(this)
            else Settings.soundOffCustomFile(this)

        when (soundType) {
            Settings.SOUND_SYSTEM -> {
                if (!soundUri.isNullOrBlank()) {
                    playMediaSound(Uri.parse(soundUri), null, onFinished)
                } else {
                    playDefaultTone(onFinished)
                }
            }

            Settings.SOUND_CUSTOM -> {
                if (!customFile.isNullOrBlank()) {
                    val custom = File(customFile)

                    val resolved = if (custom.isAbsolute) {
                        custom
                    } else {
                        File(File(filesDir, "sounds"), customFile)
                    }

                    if (resolved.isFile) {
                        playMediaSound(
                            null,
                            resolved.absolutePath,
                            onFinished
                        )
                    } else {
                        Log.w(
                            TAG,
                            "Custom sound file is missing: ${resolved.absolutePath}"
                        )
                        playDefaultTone(onFinished)
                    }
                } else {
                    Log.w(TAG, "Custom sound filename is empty")
                    playDefaultTone(onFinished)
                }
            }

            else -> playDefaultTone(onFinished)
        }
    }

    private fun selectedAudioStream(): Int {
        return when (Settings.soundStream(this)) {
            Settings.STREAM_NOTIFICATION -> AudioManager.STREAM_NOTIFICATION
            Settings.STREAM_ALARM -> AudioManager.STREAM_ALARM
            else -> AudioManager.STREAM_MUSIC
        }
    }

    private fun selectedAudioUsage(): Int {
        return when (Settings.soundStream(this)) {
            Settings.STREAM_NOTIFICATION -> AudioAttributes.USAGE_NOTIFICATION
            Settings.STREAM_ALARM -> AudioAttributes.USAGE_ALARM
            else -> AudioAttributes.USAGE_MEDIA
        }
    }

    private fun playDefaultTone(onFinished: () -> Unit) {
        if (destroying) {
            onFinished()
            return
        }

        val volume = Settings.soundVolume(this).coerceIn(0, 100)

        if (volume <= 0) {
            onFinished()
            return
        }

        val tone = when (Settings.soundTone(this)) {
            1 -> ToneGenerator.TONE_PROP_ACK
            2 -> ToneGenerator.TONE_PROP_BEEP2
            else -> ToneGenerator.TONE_PROP_BEEP
        }

        try {
            releaseToneGenerator()

            val generator = ToneGenerator(
                selectedAudioStream(),
                volume
            )

            toneGenerator = generator

            val started = generator.startTone(tone, 650)

            if (!started) {
                releaseToneGenerator()
                onFinished()
                return
            }

            val releaseRunnable = Runnable {
                if (toneGenerator === generator) {
                    releaseToneGenerator()
                    onFinished()
                }
            }

            toneReleaseRunnable = releaseRunnable
            handler.postDelayed(releaseRunnable, 750L)

        } catch (e: Exception) {
            Log.w(TAG, "Could not play confirmation tone", e)
            releaseToneGenerator()
            onFinished()
        }
    }

    private fun playMediaSound(
        uri: Uri?,
        filePath: String?,
        onFinished: () -> Unit
    ) {
        if (destroying) {
            onFinished()
            return
        }

        val volume = Settings.soundVolume(this).coerceIn(0, 100)

        if (volume <= 0) {
            onFinished()
            return
        }

        releaseMediaPlayer()
        releaseToneGenerator()

        val player = MediaPlayer()
        mediaPlayer = player

        var completed = false

        fun finishPlayback() {
            if (completed) return
            completed = true

            mediaTimeoutRunnable?.let(handler::removeCallbacks)
            mediaTimeoutRunnable = null

            if (mediaPlayer === player) {
                releaseMediaPlayer()
            }

            onFinished()
        }

        fun fallbackToTone() {
            if (completed) return
            completed = true

            mediaTimeoutRunnable?.let(handler::removeCallbacks)
            mediaTimeoutRunnable = null

            if (mediaPlayer === player) {
                releaseMediaPlayer()
            }

            if (!destroying) {
                playDefaultTone(onFinished)
            } else {
                onFinished()
            }
        }

        try {
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(selectedAudioUsage())
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )

            if (uri != null) {
                player.setDataSource(this, uri)
            } else if (!filePath.isNullOrBlank()) {
                player.setDataSource(filePath)
            } else {
                releaseMediaPlayer()
                playDefaultTone(onFinished)
                return
            }

            val normalizedVolume = volume / 100f
            player.setVolume(normalizedVolume, normalizedVolume)

            player.setOnCompletionListener {
                finishPlayback()
            }

            player.setOnErrorListener { _, what, extra ->
                Log.w(
                    TAG,
                    "Confirmation sound playback error: what=$what extra=$extra"
                )

                fallbackToTone()
                true
            }

            player.setOnPreparedListener { preparedPlayer ->
                if (
                    mediaPlayer === preparedPlayer &&
                    !destroying &&
                    !completed
                ) {
                    try {
                        preparedPlayer.start()

                        // Zabezpieczenie na wypadek zawieszenia odtwarzacza.
                        val timeout = Runnable {
                            if (!completed) {
                                Log.w(TAG, "Confirmation sound playback timed out")
                                fallbackToTone()
                            }
                        }

                        mediaTimeoutRunnable = timeout
                        handler.postDelayed(timeout, 30_000L)

                    } catch (e: Exception) {
                        Log.w(TAG, "Could not start confirmation sound", e)
                        fallbackToTone()
                    }
                } else if (!completed) {
                    finishPlayback()
                }
            }

            player.prepareAsync()

        } catch (e: Exception) {
            Log.w(TAG, "Could not prepare confirmation sound", e)
            fallbackToTone()
        }
    }

    private fun releaseMediaPlayer() {
        mediaTimeoutRunnable?.let(handler::removeCallbacks)
        mediaTimeoutRunnable = null

        val player = mediaPlayer
        mediaPlayer = null

        if (player != null) {
            try {
                player.setOnCompletionListener(null)
                player.setOnPreparedListener(null)
                player.setOnErrorListener(null)
                player.reset()
                player.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun releaseToneGenerator() {
        toneReleaseRunnable?.let(handler::removeCallbacks)
        toneReleaseRunnable = null

        val generator = toneGenerator
        toneGenerator = null

        try {
            generator?.release()
        } catch (_: Exception) {
        }
    }

    private fun vibrate() {
        if (destroying) return

        try {
            if (Build.VERSION.SDK_INT >= 31) {
                val vibrator =
                    (getSystemService(Context.VIBRATOR_MANAGER_SERVICE)
                        as VibratorManager).defaultVibrator

                if (vibrator.hasVibrator()) {
                    vibrator.vibrate(
                        android.os.VibrationEffect.createOneShot(
                            140,
                            190
                        )
                    )
                }
            } else {
                @Suppress("DEPRECATION")
                val vibrator =
                    getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

                @Suppress("DEPRECATION")
                vibrator.vibrate(140L)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not vibrate", e)
        }
    }

    // WYKLUCZENIE: EKRAN ODBLOKOWANY

    private fun isScreenUnlocked(): Boolean {
        return try {
            val powerManager =
                getSystemService(Context.POWER_SERVICE) as PowerManager

            val keyguardManager =
                getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager

            powerManager.isInteractive &&
                !keyguardManager.isKeyguardLocked
        } catch (e: Exception) {
            Log.w(TAG, "Could not determine screen lock state", e)
            false
        }
    }

    // WYKLUCZENIE: APARAT

    private fun isCameraInUse(): Boolean {
        return synchronized(busyCameras) {
            busyCameras.isNotEmpty()
        }
    }

    // WYKLUCZENIE: MULTIMEDIA

    private fun isMediaPlaying(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return false
        if (!playbackMonitoringAvailable) return false
        return mediaPlaying
    }

    // WSZYSTKIE WARUNKI WYKLUCZENIA

    private fun isExcluded(): Boolean {
        if (Settings.blockTorch(this) && torchOn) {
            return true
        }

        if (Settings.blockMedia(this) && isMediaPlaying()) {
            return true
        }

        if (
            Settings.blockUnlockedScreen(this) &&
            isScreenUnlocked()
        ) {
            return true
        }

        if (
            Settings.blockCamera(this) &&
            isCameraInUse()
        ) {
            return true
        }

        if (
            Settings.blockHeadphones(this) &&
            headphonesConnected()
        ) {
            return true
        }

        val threshold = Settings.minBattery(this)

        if (threshold > 0 && batteryPercent() < threshold) {
            return true
        }

        return false
    }

    // SŁUCHAWKI

    private fun headphonesConnected(): Boolean {
        return audioManager
            .getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            .any { device ->
                when (device.type) {
                    AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
                    AudioDeviceInfo.TYPE_WIRED_HEADSET,
                    AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
                    AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
                    AudioDeviceInfo.TYPE_USB_HEADSET -> true

                    else -> {
                        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                            device.type == AudioDeviceInfo.TYPE_BLE_HEADSET
                    }
                }
            }
    }

    // BATERIA

    private fun batteryPercent(): Int {
        val intent = registerReceiver(
            null,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        ) ?: return 100

        val level =
            intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)

        val scale =
            intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)

        return if (level >= 0 && scale > 0) {
            level * 100 / scale
        } else {
            100
        }
    }

    // HARMONOGRAM

    private fun isWithinSchedule(): Boolean {
        val start = Settings.startMinute(this)
        val end = Settings.endMinute(this)

        if (start == end) return false

        val cal = Calendar.getInstance()

        val now =
            cal.get(Calendar.HOUR_OF_DAY) * 60 +
                cal.get(Calendar.MINUTE)

        val todayBit =
            dayBit(cal.get(Calendar.DAY_OF_WEEK))

        val previous =
            (cal.clone() as Calendar).apply {
                add(Calendar.DAY_OF_YEAR, -1)
            }

        val previousBit =
            dayBit(previous.get(Calendar.DAY_OF_WEEK))

        return if (start < end) {
            now >= start &&
                now < end &&
                (Settings.daysMask(this) and todayBit != 0)
        } else {
            (now >= start &&
                (Settings.daysMask(this) and todayBit != 0)) ||
                (now < end &&
                    (Settings.daysMask(this) and previousBit != 0))
        }
    }

    private fun dayBit(calendarDay: Int): Int {
        val index =
            if (calendarDay == Calendar.SUNDAY) {
                6
            } else {
                calendarDay - Calendar.MONDAY
            }

        return 1 shl index
    }

    // LATARKA

    private fun registerTorchCallback() {
        val callback = object : CameraManager.TorchCallback() {

            override fun onTorchModeChanged(
                cameraId: String,
                enabled: Boolean
            ) {
                torchOn = enabled
                evaluateAutomation()
            }

            override fun onTorchModeUnavailable(cameraId: String) {
                // Sama niedostępność kamery nie oznacza,
                // że latarka jest włączona.
            }
        }

        torchCallback = callback

        try {
            cameraManager.registerTorchCallback(callback, handler)
        } catch (e: Exception) {
            Log.w(TAG, "Torch callback unavailable", e)
        }
    }

    // POWIADOMIENIE

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Flip Silence – monitoring",
                NotificationManager.IMPORTANCE_LOW
            )

            channel.description =
                "Keeps phone orientation automation active"

            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode)
            .setContentTitle("Flip Silence is active")
            .setContentText(
                if (faceDown) {
                    "Phone face down – checking conditions"
                } else {
                    "Waiting for phone to be flipped"
                }
            )
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

    // ZAMYKANIE USŁUGI

    override fun onDestroy() {
        destroying = true

        cancelPendingDndEnable()

        handler.removeCallbacks(periodicCheck)

        pendingRunnable?.let {
            handler.removeCallbacks(it)
        }
        pendingRunnable = null
        pendingFaceDown = null

        sensorManager.unregisterListener(this)

        try {
            torchCallback?.let {
                cameraManager.unregisterTorchCallback(it)
            }
        } catch (_: Exception) {
        }

        try {
            cameraAvailabilityCallback?.let {
                cameraManager.unregisterAvailabilityCallback(it)
            }
        } catch (_: Exception) {
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                playbackCallback?.let {
                    audioManager.unregisterAudioPlaybackCallback(it)
                }
            } catch (_: Exception) {
            }
        }

        releaseMediaPlayer()
        releaseToneGenerator()

        restoreDndIfOwned()

        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val TAG = "FlipSilence"
        private const val CHANNEL_ID = "flip_silence_monitor"
        private const val NOTIFICATION_ID = 4107

        private const val DND_BACKUP_PREFS = "flip_silence_dnd_backup"

        private const val KEY_BACKUP_EXISTS = "backup_exists"

        private const val KEY_PREVIOUS_CATEGORIES = "previous_categories"
        private const val KEY_PREVIOUS_CALL_SENDERS = "previous_call_senders"
        private const val KEY_PREVIOUS_MESSAGE_SENDERS = "previous_message_senders"
        private const val KEY_PREVIOUS_SUPPRESSED_EFFECTS = "previous_suppressed_effects"
        private const val KEY_PREVIOUS_CONVERSATION_SENDERS = "previous_conversation_senders"

        private const val KEY_APPLIED_CATEGORIES = "applied_categories"
        private const val KEY_APPLIED_CALL_SENDERS = "applied_call_senders"
        private const val KEY_APPLIED_MESSAGE_SENDERS = "applied_message_senders"
        private const val KEY_APPLIED_SUPPRESSED_EFFECTS = "applied_suppressed_effects"
        private const val KEY_APPLIED_CONVERSATION_SENDERS = "applied_conversation_senders"
    }
}
