
package com.flipsilence.app

import android.content.Context
import android.os.Build

object Settings {
    private const val PREFS = "flip_silence_settings"

    private fun p(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // GŁÓWNE USTAWIENIA

    fun enabled(c: Context) = p(c).getBoolean("enabled", false)

    fun setEnabled(c: Context, v: Boolean) =
        p(c).edit().putBoolean("enabled", v).apply()

    // HARMONOGRAM

    fun scheduleEnabled(c: Context) =
        p(c).getBoolean("schedule_enabled", false)

    fun setScheduleEnabled(c: Context, v: Boolean) =
        p(c).edit().putBoolean("schedule_enabled", v).apply()

    fun startMinute(c: Context) =
        p(c).getInt("start_minute", 22 * 60)

    fun endMinute(c: Context) =
        p(c).getInt("end_minute", 7 * 60)

    fun setStartMinute(c: Context, v: Int) =
        p(c).edit().putInt("start_minute", v).apply()

    fun setEndMinute(c: Context, v: Int) =
        p(c).edit().putInt("end_minute", v).apply()

    fun daysMask(c: Context) =
        p(c).getInt("days_mask", 127)

    fun setDaysMask(c: Context, v: Int) =
        p(c).edit().putInt("days_mask", v).apply()

    // OPÓŹNIENIE

    fun delayMs(c: Context) =
        p(c).getInt("delay_ms", 500).coerceIn(0, 2000)

    fun setDelayMs(c: Context, v: Int) =
        p(c).edit().putInt("delay_ms", v.coerceIn(0, 2000)).apply()

    // CZUŁOŚĆ

    fun sensitivity(c: Context) =
        p(c).getInt("sensitivity", 50)

    fun setSensitivity(c: Context, v: Int) =
        p(c).edit().putInt("sensitivity", v.coerceIn(0, 100)).apply()

    // WYKLUCZENIA

    fun blockTorch(c: Context) =
        p(c).getBoolean("block_torch", true)

    fun setBlockTorch(c: Context, v: Boolean) =
        p(c).edit().putBoolean("block_torch", v).apply()

    fun blockMedia(c: Context) =
        p(c).getBoolean("block_media", true)

    fun setBlockMedia(c: Context, v: Boolean) =
        p(c).edit().putBoolean("block_media", v).apply()

    fun blockHeadphones(c: Context) =
        p(c).getBoolean("block_headphones", false)

    fun setBlockHeadphones(c: Context, v: Boolean) =
        p(c).edit().putBoolean("block_headphones", v).apply()

    // WYKLUCZENIE: EKRAN ODBLOKOWANY

    fun blockUnlockedScreen(c: Context) =
        p(c).getBoolean("block_unlocked_screen", true)

    fun setBlockUnlockedScreen(c: Context, v: Boolean) =
        p(c).edit().putBoolean("block_unlocked_screen", v).apply()

    // WYKLUCZENIE: APARAT UŻYWANY

    fun blockCamera(c: Context) =
        p(c).getBoolean("block_camera", true)

    fun setBlockCamera(c: Context, v: Boolean) =
        p(c).edit().putBoolean("block_camera", v).apply()

    // MINIMALNY POZIOM BATERII

    fun minBattery(c: Context) =
        p(c).getInt("min_battery", 0)

    fun setMinBattery(c: Context, v: Int) =
        p(c).edit().putInt("min_battery", v.coerceIn(0, 100)).apply()

    // DŹWIĘKI WŁĄCZENIA I WYŁĄCZENIA

    fun soundOnEnable(c: Context) =
        p(c).getBoolean("sound_on_enable", true)

    fun setSoundOnEnable(c: Context, v: Boolean) =
        p(c).edit().putBoolean("sound_on_enable", v).apply()

    fun soundOnDisable(c: Context) =
        p(c).getBoolean("sound_on_disable", true)

    fun setSoundOnDisable(c: Context, v: Boolean) =
        p(c).edit().putBoolean("sound_on_disable", v).apply()

    // GŁOŚNOŚĆ DŹWIĘKU - KOMPATYBILNOŚĆ ZE STARSZĄ WERSJĄ

    // Starsze ustawienie wspólnej głośności pozostaje zachowane.

    fun soundVolume(c: Context) =
        p(c).getInt("sound_volume", 65).coerceIn(0, 100)

    fun setSoundVolume(c: Context, v: Int) =
        p(c).edit().putInt("sound_volume", v.coerceIn(0, 100)).apply()

    // GŁOŚNOŚĆ DŹWIĘKU WŁĄCZENIA

    // Jeżeli nowe ustawienie jeszcze nie istnieje,
    // pobieramy wartość ze starszego wspólnego ustawienia.

    fun soundOnVolume(c: Context) =
        p(c).getInt("sound_on_volume", soundVolume(c)).coerceIn(0, 100)

    fun setSoundOnVolume(c: Context, v: Int) =
        p(c).edit().putInt("sound_on_volume", v.coerceIn(0, 100)).apply()

    // GŁOŚNOŚĆ DŹWIĘKU WYŁĄCZENIA

    // Jeżeli nowe ustawienie jeszcze nie istnieje,
    // pobieramy wartość ze starszego wspólnego ustawienia.

    fun soundOffVolume(c: Context) =
        p(c).getInt("sound_off_volume", soundVolume(c)).coerceIn(0, 100)

    fun setSoundOffVolume(c: Context, v: Int) =
        p(c).edit().putInt("sound_off_volume", v.coerceIn(0, 100)).apply()

    // STRUMIEŃ GŁOŚNOŚCI

    const val STREAM_MEDIA = "media"
    const val STREAM_NOTIFICATION = "notification"
    const val STREAM_ALARM = "alarm"

    // Domyślnie alarmy.
    // Wcześniej zapisany wybór użytkownika pozostaje bez zmian.

    fun soundStream(c: Context) =
        p(c).getString("sound_stream", STREAM_ALARM) ?: STREAM_ALARM

    fun setSoundStream(c: Context, v: String) {
        val valid = when (v) {
            STREAM_NOTIFICATION,
            STREAM_ALARM -> v
            else -> STREAM_MEDIA
        }

        p(c).edit().putString("sound_stream", valid).apply()
    }

    // WYBÓR ŹRÓDŁA DŹWIĘKU

    const val SOUND_DEFAULT = "default"
    const val SOUND_NOTIFICATION = "notification_sound"
    // Legacy value retained for migration from versions that used a ringtone picker.
    const val SOUND_SYSTEM = "system"
    const val SOUND_CUSTOM = "custom"

    private fun validSoundType(v: String) =
        when (v) {
            SOUND_DEFAULT,
            SOUND_NOTIFICATION,
            SOUND_CUSTOM -> v
            SOUND_SYSTEM -> SOUND_NOTIFICATION
            else -> SOUND_DEFAULT
        }

    // DŹWIĘK WŁĄCZENIA DND

    fun soundOnType(c: Context) =
        validSoundType(
            p(c).getString("sound_on_type", SOUND_DEFAULT) ?: SOUND_DEFAULT
        )

    fun setSoundOnType(c: Context, v: String) =
        p(c).edit().putString("sound_on_type", validSoundType(v)).apply()

    fun soundOnUri(c: Context) =
        p(c).getString("sound_on_uri", null)

    fun setSoundOnUri(c: Context, v: String?) =
        p(c).edit().putString("sound_on_uri", v).apply()

    fun soundOnCustomFile(c: Context) =
        p(c).getString("sound_on_custom_file", null)

    fun setSoundOnCustomFile(c: Context, v: String?) =
        p(c).edit().putString("sound_on_custom_file", v).apply()

    // DŹWIĘK WYŁĄCZENIA DND

    fun soundOffType(c: Context) =
        validSoundType(
            p(c).getString("sound_off_type", SOUND_DEFAULT) ?: SOUND_DEFAULT
        )

    fun setSoundOffType(c: Context, v: String) =
        p(c).edit().putString("sound_off_type", validSoundType(v)).apply()

    fun soundOffUri(c: Context) =
        p(c).getString("sound_off_uri", null)

    fun setSoundOffUri(c: Context, v: String?) =
        p(c).edit().putString("sound_off_uri", v).apply()

    fun soundOffCustomFile(c: Context) =
        p(c).getString("sound_off_custom_file", null)

    fun setSoundOffCustomFile(c: Context, v: String?) =
        p(c).edit().putString("sound_off_custom_file", v).apply()

    // STARSZE USTAWIENIE TONU - KOMPATYBILNOŚĆ

    fun soundTone(c: Context) =
        p(c).getInt("sound_tone", 0).coerceIn(0, 2)

    // Niezależne tony ON/OFF. Starszy wspólny ton służy jako wartość
    // migracyjna, aby aktualizacja nie zmieniała dotychczasowego wyboru.
    fun soundOnTone(c: Context) =
        p(c).getInt("sound_on_tone", soundTone(c)).coerceIn(0, 2)

    fun setSoundOnTone(c: Context, v: Int) =
        p(c).edit().putInt("sound_on_tone", v.coerceIn(0, 2)).apply()

    fun soundOffTone(c: Context) =
        p(c).getInt("sound_off_tone", soundTone(c)).coerceIn(0, 2)

    fun setSoundOffTone(c: Context, v: Int) =
        p(c).edit().putInt("sound_off_tone", v.coerceIn(0, 2)).apply()

    fun setSoundTone(c: Context, v: Int) =
        p(c).edit().putInt("sound_tone", v.coerceIn(0, 2)).apply()

    // WIBRACJE

    // Starsze ustawienie zachowane dla kompatybilności.

    fun vibration(c: Context) =
        p(c).getBoolean("vibration", false)

    fun setVibration(c: Context, v: Boolean) =
        p(c).edit().putBoolean("vibration", v).apply()

    // Wibracja przy włączaniu DND.
    // Jeżeli nie ma jeszcze nowego ustawienia,
    // wykorzystujemy wartość starszego ustawienia.

    fun vibrationOnEnable(c: Context) =
        p(c).getBoolean("vibration_on_enable", vibration(c))

    fun setVibrationOnEnable(c: Context, v: Boolean) =
        p(c).edit().putBoolean("vibration_on_enable", v).apply()

    // Wibracja przy wyłączaniu DND.
    // Zachowujemy kompatybilność ze starszym ustawieniem.

    fun vibrationOnDisable(c: Context) =
        p(c).getBoolean("vibration_on_disable", vibration(c))

    fun setVibrationOnDisable(c: Context, v: Boolean) =
        p(c).edit().putBoolean("vibration_on_disable", v).apply()

    // POWIADOMIENIE O DZIAŁANIU APLIKACJI

    fun showStatusNotification(c: Context) =
        p(c).getBoolean("show_status_notification", true)

    fun setShowStatusNotification(c: Context, v: Boolean) =
        p(c).edit().putBoolean("show_status_notification", v).apply()

    // JĘZYK APLIKACJI

    const val LANGUAGE_POLISH = "pl"
    const val LANGUAGE_ENGLISH = "en"

    // Pierwsze uruchomienie: polski systemowy -> polski, pozostałe -> angielski.
    // Jeżeli starsza wersja zapisała już wybór użytkownika, zachowujemy go.
    fun language(c: Context): String {
        val prefs = p(c)
        if (prefs.contains("language")) {
            return prefs.getString("language", LANGUAGE_ENGLISH)
                ?: LANGUAGE_ENGLISH
        }

        val systemLanguage = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            c.resources.configuration.locales[0]?.language
        } else {
            @Suppress("DEPRECATION")
            c.resources.configuration.locale?.language
        }

        return if (systemLanguage.equals("pl", ignoreCase = true)) {
            LANGUAGE_POLISH
        } else {
            LANGUAGE_ENGLISH
        }
    }

    fun setLanguage(c: Context, v: String) {
        val valid = when (v) {
            LANGUAGE_POLISH -> LANGUAGE_POLISH
            else -> LANGUAGE_ENGLISH
        }

        p(c).edit().putString("language", valid).apply()
    }

    // KONFIGURACJA TRYBU NIE PRZESZKADZAĆ

    fun allowDndAlarms(c: Context) =
        p(c).getBoolean("dnd_allow_alarms", true)

    fun setAllowDndAlarms(c: Context, v: Boolean) =
        p(c).edit().putBoolean("dnd_allow_alarms", v).apply()

    fun allowDndCalls(c: Context) =
        p(c).getBoolean("dnd_allow_calls", false)

    fun setAllowDndCalls(c: Context, v: Boolean) =
        p(c).edit().putBoolean("dnd_allow_calls", v).apply()

    fun allowDndRepeatCallers(c: Context) =
        p(c).getBoolean("dnd_allow_repeat_callers", false)

    fun setAllowDndRepeatCallers(c: Context, v: Boolean) =
        p(c).edit().putBoolean("dnd_allow_repeat_callers", v).apply()

    fun allowDndMessages(c: Context) =
        p(c).getBoolean("dnd_allow_messages", false)

    fun setAllowDndMessages(c: Context, v: Boolean) =
        p(c).edit().putBoolean("dnd_allow_messages", v).apply()

    fun allowDndReminders(c: Context) =
        p(c).getBoolean("dnd_allow_reminders", false)

    fun setAllowDndReminders(c: Context, v: Boolean) =
        p(c).edit().putBoolean("dnd_allow_reminders", v).apply()

    fun allowDndEvents(c: Context) =
        p(c).getBoolean("dnd_allow_events", false)

    fun setAllowDndEvents(c: Context, v: Boolean) =
        p(c).edit().putBoolean("dnd_allow_events", v).apply()

    fun allowDndMedia(c: Context) =
        p(c).getBoolean("dnd_allow_media", false)

    fun setAllowDndMedia(c: Context, v: Boolean) =
        p(c).edit().putBoolean("dnd_allow_media", v).apply()

    fun allowDndSystem(c: Context) =
        p(c).getBoolean("dnd_allow_system", false)

    fun setAllowDndSystem(c: Context, v: Boolean) =
        p(c).edit().putBoolean("dnd_allow_system", v).apply()

    // ZARZĄDZANIE TRYBEM NIE PRZESZKADZAĆ

    fun wasOurs(c: Context) =
        p(c).getBoolean("dnd_owned", false)

    fun setWasOurs(c: Context, v: Boolean) =
        p(c).edit().putBoolean("dnd_owned", v).apply()

    fun previousFilter(c: Context) =
        p(c).getInt("previous_filter", 1)

    fun setPreviousFilter(c: Context, v: Int) =
        p(c).edit().putInt("previous_filter", v).apply()

    // POPRZEDNIA POLITYKA DND

    fun previousPolicy(c: Context) =
        p(c).getInt("previous_policy", 0)

    fun setPreviousPolicy(c: Context, v: Int) =
        p(c).edit().putInt("previous_policy", v).apply()

    fun hasPreviousPolicy(c: Context) =
        p(c).getBoolean("has_previous_policy", false)

    fun setHasPreviousPolicy(c: Context, v: Boolean) =
        p(c).edit().putBoolean("has_previous_policy", v).apply()
}
