package com.flipsilence.app

import android.Manifest
import android.app.TimePickerDialog
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.util.Locale

private val Bg = Color(0xFF101827)
private val Panel = Color(0xFF1D2A3D)
private val Accent = Color(0xFF9BAEFF)

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { FlipSilenceScreen() }
    }
}

@Composable
private fun FlipSilenceScreen() {
    val context = LocalContext.current
    var enabled by remember { mutableStateOf(Settings.enabled(context)) }
    var schedule by remember { mutableStateOf(Settings.scheduleEnabled(context)) }
    var start by remember { mutableIntStateOf(Settings.startMinute(context)) }
    var end by remember { mutableIntStateOf(Settings.endMinute(context)) }
    var days by remember { mutableIntStateOf(Settings.daysMask(context)) }
    var delay by remember { mutableFloatStateOf(Settings.delayMs(context).toFloat()) }
    var torch by remember { mutableStateOf(Settings.blockTorch(context)) }
    var media by remember { mutableStateOf(Settings.blockMedia(context)) }
    var headphones by remember { mutableStateOf(Settings.blockHeadphones(context)) }
    var battery by remember { mutableIntStateOf(Settings.minBattery(context)) }
    var permission by remember { mutableStateOf(hasDndAccess(context)) }
    var soundEnable by remember { mutableStateOf(Settings.soundOnEnable(context)) }
    var soundDisable by remember { mutableStateOf(Settings.soundOnDisable(context)) }
    var soundVolume by remember { mutableIntStateOf(Settings.soundVolume(context)) }
    var soundTone by remember { mutableIntStateOf(Settings.soundTone(context)) }
    var vibration by remember { mutableStateOf(Settings.vibration(context)) }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("FLIP SILENCE", color = Accent, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            Text("Cisza jednym\nodwróceniem.", color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text("Odwróć telefon ekranem do dołu, aby włączyć Nie przeszkadzać. Odwróć go ekranem do góry, aby przywrócić poprzedni stan.", color = Color(0xFFB8C4D6))

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Automatyzacja", color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text(if (enabled) "Monitorowanie położenia aktywne" else "Automatyzacja wyłączona", color = Color(0xFFB8C4D6), style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = enabled, onCheckedChange = { value ->
                            if (value && !hasDndAccess(context)) {
                                context.startActivity(Intent(AndroidSettings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                            } else {
                                enabled = value; Settings.setEnabled(context, value); updateService(context, value)
                            }
                        })
                    }
                    Button(onClick = { context.startActivity(Intent(AndroidSettings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (permission) "Uprawnienie DND: przyznane" else "Nadaj dostęp do Nie przeszkadzać")
                    }
                    Text("Usługa działa jako widoczne powiadomienie, aby Android nie usypiał monitorowania czujnika.", color = Color(0xFF9EADC2), style = MaterialTheme.typography.bodySmall)
                }
            }

            Section("Harmonogram") {
                SettingSwitch("Ogranicz działanie do godzin", schedule) { schedule = it; Settings.setScheduleEnabled(context, it); if (enabled) updateService(context, true) }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TimeButton("Od", start, Modifier.weight(1f)) { start = it; Settings.setStartMinute(context, it) }
                    TimeButton("Do", end, Modifier.weight(1f)) { end = it; Settings.setEndMinute(context, it) }
                }
                Text("Dni tygodnia", color = Color.White, fontWeight = FontWeight.Medium)
                val names = listOf("Pn", "Wt", "Śr", "Cz", "Pt", "Sb", "Nd")
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    names.forEachIndexed { index, name ->
                        val bit = 1 shl index
                        FilterChip(selected = days and bit != 0, onClick = { days = days xor bit; Settings.setDaysMask(context, days) }, label = { Text(name) })
                    }
                }
                Text("Harmonogram dotyczy momentu aktywacji. Gdy okno czasowe się kończy, aplikacja przywraca poprzedni stan DND.", color = Color(0xFF9EADC2), style = MaterialTheme.typography.bodySmall)
            }

            Section("Warunki wykluczające") {
                SettingSwitch("Nie działaj, gdy latarka jest włączona", torch) { torch = it; Settings.setBlockTorch(context, it) }
                SettingSwitch("Nie działaj podczas odtwarzania multimediów", media) { media = it; Settings.setBlockMedia(context, it) }
                SettingSwitch("Nie działaj, gdy podłączone są słuchawki", headphones) { headphones = it; Settings.setBlockHeadphones(context, it) }
                Text("Minimalny poziom baterii: ${battery}% (0 = bez ograniczenia)", color = Color.White)
                Slider(value = battery.toFloat(), onValueChange = { battery = it.toInt() }, onValueChangeFinished = { Settings.setMinBattery(context, battery) }, valueRange = 0f..50f, steps = 9)
            }

            Section("Dźwięki i sygnały") {
                SettingSwitch("Odtwórz dźwięk przy włączaniu DND", soundEnable) { soundEnable = it; Settings.setSoundOnEnable(context, it) }
                SettingSwitch("Odtwórz dźwięk przy wyłączaniu DND", soundDisable) { soundDisable = it; Settings.setSoundOnDisable(context, it) }
                Text("Rodzaj sygnału", color = Color.White)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Krótki", "Potwierdzenie", "Podwójny").forEachIndexed { index, label ->
                        FilterChip(selected = soundTone == index, onClick = { soundTone = index; Settings.setSoundTone(context, index) }, label = { Text(label) })
                    }
                }
                Text("Głośność sygnału: $soundVolume%", color = Color.White)
                Slider(value = soundVolume.toFloat(), onValueChange = { soundVolume = it.toInt() }, onValueChangeFinished = { Settings.setSoundVolume(context, soundVolume) }, valueRange = 0f..100f, steps = 9)
                SettingSwitch("Wibracja przy zmianie trybu", vibration) { vibration = it; Settings.setVibration(context, it) }
                Text("Sygnał włączenia jest odtwarzany przed aktywacją DND, a sygnał wyłączenia po przywróceniu poprzedniego trybu. Dźwięk korzysta ze strumienia multimediów.", color = Color(0xFF9EADC2), style = MaterialTheme.typography.bodySmall)
            }

            Section("Czułość i opóźnienie") {
                Text("Opóźnienie przed zmianą DND: ${delay.toInt()} ms", color = Color.White)
                Slider(value = delay, onValueChange = { delay = it }, onValueChangeFinished = { Settings.setDelayMs(context, delay.toInt()); if (enabled) updateService(context, true) }, valueRange = 0f..2000f, steps = 7)
                Text("Wyższa wartość pomaga uniknąć przypadkowego uruchomienia podczas odkładania telefonu.", color = Color(0xFF9EADC2), style = MaterialTheme.typography.bodySmall)
            }

            Text("Wersja 1.0.0 • Flip Silence", color = Color(0xFF718096), style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
    LaunchedEffect(Unit) { permission = hasDndAccess(context) }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = {
            Text(title, color = Accent, fontWeight = FontWeight.Bold)
            content()
        })
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun TimeButton(label: String, minutes: Int, modifier: Modifier = Modifier, onSet: (Int) -> Unit) {
    val context = LocalContext.current
    OutlinedButton(modifier = modifier, onClick = {
        TimePickerDialog(context, { _, h, m -> onSet(h * 60 + m) }, minutes / 60, minutes % 60, true).show()
    }) { Text("$label  ${String.format(Locale.getDefault(), "%02d:%02d", minutes / 60, minutes % 60)}") }
}

private fun hasDndAccess(context: Context): Boolean {
    val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    return nm.isNotificationPolicyAccessGranted
}

private fun updateService(context: Context, start: Boolean) {
    val intent = Intent(context, FlipMonitorService::class.java)
    if (start) ContextCompat.startForegroundService(context, intent) else context.stopService(intent)
}
