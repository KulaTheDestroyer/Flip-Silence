package com.flipsilence.app

import android.content.Context

object Settings {
    private const val PREFS = "flip_silence_settings"
    private fun p(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun enabled(c: Context) = p(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("enabled", v).apply()
    fun scheduleEnabled(c: Context) = p(c).getBoolean("schedule_enabled", false)
    fun setScheduleEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("schedule_enabled", v).apply()
    fun startMinute(c: Context) = p(c).getInt("start_minute", 22 * 60)
    fun endMinute(c: Context) = p(c).getInt("end_minute", 7 * 60)
    fun setStartMinute(c: Context, v: Int) = p(c).edit().putInt("start_minute", v).apply()
    fun setEndMinute(c: Context, v: Int) = p(c).edit().putInt("end_minute", v).apply()
    fun daysMask(c: Context) = p(c).getInt("days_mask", 127)
    fun setDaysMask(c: Context, v: Int) = p(c).edit().putInt("days_mask", v).apply()
    fun delayMs(c: Context) = p(c).getInt("delay_ms", 500)
    fun setDelayMs(c: Context, v: Int) = p(c).edit().putInt("delay_ms", v).apply()
    fun blockTorch(c: Context) = p(c).getBoolean("block_torch", true)
    fun setBlockTorch(c: Context, v: Boolean) = p(c).edit().putBoolean("block_torch", v).apply()
    fun blockMedia(c: Context) = p(c).getBoolean("block_media", true)
    fun setBlockMedia(c: Context, v: Boolean) = p(c).edit().putBoolean("block_media", v).apply()
    fun blockHeadphones(c: Context) = p(c).getBoolean("block_headphones", false)
    fun setBlockHeadphones(c: Context, v: Boolean) = p(c).edit().putBoolean("block_headphones", v).apply()
    fun minBattery(c: Context) = p(c).getInt("min_battery", 0)
    fun setMinBattery(c: Context, v: Int) = p(c).edit().putInt("min_battery", v).apply()
    fun soundOnEnable(c: Context) = p(c).getBoolean("sound_on_enable", true)
    fun setSoundOnEnable(c: Context, v: Boolean) = p(c).edit().putBoolean("sound_on_enable", v).apply()
    fun soundOnDisable(c: Context) = p(c).getBoolean("sound_on_disable", true)
    fun setSoundOnDisable(c: Context, v: Boolean) = p(c).edit().putBoolean("sound_on_disable", v).apply()
    fun soundVolume(c: Context) = p(c).getInt("sound_volume", 65)
    fun setSoundVolume(c: Context, v: Int) = p(c).edit().putInt("sound_volume", v.coerceIn(0, 100)).apply()
    fun soundTone(c: Context) = p(c).getInt("sound_tone", 0)
    fun setSoundTone(c: Context, v: Int) = p(c).edit().putInt("sound_tone", v.coerceIn(0, 2)).apply()
    fun vibration(c: Context) = p(c).getBoolean("vibration", false)
    fun setVibration(c: Context, v: Boolean) = p(c).edit().putBoolean("vibration", v).apply()
    fun wasOurs(c: Context) = p(c).getBoolean("dnd_owned", false)
    fun setWasOurs(c: Context, v: Boolean) = p(c).edit().putBoolean("dnd_owned", v).apply()
    fun previousFilter(c: Context) = p(c).getInt("previous_filter", 1)
    fun setPreviousFilter(c: Context, v: Int) = p(c).edit().putInt("previous_filter", v).apply()
}
