package com.flipsilence.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Vibrator
import android.os.VibratorManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.hardware.camera2.CameraManager
import android.util.Log
import androidx.core.app.NotificationCompat
import java.util.Calendar

class FlipMonitorService : Service(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private lateinit var notificationManager: NotificationManager
    private lateinit var audioManager: AudioManager
    private lateinit var cameraManager: CameraManager
    private val handler = Handler(Looper.getMainLooper())
    private var faceDown = false
    private var pendingFaceDown: Boolean? = null
    private var pendingRunnable: Runnable? = null
    private var torchOn = false
    private var torchCallback: CameraManager.TorchCallback? = null
    private var sensorAvailable = false

    private val periodicCheck = object : Runnable {
        override fun run() {
            evaluateAutomation()
            handler.postDelayed(this, 15_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())

        val sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (sensor != null) {
            sensorAvailable = sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL)
        }
        registerTorchCallback()
        handler.post(periodicCheck)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.enabled(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        evaluateAutomation()
        return START_STICKY
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        val z = event.values[2]
        val candidate = when {
            z < -7.2f -> true
            z > 7.2f -> false
            else -> null
        }
        if (candidate == null) {
            pendingFaceDown = null
            pendingRunnable?.let(handler::removeCallbacks)
            pendingRunnable = null
            return
        }

        if (candidate == faceDown) {
            pendingFaceDown = null
            pendingRunnable?.let(handler::removeCallbacks)
            pendingRunnable = null
            return
        }
        if (pendingFaceDown == candidate && pendingRunnable != null) return

        pendingFaceDown = candidate
        pendingRunnable?.let(handler::removeCallbacks)
        val runnable = Runnable {
            if (pendingFaceDown == candidate) {
                faceDown = candidate
                pendingFaceDown = null
                pendingRunnable = null
                evaluateAutomation()
            }
        }
        pendingRunnable = runnable
        handler.postDelayed(runnable, Settings.delayMs(this).toLong().coerceAtLeast(0L))
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun evaluateAutomation() {
        if (!Settings.enabled(this)) {
            restoreDndIfOwned()
            stopSelf()
            return
        }
        val allowedBySchedule = !Settings.scheduleEnabled(this) || isWithinSchedule()
        val allowedByConditions = !isExcluded()
        if (!allowedBySchedule || !allowedByConditions || !faceDown) {
            restoreDndIfOwned()
            return
        }
        enableDndIfAllowed()
    }

    private fun enableDndIfAllowed() {
        if (!notificationManager.isNotificationPolicyAccessGranted) return
        if (Settings.wasOurs(this)) {
            // We already own the DND change; leave it in place until the phone is flipped back.
            return
        }
        val current = notificationManager.currentInterruptionFilter
        if (current == NotificationManager.INTERRUPTION_FILTER_NONE) return // DND was already enabled manually.
        Settings.setPreviousFilter(this, current)
        try {
            // Play before enabling DND so the confirmation is not suppressed by the new policy.
            playConfirmation(enable = true)
            notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
            Settings.setWasOurs(this, true)
        } catch (e: SecurityException) {
            Log.w(TAG, "No permission to change DND", e)
        }
    }

    private fun restoreDndIfOwned() {
        if (!Settings.wasOurs(this)) return
        if (notificationManager.isNotificationPolicyAccessGranted) {
            try {
                // Do not overwrite a manual change made after Flip Silence enabled DND.
                if (notificationManager.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_NONE) {
                    notificationManager.setInterruptionFilter(Settings.previousFilter(this))
                    playConfirmation(enable = false)
                }
            } catch (e: SecurityException) {
                Log.w(TAG, "Could not restore previous DND state", e)
            }
        }
        Settings.setWasOurs(this, false)
    }


    private fun playConfirmation(enable: Boolean) {
        val enabled = if (enable) Settings.soundOnEnable(this) else Settings.soundOnDisable(this)
        if (!enabled) return
        val volume = Settings.soundVolume(this)
        if (volume > 0) {
            val tone = when (Settings.soundTone(this)) {
                1 -> ToneGenerator.TONE_PROP_ACK
                2 -> ToneGenerator.TONE_PROP_BEEP2
                else -> ToneGenerator.TONE_PROP_BEEP
            }
            try {
                val generator = ToneGenerator(AudioManager.STREAM_MUSIC, volume)
                generator.startTone(tone, 150)
                handler.postDelayed({ try { generator.release() } catch (_: Exception) { } }, 300L)
            } catch (e: Exception) { Log.w(TAG, "Could not play confirmation tone", e) }
        }
        if (Settings.vibration(this)) {
            try {
                if (Build.VERSION.SDK_INT >= 31) {
                    (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator.vibrate(android.os.VibrationEffect.createOneShot(70, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).vibrate(70L)
                }
            } catch (e: Exception) { Log.w(TAG, "Could not vibrate", e) }
        }
    }

    private fun isExcluded(): Boolean {
        if (Settings.blockTorch(this) && torchOn) return true
        if (Settings.blockMedia(this) && audioManager.isMusicActive) return true
        if (Settings.blockHeadphones(this) && headphonesConnected()) return true
        val threshold = Settings.minBattery(this)
        if (threshold > 0 && batteryPercent() < threshold) return true
        return false
    }

    private fun headphonesConnected(): Boolean {
        return audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { device ->
            when (device.type) {
                AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
                AudioDeviceInfo.TYPE_WIRED_HEADSET,
                AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
                AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
                AudioDeviceInfo.TYPE_BLE_HEADSET,
                AudioDeviceInfo.TYPE_USB_HEADSET -> true
                else -> false
            }
        }
    }

    private fun batteryPercent(): Int {
        val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return 100
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        return if (level >= 0 && scale > 0) (level * 100 / scale) else 100
    }

    private fun isWithinSchedule(): Boolean {
        val start = Settings.startMinute(this)
        val end = Settings.endMinute(this)
        if (start == end) return false
        val cal = Calendar.getInstance()
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val todayBit = dayBit(cal.get(Calendar.DAY_OF_WEEK))
        val previous = (cal.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, -1) }
        val previousBit = dayBit(previous.get(Calendar.DAY_OF_WEEK))
        return if (start < end) {
            now >= start && now < end && (Settings.daysMask(this) and todayBit != 0)
        } else {
            (now >= start && (Settings.daysMask(this) and todayBit != 0)) ||
                (now < end && (Settings.daysMask(this) and previousBit != 0))
        }
    }

    private fun dayBit(calendarDay: Int): Int {
        // Calendar: Sunday=1; UI: Monday=bit 0 ... Sunday=bit 6.
        val index = if (calendarDay == Calendar.SUNDAY) 6 else calendarDay - Calendar.MONDAY
        return 1 shl index
    }

    private fun registerTorchCallback() {
        val callback = object : CameraManager.TorchCallback() {
            override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                torchOn = enabled
                evaluateAutomation()
            }
            override fun onTorchModeUnavailable(cameraId: String) {
                // Unavailable is not proof that the torch is on; leave the last known state.
            }
        }
        torchCallback = callback
        try {
            cameraManager.registerTorchCallback(callback, handler)
        } catch (e: Exception) {
            Log.w(TAG, "Torch callback unavailable", e)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Flip Silence – monitoring", NotificationManager.IMPORTANCE_LOW)
            channel.description = "Keeps phone orientation automation active"
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_lock_silent_mode)
        .setContentTitle("Flip Silence is active")
        .setContentText(if (faceDown) "Phone face down – checking conditions" else "Waiting for phone to be flipped")
        .setOngoing(true)
        .setCategory(NotificationCompat.CATEGORY_SERVICE)
        .build()

    override fun onDestroy() {
        handler.removeCallbacks(periodicCheck)
        pendingRunnable?.let(handler::removeCallbacks)
        sensorManager.unregisterListener(this)
        try { torchCallback?.let { cameraManager.unregisterTorchCallback(it) } } catch (_: Exception) { }
        restoreDndIfOwned()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val TAG = "FlipSilence"
        private const val CHANNEL_ID = "flip_silence_monitor"
        private const val NOTIFICATION_ID = 4107
    }
}
